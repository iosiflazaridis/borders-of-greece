"""Apply names.py to the research files in place (the originals are kept outside the kit). Ids, dates, statuses and selectors
are not touched; titles in the sources are cited as they are."""
import json, sys, glob
sys.path.insert(0, "/home/claude/gb/data")
import names as N, mapping as M
from sel_auto import SEL_AUTO
SKIP = {"id", "status", "start", "end", "joint", "lat", "lon", "selector"}
def walk(v, tk, key=None):
    if key in SKIP: return v
    if key == "sources": return N.clean_sources(v) if isinstance(v, str) else v
    if isinstance(v, str): return N.clean(v, tk)
    if isinstance(v, list): return [walk(x, tk) for x in v]
    if isinstance(v, dict): return {k: walk(x, tk, k) for k, x in v.items()}
    return v
for f in sorted(glob.glob("/home/claude/gb/research/GB*.json")):
    data = json.load(open(f)); out = []
    for e in data:
        sel = M.SEL.get(e["id"]) or SEL_AUTO.get(e["id"]) or ""
        tk = "tr:" in sel or (f.endswith("GB4a.json") and not any(k in e["id"] for k in ("ukraine", "crimea")))
        out.append(walk(e, tk))
    json.dump(out, open(f, "w"), ensure_ascii=False, indent=1); print(f, len(out))
