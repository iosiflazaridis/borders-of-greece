"""The state of the map on any date: one geometry per display class, from the normalised events.

classes: dj (de jure), df (de facto, own), dfj (de facto, joint Allied sector), occ (Greek territory under foreign occupation),
aut (autonomous Greek entities), awd (awarded, outline), ris (risings for union, site only), ins (insurgent-held, site only),
plus the holdout markers (Ottoman-held fortresses inside revolution-held areas).
"""
import json, pickle, functools, sys
sys.path.insert(0, "/home/claude/gb/data")
from shapely.ops import unary_union
from shapely.geometry import Polygon, Point
import mapping as M

EV = json.load(open("/home/claude/gb/data/events.json"))
GM = pickle.load(open("/home/claude/gb/data/geom.pkl", "rb"))
GEO = [e for e in EV if e["id"] in GM and e["status"] in ("de_jure", "de_facto", "awarded", "occupied", "autonomous", "rising", "insurgent")]

def active(date):
    return frozenset(e["id"] for e in GEO if e["start"] <= date and (e["end"] is None or date < e["end"]))

BY = {e["id"]: e for e in GEO}
EMPTY = Polygon()

def _u(ids):
    gs = [GM[i] for i in ids]
    return unary_union(gs) if gs else EMPTY

@functools.lru_cache(None)
def classes(ids):
    by = {}
    for i in ids:
        e = BY[i]; k = e["status"]
        if k == "de_facto" and e.get("joint"): k = "joint"
        by.setdefault(k, []).append(i)
    occ = _u(by.get("occupied", []))
    dj = _u(by.get("de_jure", [])).difference(occ)
    held = unary_union([dj, occ])
    df = _u(by.get("de_facto", [])).difference(held)
    dfj = _u(by.get("joint", [])).difference(held).difference(df)
    greek = unary_union([held, df, dfj])
    aut = _u(by.get("autonomous", [])).difference(greek)
    awd = _u(by.get("awarded", []))
    ris = _u(by.get("rising", [])).difference(greek)
    ins = _u(by.get("insurgent", []))
    return dict(dj=dj, df=df, dfj=dfj, occ=occ, aut=aut, awd=awd, ris=ris, ins=ins)

def state(date):
    ids = active(date)
    c = classes(ids)
    greek = unary_union([c["dj"], c["df"]])
    hold = [(n, la, lo) for n, la, lo, s, e in M.HOLDOUTS if s <= date < e and greek.distance(Point(lo, la)) < 0.04]
    return c, hold, ids
