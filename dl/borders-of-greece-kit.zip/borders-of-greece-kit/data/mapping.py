"""Event -> geometry selector (pieces.py DSL) for the Borders of Greece, plus the editorial calls on the 365 research events.

SEL[id]       the selector; Turkish ilçe events not listed here are parsed from their 'units' automatically (see build_events.py)
STATUS[id]    status overrides (e.g. the Entente presence of 1915-17 -> note; the irregular risings of 1854 and 1878 -> rising)
DATES[id]     (start, end) overrides, with the reason in WHY[id]
DROP          duplicates
HOLDOUTS      Ottoman-held fortresses inside revolution-held areas, 1821-1833 (and Punta 1832-81): point markers
EXTRA         events added here (fill-ins), with their reasons
"""

ATTICA = "ru:Central Athens;ru:North Athens;ru:West Athens;ru:South Athens;ru:Piraeus;ru:East Attica;ru:West Attica"
PELOP = "ru:Argolis;ru:Arcadia;ru:Corinthia;ru:Laconia;ru:Messenia;ru:Achaea;ru:Elis"
CYCL = "ru:Andros;ru:Tinos;ru:Syros;ru:Mykonos;ru:Kea-Kythnos;ru:Milos;ru:Paros;ru:Naxos;ru:Thira"
SARONIC = "m:Salamina;m:Aegina;m:Agistri;m:Poros;m:Troizinia-Methana"
ISLANDS_ATT = SARONIC + ";m:Ydra;m:Spetses"
EUBOEA = "ru:Euboea;-m:Skyros"
IONIAN = "ru:Corfu;ru:Lefkada;ru:Ithaca;ru:Kefalonia;ru:Zakynthos;m:Kythira"
CRETE = "ru:Chania;ru:Rethymno;ru:Heraklion;ru:Lasithi"
DODEC = "ru:Rhodes;ru:Kos;ru:Kalymnos;ru:Karpathos"
NE_AEG = "m:Lemnos;m:Agios Efstratios;m:Samothrakis;ru:Thasos;ru:Lesbos;m:Chios;m:Oinousses;m:Psara;ru:Samos;ru:Ikaria"
EPIRUS = "ru:Ioannina;ru:Thesprotia;ru:Preveza;ru:Arta"
THESSALY = "ru:Larissa;ru:Magnesia;ru:Trikala;ru:Karditsa"
CENTRAL = "ru:Phthiotis;ru:Phocis;ru:Boeotia;ru:Evrytania;ru:Aetolia-Acarnania"
WMAC = "ru:Florina;ru:Kastoria;ru:Kozani;ru:Grevena"
CMAC = "ru:Thessaloniki;ru:Chalkidiki;ru:Kilkis;ru:Pella;ru:Imathia;ru:Pieria"
EMAC_E = "ru:Serres@EStr;ru:Drama;ru:Kavala"
WTHRACE = "ru:Xanthi;ru:Rhodope;ru:Evros;-m:Samothrakis"
PHTH_S = "m:Lokroi;m:Amfikleia-Elateia;m:Molos-Agios Konstantinos"
GORGOP = "[m:Lamia@SSp;&box:22.33,38.5,22.7,39]"            # the Gorgopotamos unit: Lamia municipality south of the Spercheios, east of the Ypati unit (approx)
N_EPIRUS_SW = "al:Gjirokastër;al:Delvinë;al:Sarandë;al:Himarë;al:Përmet;al:Tepelenë"
N_EPIRUS_KO = "al:Korçë;al:Devoll;al:Kolonjë"
KARAAGAC = "tr:Edirne/Edirne merkez@W"
E_THRACE = ("tr:Edirne/*;-" + KARAAGAC + ";tr:Kırklareli/*;tr:Tekirdağ/*;tr:Constantinople/Silivri;[tr:Constantinople/Çatalca;&box:25,40,28.45,42.2]"
            ";tr:Çanakkale/Gelibolu;tr:Çanakkale/Eceabat")

SEL = {
    # ---------------------------------------------------------------- GB1: the revolution, 1821-1833
    "1821-mani": "m:East Mani;m:West Mani",
    "1821-kalamata-messenia": "ru:Messenia;-m:West Mani",
    "1821-navarino": "c:36.925,21.69,5",
    "1821-arcadia": "ru:Arcadia",
    "1821-tripolitsa": "c:37.51,22.373,4",
    "1821-achaea-elis": "ru:Achaea;ru:Elis",
    "1821-laconia": "m:Sparta;m:Evrotas;m:Elafonisos;m:Monemvasia",
    "1821-monemvasia": "c:36.687,23.056,4",
    "1821-argolis": "ru:Argolis",
    "1822-nafplio": "c:37.567,22.801,4",
    "1822-acrocorinth-a": "c:37.9,22.88,5",
    "1821-corinthia": "ru:Corinthia",
    "1823-acrocorinth-b": "c:37.9,22.88,5",
    "1828-peloponnese-evacuated": "ru:Messenia;ru:Arcadia;ru:Laconia;ru:Elis;ru:Achaea",
    "1828-patras": "c:38.243,21.743,4",
    "1828-rio": "c:38.306,21.783,3",
    "1828-navarino": "c:36.925,21.69,5",
    "1828-methoni": "c:36.817,21.705,3",
    "1828-koroni": "c:36.795,21.958,3",
    "1821-eastern-roumeli": "ru:Phocis;ru:Boeotia;" + PHTH_S,
    "1821-athens-a": "c:37.975,23.73,4",
    "1821-athens-attica-b": ATTICA,
    "1822-acropolis": "c:37.972,23.726,1.5",
    "1826-karaiskakis-parnassus": "m:Distomo-Arachova-Antikyra;m:Delphi",
    "1821-western-roumeli": "ru:Aetolia-Acarnania",
    "1821-missolonghi": "c:38.371,21.428,6",
    "1821-anatoliko": "c:38.437,21.351,4",
    "1829-akarnania-vonitsa": "m:Aktio-Vonitsa;m:Xiromero;m:Amfilochia;m:Agrinio@WAch",
    "1829-nafpaktos-antirrio": "c:38.393,21.828,5;c:38.33,21.769,3",
    "1829-missolonghi-aetolia": "m:Missolonghi;m:Agrinio@EAch;m:Thermo;m:Nafpaktia",
    "1829-evrytania": "ru:Evrytania",
    "1828-livadeia-salona": "m:Livadeia;m:Orchomenus;m:Distomo-Arachova-Antikyra;m:Delphi;m:Dorida",
    "1829-thebes": "m:Thebes;m:Tanagra;m:Aliartos",
    "1829-petra-capitulation": PHTH_S + ";" + GORGOP,
    "1821-spetses": "m:Spetses",
    "1821-hydra": "m:Ydra",
    "1821-psara": "m:Psara",
    "1821-kasos": "m:Kasos",
    "1821-samos": "ru:Samos",
    "1821-cyclades": CYCL,
    "1821-saronic": SARONIC,
    "1821-northern-sporades": "ru:Sporades;m:Skyros",
    "1821-euboea-countryside": "m:Istiaia-Aidipsos;m:Mantoudi-Limni-Agia Anna;m:Kymi-Aliveri;m:Dirfys-Messapia",
    "1822-chios": "m:Chios",
    "1821-dodecanese-islands": "m:Patmos;m:Leros;m:Kalymnos;m:Astypalaia",
    "1821-crete": "ru:Chania;ru:Rethymno;ru:Heraklion",
    "1825-gramvousa": "pt:35.613,23.578",
    "1828-crete-frangokastello": "m:Sfakia",
    "1821-chalkidiki": "m:Kassandra;m:Sithonia;ru:Mount Athos",
    "1822-naoussa-olympus": "m:Naousa;c:40.42,22.14,8;m:Pydna - Kolindros;m:Katerini;m:Dion-Olympus",
    "1828-11-protocol-morea-cyclades": PELOP + ";" + ISLANDS_ATT + ";" + CYCL,
    "1829-03-22-arta-volos-protocol": PELOP + ";" + ATTICA + ";" + ISLANDS_ATT + ";ru:Aetolia-Acarnania;ru:Boeotia;ru:Phocis;ru:Evrytania;ru:Phthiotis;-m:Domokos@N1832;" + CYCL,
    "1830-02-03-aspropotamos-spercheios": PELOP + ";m:Missolonghi;m:Nafpaktia;[m:Agrinio@EAch;&box:19,34,30,38.56];ru:Phocis;ru:Boeotia;" + PHTH_S + ";" + ATTICA + ";" + ISLANDS_ATT + ";ru:Euboea;ru:Sporades;" + CYCL,
    "1831-09-26-arta-volos-protocol": PELOP + ";" + ATTICA + ";" + ISLANDS_ATT + ";ru:Aetolia-Acarnania;ru:Boeotia;ru:Phocis;ru:Evrytania;ru:Phthiotis;-m:Domokos@N1832;" + CYCL + ";ru:Euboea;ru:Sporades",
    "1832-kingdom-de-jure": PELOP + ";ru:Aetolia-Acarnania;-c:38.952,20.765,3;ru:Boeotia;ru:Phocis;ru:Evrytania;" + PHTH_S + ";" + GORGOP + ";m:Domokos@S1832;" + ISLANDS_ATT + ";ru:Sporades;m:Skyros;" + CYCL,
    "1832-attica-awarded-pending": ATTICA,
    "1833-attica-handover": ATTICA,
    "1832-euboea-awarded-pending": EUBOEA,
    "1833-euboea-handover": EUBOEA,
    "1832-lamia-awarded-pending": "m:Lamia;m:Stylida;m:Makrakomi",
    "1833-lamia-handover": "m:Lamia;m:Stylida;m:Makrakomi",
    # ---------------------------------------------------------------- GB2: 1833-1912
    "1854-epirus-arta-peta": "m:Arta;m:Nikolaos Skoufas;m:Georgios Karaiskakis",
    "1854-epirus-metsovo": "m:Metsovo",
    "1854-epirus-north-west": "m:Souli;m:Filiates;al:Himarë",
    "1854-thessaly-insurgents": "",                       # 'mountain districts, places not named': no geometry (site text only)
    "1854-macedonia-olympus-pindus": "m:Tempi;m:Dion-Olympus;m:Grevena",
    "1854-chalkidiki-athos": "m:Sithonia;ru:Mount Athos",
    "1854-piraeus-occupation": "m:Pireas",
    "1864-ionian-corfu-paxoi": "ru:Corfu",
    "1864-ionian-other-islands": "ru:Lefkada;ru:Ithaca;ru:Kefalonia;ru:Zakynthos;m:Kythira",
    "1878-greek-army-thessaly": "m:Domokos@N1832",
    "1878-thessaly-insurgents": "m:Lake Plastiras;m:Mouzaki",
    "1878-epirus-insurgents": "m:Central Tzoumerka;m:Georgios Karaiskakis",
    "1878-agioi-saranta-delvino": "al:Sarandë;al:Delvinë",
    "1878-macedonia-olympus-vourinos": "m:Dion-Olympus;c:40.2,21.65,12",
    "1880-berlin-conference-award": THESSALY + ";m:Domokos;ru:Arta;ru:Preveza;m:Ioannina;m:Metsovo;m:Dodoni;m:North Tzoumerka;m:Zitsa;[m:Zagori;&box:19,34,30,39.86];ru:Thesprotia@SKal;[m:Dion-Olympus;&box:19,34,30,40.14]",
    "1881-thessaly-arta": "ru:Larissa;-m:Elassona;ru:Magnesia;ru:Trikala;ru:Karditsa;m:Domokos;ru:Arta@E",
    "1881-punta": "[m:Aktio-Vonitsa;&c:38.952,20.765,3]",
    "1881-82-disputed-frontier-points": "",              # inside the 1881 area already; not drawn separately
    "1897-crete-vassos-expedition": "m:Platanias",
    "1897-epirus-first-advance": "ru:Arta@W;m:Ziros",
    "1897-epirus-second-advance": "ru:Arta@W;m:Ziros;m:Preveza",
    "1897-grevena-villages": "m:Deskati",
    "1897-ottoman-occupation-tyrnavos": "m:Tyrnavos",
    "1897-ottoman-occupation-larissa": "m:Larissa;m:Kileler;m:Agia;m:Tempi",
    "1897-ottoman-occupation-west-thessaly": "ru:Trikala;ru:Karditsa",
    "1897-ottoman-occupation-velestino-volos-farsala": "ru:Magnesia;m:Farsala",
    "1897-ottoman-occupation-domokos-othrys": "m:Domokos;c:38.99,22.31,6",
    "1897-frontier-rectification-strips": "",            # the strips are not located in any source: not drawn (stated on the map)
    "1898-cretan-state": CRETE,
    "1908-crete-union-declared": CRETE,
    "1834-principality-of-samos": "ru:Samos",
    # ---------------------------------------------------------------- GB3: 1912-1918
    "1912-icaria-free-state": "ru:Ikaria",
    "1912-ikaria": "ru:Ikaria",
    "1912-crete-greek-administration": CRETE,
    "1913-crete-union": CRETE,
    "1913-samos": "ru:Samos",
    "1912-elassona-deskati": "m:Elassona;m:Deskati",
    "1912-sarantaporo-servia": "m:Servia-Velventos",
    "1912-kozani": "m:Kozani",
    "1912-grevena-siatista": "m:Grevena;m:Voio",
    "1912-eordaia-amyntaio": "m:Eordaia;[m:Amyntaio;&box:21,40.5,22,40.72];c:40.80,21.83,6",
    "1912-katerini": "ru:Pieria",
    "1912-veria-naousa": "ru:Imathia",
    "1912-edessa": "m:Edessa;m:Skydra;m:Almopia",
    "1912-giannitsa": "m:Pella",
    "1912-thessaloniki": "ru:Thessaloniki",
    "1912-chalkidiki": "ru:Chalkidiki",
    "1912-mount-athos": "ru:Mount Athos",
    "1912-florina": "m:Florina;m:Prespes;[m:Amyntaio;&box:21,40.72,22,41.2]",
    "1912-kastoria": "ru:Kastoria",
    "1912-philippiada-louros": "m:Ziros;c:39.16,20.76,6;ru:Arta@W",
    "1912-preveza": "m:Preveza;m:Parga",
    "1912-chimarra": "al:Himarë",
    "1912-metsovo": "m:Metsovo",
    "1912-epirus-front-bizani": "ru:Preveza;ru:Arta@W;m:Dodoni;m:North Tzoumerka;m:Metsovo",
    "1912-korytsa": "al:Korçë;al:Devoll",
    "1913-ioannina": "ru:Ioannina",
    "1913-thesprotia": "ru:Thesprotia;m:Parga",
    "1913-argyrokastro-delvino": "al:Gjirokastër;al:Delvinë",
    "1913-tepeleni": "al:Tepelenë",
    "1913-premeti-kolonia": "al:Përmet;al:Kolonjë",
    "1913-agioi-saranta": "al:Sarandë",
    "1913-northern-epirus-extent": N_EPIRUS_SW + ";" + N_EPIRUS_KO,
    "1912-lemnos": "m:Lemnos",
    "1912-thasos": "ru:Thasos",
    "1912-agios-efstratios": "m:Agios Efstratios",
    "1912-imbros": "tr:Çanakkale/Imbros",
    "1912-samothrace": "m:Samothrakis",
    "1912-psara": "m:Psara",
    "1912-tenedos": "tr:Çanakkale/Tenedos",
    "1912-lesbos": "ru:Lesbos",
    "1912-chios": "m:Chios;m:Oinousses",
    "1914-aegean-islands-de-jure": NE_AEG,
    "1913-kastellorizo": "m:Kastellorizo",
    "1913-greek-bulgarian-line-june": "ru:Thessaloniki;ru:Chalkidiki;m:Paionia",
    "1913-kilkis-lachanas": "m:Kilkis;m:Paionia",
    "1913-nigrita": "m:Visaltia",
    "1913-gevgeli": "c:41.141,22.502,8",
    "1913-doiran": "c:41.18,22.72,6",
    "1913-sidirokastro": "m:Sintiki",
    "1913-serres": "m:Serres;m:Emmanouil Pappas;m:Nea Zichni;m:Amphipolis;m:Irakleia",
    "1913-kavala": "ru:Kavala",
    "1913-drama": "ru:Drama",
    "1913-nevrokop": "bg:Gotse Delchev;bg:Garmen;bg:Hadzhidimovo;bg:Satovcha",
    "1913-upper-strymon": "bg:Petrich;bg:Sandanski;bg:Strumyarni;bg:Kresna",
    "1913-kresna-simitli": "bg:Simitli;[bg:Blagoevgrad;&box:22,41,24,41.97]",
    "1913-dedeagatch": "m:Alexandroupolis;[m:Soufliou;&box:25,40.5,27,41.14]",
    "1913-xanthi": "m:Xanthis;m:Avdiron;m:Topirou",
    "1913-komotini": "m:Komotinis;m:Maronias-Sapon;[m:Iasmou;&box:24,40.5,26,41.15]",
    "1913-armistice-front": "",                          # the union of the town events above; not drawn again
    "1913-macedonia-de-jure": CMAC + ";" + WMAC + ";m:Elassona",
    "1913-eastern-macedonia-de-jure": "ru:Serres;ru:Drama;ru:Kavala",
    "1913-epirus-de-jure": EPIRUS,
    "1914-northern-epirus-autonomous": "al:Gjirokastër;al:Delvinë;al:Sarandë;al:Himarë;al:Përmet",
    "1914-northern-epirus-greek-argyrokastro": N_EPIRUS_SW,
    "1914-northern-epirus-greek-korytsa": N_EPIRUS_KO,
    "1916-italy-northern-epirus": N_EPIRUS_SW,
    "1916-bulgaria-korytsa": "al:Korçë",
    "1916-france-korytsa": N_EPIRUS_KO,
    "1915-thessaloniki-entente": "ru:Thessaloniki;ru:Chalkidiki;ru:Kilkis",
    "1915-milos-allied": "m:Milos",
    "1915-lesbos-allied-base": "ru:Lesbos",
    "1915-kastellorizo-french": "m:Kastellorizo",
    "1916-corfu-french": "ru:Corfu",
    "1916-rupel": "m:Sintiki;&box:23,41.26,24,41.5",
    "1916-eastern-macedonia-bulgarian": EMAC_E,
    "1916-kavala": "m:Kavalas",
    "1916-florina-bulgarian": "m:Florina;m:Prespes;[m:Amyntaio;&box:21,40.72,22,41.2];c:40.97,21.8,6",
    "1916-skra-salient": "c:41.10,22.52,5",
    "1916-national-defence-macedonia": CMAC,
    "1916-national-defence-islands": CRETE + ";" + NE_AEG,
    "1917-thessaly-french": THESSALY,
    # ---------------------------------------------------------------- GB4a: Ukraine (joint Allied sectors)
    "1919-ukraine-odessa": "c:46.47,30.72,12",
    "1919-ukraine-odessa-front-berezovka-serbka": "c:47.20,30.91,9;c:46.90,30.82,7",
    "1919-ukraine-kherson": "c:46.64,32.61,8",
    "1919-ukraine-nikolaev": "c:46.97,32.0,9",
    "1919-crimea-sevastopol": "c:44.6,33.52,8",
    # Asia Minor composites: used only to fill districts without their own event (build_events.py), never drawn as a whole
    "1919-06-front-greek-zone": "", "1919-milne-line-zone": "", "1920-autumn-front": "", "1921-07-front": "",
    "1921-09-sakarya-furthest-advance": "", "1921-1922-winter-line": "", "1922-retreat-sequence": "",
    "1920-sevres-smyrna-zone": "tr:İzmir/*;tr:Manisa/Şehzadeler;tr:Manisa/Yunusemre;tr:Manisa/Turgutlu;tr:Manisa/Saruhanlı;tr:Manisa/Gölmarmara;tr:Manisa/Ahmetli;tr:Manisa/Akhisar;tr:Balıkesir/Ayvalık;tr:Balıkesir/Gömeç",
    # ---------------------------------------------------------------- GB4b: Thrace, the islands, the treaties
    "1919-interallied-thrace": WTHRACE + ";" + KARAAGAC,
    "1919-neuilly-western-thrace": WTHRACE + ";" + KARAAGAC,
    "1920-western-thrace-award": WTHRACE,
    "1920-xanthi": "ru:Xanthi",
    "1920-komotini": "ru:Rhodope",
    "1920-alexandroupoli-feres": "m:Alexandroupolis",
    "1920-soufli-didymoteicho": "m:Soufliou;m:Didymoteichou;m:Orestiadas",
    "1920-karagatch": KARAAGAC,
    "1920-karagatch-award": KARAAGAC,
    "1924-western-thrace-de-jure": WTHRACE,
    "1919-eastern-thrace-railway-joint": "pt:41.153,28.617;pt:41.143,28.461;pt:41.172,27.501;pt:41.159,27.8;pt:41.404,27.357;pt:41.267,26.689",
    "1920-rodosto-marmara": "tr:Tekirdağ/*;tr:Constantinople/Silivri;[tr:Constantinople/Çatalca;&box:25,40,28.45,42.2]",
    "1920-adrianople": "tr:Edirne/*;-" + KARAAGAC,
    "1920-kirk-kilisse": "tr:Kırklareli/*",
    "1920-gallipoli": "tr:Çanakkale/Gelibolu;tr:Çanakkale/Eceabat",
    "1922-eastern-thrace-evacuation": E_THRACE,
    "1922-eastern-thrace-allied-interim": E_THRACE,
    "1920-sevres-eastern-thrace": E_THRACE,
    "1918-1923-imbros-greek": "tr:Çanakkale/Imbros",
    "1918-1923-tenedos-greek": "tr:Çanakkale/Tenedos",
    "1920-sevres-imbros-tenedos": "tr:Çanakkale/Imbros;tr:Çanakkale/Tenedos",
    "1919-venizelos-tittoni": "ru:Kos;ru:Kalymnos;ru:Karpathos;m:Symi;m:Tilos;m:Halki",
    "1920-italo-greek-dodecanese": "ru:Kos;ru:Kalymnos;ru:Karpathos;m:Symi;m:Tilos;m:Halki",
    "1924-lausanne-aegean-islands": NE_AEG,
    "1923-lausanne-summary": "",
    "1924-mount-athos": "ru:Mount Athos",
    # ---------------------------------------------------------------- GB5: 1923 to today
    "1923-corfu-italian-occupation": "m:Corfu",
    "1925-petrich-greek-advance": "bg:Petrich;&box:22,41,24,41.385",
    "1940-italian-advance-thesprotia-north-kalamas": "ru:Thesprotia@NKal",
    "1940-italian-bridgehead-igoumenitsa-margariti": "m:Igoumenitsa@SKal",
    "1940-italian-advance-pogoni-kalpaki": "m:Pogoni;&box:20,39.89,21,40.2",
    "1940-italian-konitsa": "m:Konitsa;&box:20,39.9,20.80,40.2",
    "1940-italian-pindus-julia": "[m:Konitsa;&box:20.80,39.9,21.2,40.3];[m:Zagori;&box:20.95,39.9,21.3,40.3];c:40.09,21.04,8",
    "1940-greek-korytsa": "al:Korçë",
    "1940-greek-devoll-bilisht": "al:Devoll",
    "1940-greek-kolonia-erseka-leskoviki": "al:Kolonjë",
    "1940-greek-moschopolis": "c:40.63,20.59,5",
    "1940-greek-pogradets": "al:Pogradec;&box:20,40.6,21,40.96",
    "1940-greek-premeti": "al:Përmet",
    "1940-greek-agioi-saranta": "al:Sarandë",
    "1940-greek-delvino": "al:Delvinë",
    "1940-greek-argyrokastro": "al:Gjirokastër;[al:Tepelenë;&box:19,39,21,40.25]",
    "1940-greek-chimarra": "al:Himarë",
    "1941-greek-klisura": "[poly:klisura;&al:*]",
    "1940-greek-ostravitsa-tomoros": "[poly:ostravice;&al:*]",
    "1941-greek-held-southern-albania-front-line": "[poly:albania_front_1941;&al:*]",
    "1941-greek-withdrawal-albania-capitulation": EPIRUS,
    "1941-german-conquest-eastern-macedonia-thrace": EMAC_E + ";ru:Thasos;" + WTHRACE,
    "1941-1944-bulgarian-zone": EMAC_E + ";ru:Thasos;ru:Xanthi;ru:Rhodope;[m:Alexandroupolis;-box:25.98,40.5,27,41.2];m:Samothrakis",
    "1941-1944-german-evros-strip": "m:Orestiadas;m:Didymoteichou;m:Soufliou;[m:Alexandroupolis;&box:25.98,40.5,27,42]",
    "1941-1944-german-zone-central-macedonia": "ru:Thessaloniki;ru:Chalkidiki;ru:Mount Athos;ru:Kilkis;ru:Pella;ru:Imathia;ru:Pieria;ru:Serres@WStr",
    "1943-1944-bulgarian-troops-central-macedonia": "",  # zone layer inside the German zone; site only
    "1941-1944-western-macedonia": WMAC,
    "1941-1944-thessaly": THESSALY,
    "1941-1944-central-western-greece": CENTRAL,
    "1941-1944-attica-athens-piraeus": ATTICA + ";" + ISLANDS_ATT,
    "1941-1944-peloponnese": PELOP,
    "1941-1944-kythira": "m:Kythira",
    "1941-1944-euboea-skyros": "ru:Euboea",
    "1941-1944-northern-sporades": "ru:Sporades",
    "1941-1944-ionian-islands": "ru:Corfu;ru:Lefkada;ru:Ithaca;ru:Kefalonia;ru:Zakynthos",
    "1941-1944-cyclades": CYCL + ";-m:Milos",
    "1941-1945-milos-german-garrison": "m:Milos",
    "1941-1944-north-aegean-german-islands": "ru:Lemnos;ru:Lesbos;ru:Chios",
    "1941-1943-samos-ikaria-italian": "ru:Samos;ru:Ikaria",
    "1943-samos-allied-interlude": "ru:Samos;ru:Ikaria",
    "1943-1944-samos-ikaria-german": "ru:Samos;ru:Ikaria",
    "1941-1945-crete-chania": "ru:Chania",
    "1941-1944-crete-rethymno-heraklion": "ru:Rethymno;ru:Heraklion",
    "1941-1944-crete-lasithi": "ru:Lasithi",
    "zone-1941-1943-german": "", "zone-1941-1943-italian": "", "zone-1943-1944-german-takeover": "",   # zone layers: site only
    "1941-1942-principality-of-pindus": "", "1944-liberation-sequence": "",
    "1924-1943-dodecanese-italian": "", "1943-1947-kastellorizo-british": "", "1943-1945-dodecanese-german": "",
    "1945-1947-dodecanese-british-administration": "",
    "1947-dodecanese-greek-military-administration": DODEC,
    "1947-dodecanese-de-jure": DODEC,
    "1948-dodecanese-formal-annexation": "",
    "1944-dekemvriana": "ru:Central Athens;ru:North Athens;ru:West Athens;ru:South Athens;ru:Piraeus",
    "1946-1949-greek-civil-war": "", "1947-1949-provisional-democratic-government": "", "1947-1948-dse-konitsa-attack": "",
    "1947-1948-dse-grammos-first": "[poly:grammos;&gr:*]",
    "1947-1949-dse-vitsi": "[poly:vitsi;&gr:*]",
    "1948-1949-dse-grammos-second": "[poly:grammos;&gr:*]",
    "1946-1949-dse-other-mountain-zones": "",
    "1943-1944-free-greece-peea": "", "1946-1947-paris-peace-conference-claims": "", "1949-today-no-further-change": "",
    "1996-imia-crisis": "", "cyprus-never-greek": "",
}

# the 1940-41 Albanian front and its sectors (from the named positions in GB5; approximate, as the research says)
POLYS = {
    # Greek-held southern Albania at its greatest extent (Feb - mid-Apr 1941): the front from the coast north of Himarë by the
    # Kuç saddle, south and east of Tepelenë, the Trebeshinë ridge, the Osum valley in Skrapar, the south of Tomorr, Mali i
    # Ostrovicës, the Devoll valley and the Kamia massif to Lake Ohrid north of Pogradec; closed along the 1941 Greek border
    "albania_front_1941": [(19.64, 40.17), (19.87, 40.19), (19.96, 40.24), (20.0, 40.27), (20.06, 40.31), (20.09, 40.35), (20.14, 40.38),
                           (20.17, 40.47), (20.24, 40.47), (20.17, 40.64), (20.30, 40.60), (20.43, 40.53), (20.52, 40.70), (20.58, 40.95),
                           (20.63, 40.97), (20.75, 41.0), (21.1, 40.9), (21.1, 39.4), (19.9, 39.4), (19.3, 40.1)],
    "klisura": [(20.06, 40.31), (20.09, 40.35), (20.14, 40.38), (20.17, 40.47), (20.24, 40.47), (20.30, 40.40), (20.28, 40.28), (20.15, 40.25), (20.07, 40.27)],
    "ostravice": [(20.24, 40.47), (20.17, 40.64), (20.30, 40.60), (20.43, 40.53), (20.52, 40.62), (20.55, 40.45), (20.40, 40.40), (20.30, 40.42)],
    # Democratic Army mountain bases on the Albanian border (approximate): Grammos and Vitsi
    "grammos": [(20.72, 40.42), (20.85, 40.48), (20.98, 40.45), (21.02, 40.33), (20.92, 40.22), (20.80, 40.20), (20.70, 40.28)],
    "vitsi": [(21.03, 40.82), (21.15, 40.92), (21.30, 40.86), (21.30, 40.70), (21.18, 40.62), (21.05, 40.66)],
}

STATUS = {
    # the Entente presence of 1915-17: Greek administration continued (decided 26 Oct); the National Defence government: a rival
    # Greek government, not a change of the border
    "1915-thessaloniki-entente": "note", "1915-milos-allied": "note", "1915-lesbos-allied-base": "note",
    "1916-corfu-french": "note", "1917-thessaly-french": "note",
    "1916-national-defence-macedonia": "note", "1916-national-defence-islands": "note",
    # Northern Epirus in 1916: the end of Greek control, not an occupation of Greek territory
    "1916-italy-northern-epirus": "note", "1916-bulgaria-korytsa": "note", "1916-france-korytsa": "note",
    # Kastellorizo under France from Dec 1915: the end of Greek control
    "1915-kastellorizo-french": "note",
    # the irregular risings of 1854 and 1878 (bands with Greek officers who had resigned; not the state's forces)
    "1854-epirus-arta-peta": "rising", "1854-epirus-metsovo": "rising", "1854-epirus-north-west": "rising",
    "1854-thessaly-insurgents": "rising", "1854-macedonia-olympus-pindus": "rising", "1854-chalkidiki-athos": "rising",
    "1878-thessaly-insurgents": "rising", "1878-epirus-insurgents": "rising", "1878-agioi-saranta-delvino": "rising",
    "1878-macedonia-olympus-vourinos": "rising",
    # the Allied missions in Eastern Thrace (Oct-Nov 1922) and the Inter-Allied administration of Western Thrace: notes
    "1922-eastern-thrace-allied-interim": "note", "1919-interallied-thrace": "note", "1919-neuilly-western-thrace": "note",
    # the 1897 strips: kept as a site note (no geometry)
    "1897-frontier-rectification-strips": "note", "1881-82-disputed-frontier-points": "note", "1913-armistice-front": "note",
}

DROP = {
    "crete-cretan-state-end": "duplicate of 1898-cretan-state + 1908-crete-union-declared (GB2)",
    "samos-principality-end": "duplicate of 1834-principality-of-samos (GB2); its end date (13 Mar 1913) is used there",
    "1918-1923-imbros-greek": "overlaps 1912-imbros (GB3): Imbros stayed Greek-administered 1912-1923",
    "1918-1923-tenedos-greek": "overlaps 1912-tenedos (GB3): Tenedos stayed Greek-administered 1912-1923",
}

DATES = {
    "1834-principality-of-samos": (None, "1913-03-13"),
    "1912-tenedos": (None, "1923-09-15"),
    "1912-imbros": (None, "1923-09-15"),
    "1912-mount-athos": (None, "1924-08-06"),
    "1922-eastern-thrace-evacuation": (None, "1922-10-31"),
    "1913-dedeagatch": (None, "1913-08-18"), "1913-xanthi": (None, "1913-08-18"), "1913-komotini": (None, "1913-08-18"),
}
WHY = {
    "1834-principality-of-samos": "The principality's government declared union on 24 Nov 1912 but Samos stayed self-governing until the Greek landing of 13 Mar 1913 (GB3).",
    "1912-tenedos": "Greek administration lasted until the island was handed over under the Lausanne settlement (Protocol XV), September 1923; GB3's 12 Nov 1922 is the Mudanya period, not the handover.",
    "1912-imbros": "Handed over with Tenedos in September 1923 (Lausanne, Protocol XV).",
    "1912-mount-athos": "Greek-held from Nov 1912; Greek sovereignty (with the monastic autonomy) recognised at Lausanne (in force 6 Aug 1924).",
    "1922-eastern-thrace-evacuation": "The Greek army stood on the Evros line from 31 Oct 1922 (Gregorian; 18 Oct Julian); the Allied missions then handed Eastern Thrace to Turkey.",
    "1913-dedeagatch": "m:Alexandroupolis;[m:Soufliou;&box:25,40.5,27,41.14]",
    "1913-xanthi": "See 1913-dedeagatch.", "1913-komotini": "See 1913-dedeagatch.",
}

# Ottoman-held strongholds inside revolution-held areas (drawn as small dark rings while they held out)
HOLDOUTS = [
    ("Tripolitsa", 37.510, 22.373, "1821-04-15", "1821-10-05"),
    ("Patras castle", 38.243, 21.743, "1821-04-06", "1828-10-05"),
    ("Rio (Castle of the Morea)", 38.306, 21.783, "1821-04-06", "1828-10-30"),
    ("Methoni", 36.817, 21.705, "1821-04-04", "1828-10-07"),
    ("Koroni", 36.795, 21.958, "1821-04-04", "1828-10-09"),
    ("Navarino", 36.912, 21.697, "1821-04-04", "1821-08-19"),
    ("Monemvasia", 36.687, 23.056, "1821-04-15", "1821-08-04"),
    ("Nafplio", 37.567, 22.801, "1821-04-15", "1822-12-12"),
    ("Acrocorinth", 37.891, 22.871, "1821-04-15", "1822-01-26"),
    ("Acrocorinth", 37.891, 22.871, "1822-07-15", "1823-07-01"),
    ("Acropolis of Athens", 37.972, 23.726, "1821-05-15", "1822-06-22"),
    ("Nafpaktos", 38.393, 21.828, "1821-06-15", "1829-04-15"),
    ("Antirrio", 38.330, 21.769, "1821-06-15", "1829-04-15"),
    ("Vonitsa", 38.920, 20.887, "1821-06-15", "1829-03-05"),
    ("Chalkis", 38.463, 23.594, "1821-05-15", "1823-07-01"),
    ("Karystos", 38.017, 24.420, "1821-05-15", "1823-07-01"),
    ("Chios castle", 38.371, 26.136, "1822-03-15", "1822-04-15"),
    ("Chania", 35.513, 24.018, "1821-06-15", "1824-07-01"),
    ("Souda", 35.489, 24.140, "1821-06-15", "1824-07-01"),
    ("Rethymno", 35.369, 24.474, "1821-06-15", "1824-07-01"),
    ("Heraklion", 35.339, 25.144, "1821-06-15", "1824-07-01"),
    ("Punta (Aktio) fort", 38.952, 20.765, "1832-08-30", "1881-07-06"),
]

DATES["1921-08-sandikli"] = (None, "1921-09-24")
WHY["1921-08-sandikli"] = ("End date unresolved in the research: KTB's 12 Sep 1922 is doubtful, since the Greek right flank rested on the "
                          "Kamalar and Ahır mountains south-west of Afyon after the Sakarya. Drawn until the withdrawal of 24 Sep 1921.")

# fill-ins: districts that the research's snapshots ('front' events) put inside the Greek-held area but that have no event
# of their own. Dates are inferred from the neighbouring districts and are approximate.
_FILL = "Fill-in (editorial): inside the Greek-held area in the research's snapshot{s} ({snap}), with no event of its own; dates inferred from {how}."
EXTRA = [
    dict(id="fill-1920-kiraz-beydag", status="de_facto", start="1920-07", end="1922-09-03", name="Kiraz and Beydağ (upper Küçük Menderes)",
         selector="tr:İzmir/Kiraz;tr:İzmir/Beydağ", confidence="approx",
         editorial=_FILL.format(s="s", snap="1920-autumn-front, 1921-07-front: all the districts of the province of Smyrna", how="the summer 1920 offensive and the Turkish recapture of Ödemiş (3 Sep 1922)")),
    dict(id="fill-1920-guney", status="de_facto", start="1920-07-05", end="1922-09-04", name="Güney (Denizli)",
         selector="tr:Denizli/Güney", confidence="approx",
         editorial=_FILL.format(s="s", snap="1920-autumn-front, 1921-07-front: 'Buldan; Güney (approx.)'", how="Buldan (5 Jul 1920 - 4 Sep 1922)")),
    dict(id="fill-1920-saphane-pazarlar", status="de_facto", start="1920-11-03", end="1922-09-01", name="Şaphane and Pazarlar (Kütahya)",
         selector="tr:Kütahya/Şaphane;tr:Kütahya/Pazarlar", confidence="approx",
         editorial=_FILL.format(s="", snap="1920-autumn-front: 'Simav (from 3 Nov. 1920), Şaphane and Pazarlar (approx.)'", how="Simav and Gediz")),
    dict(id="fill-1921-usak-east", status="de_facto", start="1921-07-13", end="1922-09-01", name="Banaz, Sivaslı and Karahallı (Uşak)",
         selector="tr:Uşak/Banaz;tr:Uşak/Sivaslı;tr:Uşak/Karahallı", confidence="approx",
         editorial=_FILL.format(s="s", snap="1921-07-front and later: all the districts of Uşak; for 1920, not established", how="the July 1921 offensive and the Turkish recapture of Uşak (1 Sep 1922)")),
    dict(id="fill-1921-cal", status="de_facto", start="1921-04-01", end="1922-08-31", name="Çal (Denizli)",
         selector="tr:Denizli/Çal", confidence="approx",
         editorial=_FILL.format(s="s", snap="1921-07-front and later: 'Bekilli, Baklan, Çal (approx.)'", how="Çivril (1 Apr 1921 - 31 Aug 1922)")),
    dict(id="fill-1921-alpu-han", status="de_facto", start="1921-07-19", end="1922-09-02", name="Alpu and Han (Eskişehir), in part",
         selector="tr:Eskişehir/Alpu;tr:Eskişehir/Han", confidence="approx",
         editorial=_FILL.format(s="s", snap="1921-07-front and later: 'Mihalgazi, Sarıcakaya, Alpu, Han (partly, approx.)'", how="Eskişehir (19 Jul 1921 - 2 Sep 1922)")),
    dict(id="fill-1921-sakarya-west", status="de_facto", start="1921-08-14", end="1921-09-20", name="The march to the Sakarya: Beylikova, Mahmudiye, Çifteler, southern Mihalıççık, northern Şuhut",
         selector="tr:Eskişehir/Beylikova;tr:Eskişehir/Mahmudiye;tr:Eskişehir/Çifteler;[tr:Eskişehir/Mihalıççık;&box:30,38,33,39.75];[tr:Afyonkarahisar/Şuhut;&box:29,38.62,32,39.5]",
         confidence="approx", battle="Sakarya",
         editorial=_FILL.format(s="", snap="1921-09-sakarya-furthest-advance", how="the start of the advance (1 Aug Julian = 14 Aug 1921) and the recapture of Sivrihisar (20 Sep 1921)")),
    dict(id="fill-1921-sakarya-east", status="de_facto", start="1921-08-23", end="1921-09-14", name="The Sakarya salient (west of Polatlı and Haymana)",
         selector="[tr:Ankara/Polatlı;&box:31,38,32.08,40.5];[tr:Ankara/Haymana;&box:31,38,32.40,39.6]", confidence="approx", battle="Sakarya",
         editorial=_FILL.format(s="", snap="1921-09-sakarya-furthest-advance: 'the western and southern parts of Polatlı district (Polatlı town not taken) and the western part of Haymana district (Haymana town not taken)'", how="the battle (23 Aug - 13 Sep 1921); the line inside the Sakarya bend is the least certain part of the research")),
    dict(id="fill-1922-iscehisar-west", status="de_facto", start="1921-09-24", end="1922-08-27", name="Western İscehisar (Afyon front)",
         selector="[tr:Afyonkarahisar/İscehisar;&box:29,38,30.74,39.5]", confidence="approx",
         editorial=_FILL.format(s="", snap="1921-1922-winter-line: the western part of İscehisar (approx.)", how="Afyon Karahisar (lost 27 Aug 1922)")),
    dict(id="fill-1912-axios-valley", status="de_facto", start="1912-11-15", end="1913-08-30", name="The Axios valley in Kilkis (Polykastro, Axioupoli, Goumenissa)",
         selector="m:Paionia", confidence="approx",
         editorial="Fill-in (editorial): the research's snapshot of June 1913 (1913-greek-bulgarian-line-june) has the western part of Kilkis regional unit Greek-held on the eve of the Second Balkan War; the date it was first held is not in the research. Start inferred (soon after Thessaloniki, Nov 1912)."),
]

# 'joint' kept for the Allied sectors (Ukraine 1919, the Thracian railway 1919-20, Gallipoli in the Straits zone); not for places the
# Greek army held alone with a passing Allied detachment, or Thessaloniki with a Bulgarian division in the city (1912-13)
JOINT = {"1912-thessaloniki": False, "1919-karaburun": False, "1919-phocaea": False}

DATES["1941-1944-german-evros-strip"] = (None, "1944-10-15")
DATES["1941-1944-crete-rethymno-heraklion"] = (None, "1944-10-15")
DATES["1941-1944-crete-lasithi"] = (None, "1944-10-15")
DATES["1916-skra-salient"] = ("1916-08-17", None)
for _i in ("1941-1944-german-evros-strip", "1941-1944-crete-rethymno-heraklion", "1941-1944-crete-lasithi"):
    WHY[_i] = "The research gives only the year of the end (1944); drawn until mid-October 1944, when the Germans left central and eastern Crete for the Chania enclave and withdrew from Thrace (approximate)."
WHY["1916-skra-salient"] = "The research gives only the year of the start (1916); drawn from the Bulgarian offensive of 17 Aug 1916 (approximate)."

# month-only dates of the 1941 conquest and the 1944-45 liberation, placed so that the order on the map follows the campaign
_APR = "The research gives April 1941 only; drawn from 30 April, after the fall of Athens (27 Apr), when the Axis took over the islands (approximate)."
for _i in ("1941-1944-euboea-skyros", "1941-1944-ionian-islands", "1941-1944-north-aegean-german-islands"):
    DATES[_i] = ("1941-04-30", None); WHY[_i] = _APR
DATES["1941-1944-german-evros-strip"] = ("1941-04-20", "1944-10-15")
WHY["1941-1944-german-evros-strip"] = "The research gives April 1941 and 1944 only; drawn from the division of Thrace on 20 April 1941 (when the Bulgarian army entered) to mid-October 1944 (approximate)."
DATES["1941-1944-western-macedonia"] = (None, "1944-11-02")
WHY["1941-1944-western-macedonia"] = "The research gives November 1944 only; the last German troops left Greek territory by 4 November 1944 (GB5), so drawn until 2 November (approximate)."
DATES["1941-1945-milos-german-garrison"] = (None, "1945-05-09")
WHY["1941-1945-milos-german-garrison"] = "The research gives May 1945 only; drawn until the German surrender in the Aegean (8-9 May 1945; approximate)."
DATES["1941-1945-crete-chania"] = ("1941-05-27", None)
WHY["1941-1945-crete-chania"] = "Drawn from the fall of Chania (27 May 1941), not from the first German landings of 20 May: the Battle of Crete was fought on Greek-held ground until then."

# Mount Athos: held from November 1912; Greek sovereignty, with the monastic autonomy, recognised at Lausanne (in force 6 Aug 1924)
STATUS["1924-mount-athos"] = "de_jure"
WHY["1924-mount-athos"] = ("Greek sovereignty over Mount Athos, with its autonomy, was recognised at Lausanne (in force 6 August 1924); the research "
                           "recorded it as a note, which left Athos undrawn from 1924. Drawn as part of the recognised state from that date.")

# Imia (27 Oct 2026, Iosif: "Imia is Greek. The site does not make this clear."): the islets are Greek territory, part of the Dodecanese.
_IMIA_BASIS = ("Imia is Greek territory, part of the Dodecanese. Turkey renounced the Dodecanese 'and the islets dependent thereon' in favour "
               "of Italy at Lausanne (1923, Art. 15); the Italian-Turkish convention of 4 January 1932 and its protocol of 28 December 1932 "
               "placed Imia on the Italian side of the boundary (point 30 of the protocol); Italy ceded the Dodecanese 'as well as the adjacent "
               "islets' to Greece by the Treaty of Paris (10 February 1947, Art. 14).")
_IMIA_SRC = ("mfa.gr, 'Turkish claims' and 'Zones grises' (Lausanne Art. 15, the 1932 convention and protocol, Art. 14 of the 1947 treaty, the "
             "events of 1995-96); US Congressional Research Service, 'Greece and Turkey: The Rocky Islet Crisis' (report 96-140, 1996); "
             "greekcitytimes.com (the three officers)")
EXTRA.append(dict(
    id="1947-imia", status="de_jure", start="1947-09-15", end=None, name="Imia (Limnia)", selector="c:37.050,27.150,0.12", confidence="exact",
    units=["Imia (Limnia), two uninhabited islets east of Kalymnos (Kalymnos regional unit)"],
    basis=_IMIA_BASIS, signed="1947-02-10", in_force="1947-09-15", handover="1947-03-31 (Greek military administration, with the Dodecanese)",
    event=("Greek with the rest of the Dodecanese. Turkey did not contest this until the crisis of 1995-96, and has disputed it since "
           "(see '1996-imia-crisis'); Greek sovereignty has not changed."),
    sources=_IMIA_SRC, joint=False, joint_with="", occupier="", by_whom="", battle="", line="", date_note="", note="",
    editorial=("Added 27 Oct 2026 so that the atlas shows Imia: the islets (about 0.04 km²) are too small to see at this scale, so they "
               "are marked with a point, in the colour of the Greek state, from the entry into force of the Treaty of Paris.")))
OVERRIDE = {
    "1996-imia-crisis": dict(
        name="The Imia crisis, 1995-96",
        units=["Imia (Limnia), Kalymnos regional unit"],
        basis=_IMIA_BASIS,
        event=("A Turkish freighter ran aground on Imia in late December 1995, and Turkey then claimed the islets. On 27-28 January 1996 "
               "Turkish journalists replaced the Greek flag with a Turkish one, and the Hellenic Navy restored it; on the night of 30-31 January "
               "Turkish commandos landed on the western islet. A Greek navy helicopter crashed during the crisis, killing Christodoulos "
               "Karathanasis, Panagiotis Vlahakos and Ektoras Gialopsos. Both sides withdrew under US mediation on 31 January. Greek "
               "sovereignty did not change."),
        date_note=("From the grounding (26 December 1995 in the Greek Ministry of Foreign Affairs' account; 25 December in the CRS report) "
                   "to the withdrawal of 31 January 1996. The flag was replaced on 27 January (MFA) or 28 January (CRS)."),
        sources=_IMIA_SRC, confidence="exact",
        note=("A note: the map does not change. Imia is drawn as part of Greece from 1947 ('1947-imia'). Turkey's claim, raised in 1996, is "
              "part of its claims to 'gray zones' in the Aegean."),
        editorial=("Rewritten 27 Oct 2026: the first version named the islets by their Turkish name beside the Greek one and described "
                   "Greek sovereignty as a claim.")),
    "1947-dodecanese-de-jure": dict(
        line=("Treaty of Peace with Italy, Art. 14(1): 'Italy hereby cedes to Greece in full sovereignty the Dodecanese Islands indicated "
              "hereafter, namely Stampalia (Astropalia), Rhodes (Rhodos), Calki (Kharki), Scarpanto, Casos (Casso), Piscopis (Tilos), Misiros "
              "(Nisyros), Calimnos (Kalymnos), Leros, Patmos, Lipsos (Lipso), Simi (Symi), Cos (Kos) and Castellorizo, as well as the adjacent "
              "islets.' Art. 14(2): 'These islands shall be and shall remain demilitarised.' (UNTS vol. 49; the Greek Ministry of Foreign "
              "Affairs quotes the same article.)"),
        event="The islands 'became part of Greece on 7 March 1948' (pvgriekenland.nl), when the military administration ended.",
        note="Including Imia (Limnia), east of Kalymnos: see '1947-imia'."),
}
DATES["1996-imia-crisis"] = ("1995-12-26", "1996-01-31")

# Southern Ukraine, 1919 (Iosif, 27 Oct: "What does 'Southern Ukraine' have to do with the borders of Greece. I authorized inclusion of
# information about the Greek Army's activities, not for you to put it into that map"): the five records are notes, not drawn.
for _i in ("1919-ukraine-odessa", "1919-ukraine-odessa-front-berezovka-serbka", "1919-ukraine-kherson", "1919-ukraine-nikolaev", "1919-crimea-sevastopol"):
    STATUS[_i] = "note"
    WHY[_i] = ("Kept as information about the Greek forces' operations, not drawn on the map: Greek troops served under French command in "
               "the Allied intervention of 1919, and Greece held no land of its own there.")

# Western Thrace, 1920 (27 Oct, site audit): the award was carried out (Greek administration from May 1920, the Thrace treaty in force
# 6 Aug 1924), so it is not drawn as "awarded, not carried out": the land is drawn as held from 1920 and as recognized from 1924.
STATUS["1920-western-thrace-award"] = "note"
WHY["1920-western-thrace-award"] = ("The award was carried out: Greek administration from May 1920 and the Thrace treaty in force from "
                                     "6 August 1924. Kept as a note; the land is drawn as held from 1920 and as recognized from 1924.")
