"""Place names in the atlas's text: each place is named as it was called at the time, in its Greek or English form.

Rules (Iosif, 27 Oct 2026: "Imia is Greek", "That name is ahistorical for 1923. Audit all your junk."):
- Greek places keep their Greek names: Imbros, Tenedos, Imia (never the Turkish names of 1970 or the Turkish claim).
- Places the Greeks and the English of the time called by a Greek or European name get that name: Constantinople, Smyrna,
  Adrianople, Prusa, Nicaea, Nicomedia, Magnesia, Philadelphia, Pergamon, Kydonies, Vourla, Krini, Raidestos, Gallipoli;
  Northern Epirus in its Greek forms (Argyrokastro, Korytsa, Agioi Saranta, Delvino, Premeti, Chimarra ...). Turkish names keep their modern spelling, never an old English one (Ankara, not Angora; Aydın, not Aidin).
- Names given later are replaced by the names of the time (Kemalpaşa -> Nif, Turgutlu -> Kasaba, Kırklareli -> Saranta Ekklisies,
  Mustafakemalpaşa -> Kirmasti, Karacabey -> Mihaliç, Orhangazi -> Pazarköy, Emirdağ -> Aziziye, Kırklareli -> Saranta Ekklisies, Blagoevgrad -> Gorna Dzhumaya,
  Razlog -> Mehomia, Gotse Delchev -> Nevrokop, Mykolaiv -> Nikolaev ...).
- Rivers in or on the border of Greece by their Greek names: Evros, Strymon, Nestos, Aoos, Maeander.
- Other places keep their local name of the time (Uşak, Eskişehir, Kütahya, Balıkesir).
- Quotations ('...') and citations (en.wikipedia <title>) are left as they are.
- In the records of Asia Minor and Eastern Thrace the Turkish sources' 'liberated' (the Turkish return) is written 'retaken by
  the Turks', and 'national forces' 'Turkish nationalist forces'.
clean(text, turkey=False) applies all of this; it is idempotent.
"""
import re

L = "A-Za-zÀ-ÖØ-öø-ÿçğıöşüëÇĞİÖŞÜËâîûčšžćđ"          # letters, for word boundaries
def _w(p): return rf"(?<![{L}])(?:{p})(?![{L}])"

# whole phrases first (applied everywhere, quotes included, because they rewrite the research's own wording)
PHRASES = [
    ("Imbros (Gokceada), Tenedos (Bozcaada), Rabbit Islands", "Imbros, Tenedos and the Rabbit Islands"),
    ("Imbros (Gökçeada)", "Imbros"), ("Tenedos (Bozcaada)", "Tenedos"),
    ("Turkey: Gokceada ilce", "Imbros"), ("Bozcaada ilce", "Tenedos"),
    ("Lausanne negotiations on Imroz and Bozcaada", "Lausanne negotiations on Imbros and Tenedos"),
    ("Great Offensive (Battle of Dumlupinar) and Greek retreat", "Battle of Dumlupınar and the Greek retreat"),
    ("Great Offensive / Battle of Dumlupınar", "Battle of Dumlupınar"),
    ("the Turkish Great Offensive", "the Turkish offensive"),
    ("Büyük Menderes", "Maeander"), ("Küçük Menderes", "Kaystros"),
    ("Lake İznik", "the lake of Nicaea"),
    ("Mali i Ostrovicës", "Mount Ostravitsa"), ("Mali i Shëndëllisë", "Mount Shendeli"), ("Mal Shëndëlli", "Mount Shendeli"),
    ("Mali i Trebeshinës", "Mount Trebeshina"),
    ("Ali Butuş/Orvilos (Slavyanka)", "Orvilos (Ali Botush)"),
    ("Gorna Dzhumaya (Blagoevgrad, Bulgarian-held)", "Gorna Dzhumaya (Bulgarian-held)"),
    ("Nevrokop (Gotse Delchev)", "Nevrokop"),
    ("the Razlog (Mehomia) sector (Greek attacks; Razlog not taken)", "the Mehomia sector (Greek attacks; Mehomia not taken)"),
    ("Tiraspol (now Moldova/Transnistria)", "Tiraspol (now Moldova)"),
    ("Maritsa (Evros/Meric)", "Evros"), ("the Evros (Maritsa)", "the Evros"), ("Evros/Maritsa", "Evros"),
    ("'to withdraw from Eastern Thrace as far as the Maritsa River (River Meric)'", "'to withdraw from Eastern Thrace as far as the Maritza'"),
    ("TÜBA says 'Çanakkale' was occupied by 8 July", "TÜBA has Chanak occupied by 8 July"),
    ("Sarandë (Agioi Saranta, 'Porto Edda')", "Agioi Saranta ('Porto Edda' to the Italians)"),
    ("Himarë (Cheimarra) coast", "Chimarra coast"),
    ("Moscopole (Voskopojë)", "Moschopolis"),
    ("Bursa (Prousa)", "Prusa"),
    ("Komotini (Gümülcine)", "Komotini"), ("Komotini / Gumulcine", "Komotini"),
    ("Dedeagatch (Alexandroupoli)", "Dedeağaç (Alexandroupoli)"),
    ("Kirk Kilisse (Kirklareli, Saranta Ekklisies)", "Saranta Ekklisies"), ("Kirk Kilisse (Saranta Ekklisies)", "Saranta Ekklisies"),
    ("Gallipoli peninsula (Kallipolis)", "Gallipoli peninsula"),
    ("(Battle of Himara article; himara.gr)", "(en.wikipedia 'Battle of Himara'; himara.gr)"),
    ("(Kathimerini 9 Dec; Battle of Himara)", "(Kathimerini 9 Dec; en.wikipedia 'Battle of Himara')"),
    (", Kütahya's liberation day", ""),
    ("['Aydın'ın yedi mil kuzeydoğusundaki ... sırtta deniz kıyısında bir noktadan' - the place name", "['seven miles north-east of Aidin', as printed: the place name"),
    ("cf. KTB's 'Alaşehir 21 Haziran 1919' in the 1920 block", "cf. KTB's entry for Philadelphia dated 21 June 1919 in the 1920 block"),
    ("summarises the 1920 result as a 'Bursa-Uşak-Denizli line'", "summarises the 1920 result as a line from Prusa through Uşak to Denizli"),
    ("by mid-1920 the occupation reached a Bursa-Uşak-Denizli line", "by mid-1920 the occupation reached a line from Prusa through Uşak to Denizli"),
    ("for 'Korçë, Bilisht, Kolonja, Opar and Gora'", "for Korytsa, Bilishti, Kolonia, Opar and Gora"),
    ("for 'Korçë, Bilishti, Kolonja, Opar and Gora'", "for Korytsa, Bilishti, Kolonia, Opar and Gora"),
    ("en.wikipedia Great Offensive for Kuşadası, 7 September", "en.wikipedia 'Great Offensive' for Scala Nova, 7 September"),
    ("speaks loosely of a Greek line 'from İzmit to Eskişehir and Kara Hisâr'", "speaks loosely of a Greek line from Nicomedia to Eskişehir and Karahisar"),
    ("Greek advances 'from Bursa and Uşak'", "Greek advances from Prusa and Uşak"),
    ("en.wikipedia Great Offensive: 'the last Greek troops left Cesme' on 16 September 1922", "en.wikipedia 'Great Offensive': the last Greek troops left Krini on 16 September 1922"),
    ("en.wikipedia Battle of Dumlupınar and Great Offensive: III Corps left Erdek", "en.wikipedia 'Battle of Dumlupınar' and 'Great Offensive': III Corps left Artaki"),
    ("the Greek occupation 'started from Tekirdag on July 20, 1920' and was completed 'with the occupation of Kirklareli on 25 July 1920'",
     "the Greek occupation started from Rodosto on 20 July 1920 and was completed with the occupation of Kirk Kilisse on 25 July 1920"),
    ("(the Greek right flank 'rested on the Menderes', AKÜ SBD)", "(the Greek right flank rested on the Maeander, AKÜ SBD)"),
    ("'pushed up the Struma'", "pushed up the Strymon"),
    # the research's first-person working notes, in the atlas's voice
    ("but I could not verify places or dates", "but the places and dates could not be verified"),
    ("I could not verify places or dates", "the places and dates could not be verified"),
    ("I could not verify the days", "the days could not be verified"),
    ("I could not pin the exact landing and departure days from the sources I fetched", "the exact landing and departure days are not in the sources read"),
    ("I believe they stayed Greek, so do not count them in 1864)", "they probably stayed Greek, so they are not counted in 1864)"),
    ("I could not identify Botsi", "Botsi is not identified"),
    ("I could not identify them", "they are not identified"),
    ("THE KEY GAP of this batch", "The main gap in the research"),
    ("a later batch should close this event and open a de_jure one", "the recognition at Lausanne is the record '1924-mount-athos'"),
    ("END IS OUTSIDE THIS BATCH and disputed", "The end date (from a later research batch) is disputed"),
    ("END IS OUTSIDE THIS BATCH", "The end date is from a later research batch"),
    ("Smyrna (İzmir city)", "Smyrna"), ("Smyrna (Izmir city)", "Smyrna"), ("Smyrna (Smyrna city)", "Smyrna"),
    ("Imia / Kardak islets", "Imia (Limnia)"), ("Imia / Imia islets", "Imia (Limnia)"),
    ("Kalymnos regional unit (claimed by Greece as dependencies of Kalymnos; disputed by Turkey)", "Imia (Limnia), Kalymnos regional unit"),
    ("Imia/Kardak islets: see the 1996 note event.", "Imia (Limnia), Greek with the Dodecanese: see '1947-imia'."),
]

# single names, outside quotations and citations
NAMES = [
    # Asia Minor
    ("İzmir|Izmir", "Smyrna"), ("Aidin|Aydin", "Aydın"), ("Manisa", "Magnesia"), ("Alaşehir|Alashehr", "Philadelphia"),
    ("Ayvalık|Ayvalik", "Kydonies"), ("Bergama", "Pergamon"), ("Foça|Foca", "Phocaea"), ("Çeşme|Cesme", "Krini"),
    ("Alaçatı|Alacati", "Alatsata"), ("Urla", "Vourla"), ("Kuşadası|Kusadasi|Skalanova", "Scala Nova"), ("Söke", "Sokia"),
    ("Selçuk", "Ayasoluk"), ("Kemalpaşa|Kemalpasa", "Nif"), ("Turgutlu", "Kasaba"), ("Bursa|Prousa|Brusa", "Prusa"),
    ("İznik|Iznik", "Nicaea"), ("İzmit|Izmit|Ismid", "Nicomedia"), ("Gemlik", "Kios"), ("Orhangazi", "Pazarköy"),
    ("Mustafakemalpaşa|Mustafakemalpasa", "Kirmasti"), ("Karacabey", "Mihaliç"), ("Orhaneli", "Adranos"),
    ("Bandırma|Bandirma", "Panormos"), ("Erdek", "Artaki"), ("Kapıdağ|Kapidag", "Kyzikos"), ("Edremit", "Adramyttion"),
    ("Afyonkarahisar|Afyon(?! Karahisar| Kocatepe)", "Afyon Karahisar"), ("Emirdağ|Emirdag", "Aziziye"), ("Angora", "Ankara"),
    ("Menderes", "Maeander"), ("Bakırçay", "Kaikos"), ("Dumlupinar", "Dumlupınar"), ("Odemis|Odemish", "Ödemiş"),
    ("Bayindir", "Bayındır"), ("Kirkagach", "Kırkağaç"), ("Inonu", "İnönü"),
    # the Straits and Eastern Thrace
    ("Eceabat", "Madytos"), ("Gelibolu|Kallipolis", "Gallipoli"), ("Canakkale|Chanak", "Çanakkale"),
    ("Tekirdağ|Tekirdag|Rodosto|Süleymanpaşa|Suleymanpasa", "Raidestos"), ("Kırklareli|Kirklareli|Kirk Kilisse", "Saranta Ekklisies"),
    ("Luleburgaz|Lule Burgas", "Lüleburgaz"), ("Corlu|Chorlu", "Çorlu"), ("Catalca|Chatalja", "Çatalca"), ("Malkara", "Malgara"),
    ("Enez", "Enos"), ("Edirne", "Adrianople"), ("Karagatch|Karaagac|Karagach", "Karaağaç"), ("Meriç|Meric|Maritsa", "Evros"),
    ("Uzunkopru", "Uzunköprü"), ("Muratli|Muradli", "Muratlı"), ("Hadimkoy", "Hadımköy"), ("Bosnakoy", "Bosnaköy"),
    ("Gökçeada|Gokceada|Imroz", "Imbros"), ("Bozcaada", "Tenedos"), ("Kardak", "Imia"),
    ("Dedeagatch|Dedeagac", "Dedeağaç"), ("Gümülcine|Gumulcine", "Komotini"),
    # Northern Epirus and Albania
    ("Korçë|Korce|Koritsa|Koritza|Korça", "Korytsa"), ("Gjirokastër|Gjirokaster|Gjirokastra|Argirocastro|Argyrokastron", "Argyrokastro"),
    ("Sarandë|Saranda|Santi Quaranta", "Agioi Saranta"), ("Delvinë|Delvina", "Delvino"), ("Tepelenë|Tepelena", "Tepeleni"),
    ("Përmet|Permet", "Premeti"), ("Himarë|Himara|Cheimarra|Chimara", "Chimarra"), ("Kolonjë|Kolonja", "Kolonia"),
    ("Ersekë", "Erseka"), ("Leskovik", "Leskoviki"), ("Pogradec", "Pogradets"), ("Këlcyrë|Kleisoura", "Klisura"),
    ("Voskopojë|Voskopoja|Moscopole", "Moschopolis"), ("Vlorë|Vlore|Vlora|Valona", "Avlona"), ("Libohovë|Libohova", "Libochovo"),
    ("Konispol", "Konispoli"), ("Bilisht", "Bilishti"), ("Dropull", "Dropoli"), ("Vjosë|Vjosa", "Aoos"), ("Drino", "Drinos"),
    ("Tomorr", "Tomoros"), ("Trebeshinë|Trebeshinës", "Trebeshina"), ("Ostravicë|Ostrovicës|Ostravice|Ostrovicë", "Ostravitsa"),
    ("Shëndëlli|Shëndëllisë", "Shendeli"), ("Nemërçkë", "Nemercka"), ("Lëkurës", "Lekuresi"), ("Bubës", "Bubesi"),
    ("Shushicë", "Shushitsa"), ("Lukovë", "Lukovo"), ("Kapshticë", "Kapeshtitsa"), ("Frashër", "Frasheri"), ("Finiq", "Finiki"),
    ("Gjashtë", "Gjashta"),
    # Bulgaria, Macedonia, Ukraine
    ("Blagoevgrad", "Gorna Dzhumaya"), ("Gotse Delchev", "Nevrokop"), ("Razlog", "Mehomia"), ("Sandanski", "Sveti Vrach"),
    ("Struma", "Strymon"), ("Mesta", "Nestos"), ("Belasica|Belasitsa", "Beles"), ("Bitola", "Monastir"), ("Gevgelija", "Gevgeli"),
    ("Mykolaiv", "Nikolaev"), ("Odesa", "Odessa"), ("Berezivka", "Berezovka"), ("Feodosiya", "Feodosia"), ("Bilozerka", "Belozerka"),
    ("Hryhoriv", "Grigoriev"), ("Kajmakčalan|Kajmakcalan", "Kaimaktsalan"), ("Kožuf|Kozuf", "Tzena"),
]
_NAMES = [(re.compile(_w(p)), r) for p, r in NAMES]

# the Turkish sources' perspective, in the records of Asia Minor and Eastern Thrace
TURKEY = [
    (r"liberated by Turkish national forces", "retaken by Turkish nationalist forces"),
    (r"Turkish national forces", "Turkish nationalist forces"),
    (r"\bwas liberated\b", "was retaken by the Turks"),
    (r"\bLiberated\b", "Retaken by the Turks"),
    (r"\bliberated\b", "retaken by the Turks"),
    (r"\bthe liberation of\b", "the Turkish recapture of"),
    (r"\bliberation\b", "recapture"),
    (r"\bLiberation\b", "Recapture"),
]
_TURKEY = [(re.compile(p), r) for p, r in TURKEY]

_PROTECT = re.compile(r"(?<![\w])'[^'\n]{2,}?'(?![\w])|\b(?:en|el|tr|de|fr)\.wikipedia(?: [A-Z0-9][^;,()'\n]*)?")

# American spelling (Iosif, 27 Oct: "don't use English spelling ever"); quotations and titles are left as they are
_US_STEMS = ("recogn", "organ", "author", "mobil", "neutral", "stabil", "summar", "formal", "demilitar", "militar", "Bulgarian", "Italian",
             "real", "central", "decentral", "colon", "legal", "national", "internation", "Hellen", "character", "critic", "minim", "normal",
             "special", "util", "civil", "modern", "symbol", "final", "prior", "maxim", "jeopard", "fertil", "apolog", "emphas", "sympath")
_US_IZE = re.compile(r"\b((?:" + "|".join(_US_STEMS) + r"))is(e|ed|es|ing|ation|ations)\b", re.I)
_US_WORDS = [("colour", "color"), ("favour", "favor"), ("harbour", "harbor"), ("honour", "honor"), ("labour", "labor"), ("neighbour", "neighbor"),
             ("behaviour", "behavior"), ("armour", "armor"), ("rumour", "rumor"), ("endeavour", "endeavor"), ("vigour", "vigor"),
             ("centre", "center"), ("kilometre", "kilometer"), ("metre", "meter"), ("theatre", "theater"), ("defence", "defense"),
             ("offence", "offense"), ("licence", "license"), ("labelled", "labeled"), ("labelling", "labeling"), ("modelled", "modeled"),
             ("travelled", "traveled"), ("travelling", "traveling"), ("cancelled", "canceled"), ("signalled", "signaled"), ("totalled", "totaled"),
             ("grey", "gray"), ("programme", "program"), ("catalogue", "catalog"), ("amongst", "among"), ("whilst", "while"), ("piastre", "piaster"),
             ("manoeuvre", "maneuver"), ("judgement", "judgment"), ("ageing", "aging"), ("sceptic", "skeptic"), ("plough", "plow"),
             ("analyse", "analyze"), ("analysed", "analyzed"), ("paralyse", "paralyze"), ("fulfil", "fulfill"), ("enrol", "enroll")]
_US_RX = [(re.compile(r"\b" + a + r"(s|d|ed|ing|r|rs)?\b", re.I), b) for a, b in _US_WORDS]
def _case(src, rep): return rep[0].upper() + rep[1:] if src[0].isupper() else rep
def us(seg):
    seg = _US_IZE.sub(lambda m: m.group(1) + "iz" + m.group(2), seg)
    for rx, b in _US_RX:
        seg = rx.sub(lambda m: _case(m.group(0), b) + ("ed" if m.group(1) == "d" and b.endswith("er") else (m.group(1) or "")), seg)
    seg = re.sub(r"\b(Greek|Hellenic) (army|navy)\b", lambda m: m.group(1) + " " + m.group(2).capitalize(), seg)
    return seg
def us_text(s):
    """American spelling outside quotations, for the site's own texts"""
    if not isinstance(s, str) or not s: return s
    out, pos = [], 0
    for m in _PROTECT.finditer(s):
        out.append(us(s[pos:m.start()])); out.append(m.group(0)); pos = m.end()
    out.append(us(s[pos:]))
    return "".join(out)

def _names(seg):
    for rx, r in _NAMES: seg = rx.sub(r, seg)
    return us(seg)

def _dedupe(s):
    s = re.sub(rf"(?<![{L}])([A-Z][{L}' ]{{1,40}}?) \(\1\)", r"\1", s)            # 'Smyrna (Smyrna)'
    s = re.sub(rf"(?<![{L}])([A-Z][{L}]+)(?: ?/ ?\1)+(?![{L}])", r"\1", s)          # 'Evros/Evros'
    s = re.sub(rf"(?<![{L}])([A-Z][{L}]+) \(\1, ", r"\1 (", s)                       # 'Mehomia (Mehomia, '
    return s

def clean(s, turkey=False):
    if not isinstance(s, str) or not s: return s
    for a, b in PHRASES: s = s.replace(a, b)
    out, pos = [], 0
    for m in _PROTECT.finditer(s):
        out.append(_names(s[pos:m.start()])); out.append(m.group(0)); pos = m.end()
    out.append(_names(s[pos:]))
    s = _dedupe("".join(out))
    s = s.replace("Istanbul", "Constantinople").replace("İstanbul", "Constantinople")
    if turkey:
        for rx, r in _TURKEY: s = rx.sub(r, s)
    return s

# the sources: titles are cited as they are; only the research's own descriptions are changed
SOURCE_PHRASES = [
    ("list of 1922 liberation dates", "list of the dates of the Turkish recapture, 1922"),
    ("chapter on the occupation and liberation of Alasehir", "chapter on Philadelphia, 1920-22"),
    ("general knowledge (en.wikipedia Imia/Kardak not fetched: not in the URL list or search results)",
     "general knowledge (the atlas replaces this record's text with the Greek Ministry of Foreign Affairs and the CRS report: see mapping.OVERRIDE)"),
    ("(Bandırma liberation day)", "(the date of the Turkish recapture of Panormos)"),
    ("(King Alexander visited Dedeagac after Tekirdag in July 1920, renamed Alexandroupolis)",
     "(King Alexander visited Dedeağaç after Raidestos in July 1920; the town was renamed Alexandroupolis)"),
    ("('the occupation of Karaagac by the IX Infantry Division followed (16 May)')", "('the occupation of Karaağaç by the IX Infantry Division followed (16 May)')"),
    ("('the occupation of Karagatch by the IX Infantry Division followed (16 May)')", "('the occupation of Karaağaç by the IX Infantry Division followed (16 May)')"),
    ("('only 16 km from Vlorë')", "(16 km from Avlona)"),
    ("(Korçë fighting 22-27 March 1914)", "(fighting at Korytsa, 22-27 March 1914)"),
]
TITLES = ["'Ege ve Izmir'in kurtulusu'", "'9 Eylul ve Izmir'in kurtulusu'", "en.wikipedia Karaagac, Edirne", "Milli Mucadelede Manisa",
          "Manisa Buyuksehir Bel.", "Edirne-Kirklareli-Tekirdag", "'Edirne isgal altinda'"]
_SPROTECT = re.compile("|".join(map(re.escape, TITLES)) + r"|(?<![\w])'[^'\n]{2,}?'(?![\w])|\b(?:en|el|tr|de|fr)\.wikipedia(?: [A-Z0-9][^;,()'\n]*)?|"
                       r"\bBattle of [A-Z][^;,()'\n]*|\S+\.(?:gov|edu|org|com|gr|rs)\.?\S*")

def clean_sources(s):
    if not isinstance(s, str) or not s: return s
    for a, b in PHRASES + SOURCE_PHRASES: s = s.replace(a, b)
    out, pos = [], 0
    for m in _SPROTECT.finditer(s):
        out.append(_names(s[pos:m.start()])); out.append(m.group(0)); pos = m.end()
    out.append(_names(s[pos:]))
    return _dedupe("".join(out))

def clean_any(v, turkey=False):
    if isinstance(v, str): return clean(v, turkey)
    if isinstance(v, list): return [clean_any(x, turkey) for x in v]
    if isinstance(v, dict): return {k: clean_any(x, turkey) for k, x in v.items()}
    return v
