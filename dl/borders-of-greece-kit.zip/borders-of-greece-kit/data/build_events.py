"""Normalise the research events (GB1-GB5) and give each one its geometry.

Writes data/events.json (normalised records, no geometry), data/geom.pkl (id -> shapely geometry, full resolution) and a report
of what was parsed. Turkish district events without an entry in mapping.SEL are parsed from their 'units' strings.
usage: python3 build_events.py [report]
"""
import json, re, sys, pickle, datetime as dt
sys.path.insert(0, "/home/claude/gb/geo"); sys.path.insert(0, "/home/claude/gb/data")
import pieces as P
import mapping as M
import names as N
from sel_auto import SEL_AUTO
from shapely.geometry import Polygon

R = "/home/claude/gb/research"
FILES = ["GB1", "GB2", "GB3", "GB4a", "GB4b", "GB5"]
for k, v in M.POLYS.items():
    P.POLYS[k] = Polygon(v).buffer(0)

ALIAS = {("Kütahya", "Gediz"): "Gediz Merkez", ("Çanakkale", "Ayvacık"): "Ayvacik", ("Çanakkale", "Imbros"): "Imbros"}
PROVS = sorted({p for p, d in P.TUR}, key=len, reverse=True)

def parse_tr(units):
    """district selectors from strings such as 'Manisa province: Şehzadeler and Yunusemre districts (...)'"""
    out = []
    for u in units:
        u2 = u.replace("Afyonkarahisar (Merkez İlçe)", "AFYMERKEZ")
        prov = next((p for p in PROVS if u2.startswith(p + " province") or u2.startswith("Turkey: " + p)), None)
        if not prov: continue
        dists = sorted({d for p, d in P.TUR if p == prov}, key=len, reverse=True)
        body = u2.split(":", 1)[1] if ":" in u2 else u2
        found = []
        for d in dists:
            dd = "AFYMERKEZ" if d == "Afyonkarahisar (Merkez İlçe)" else d
            if re.search(r"(?<![\wçğıöşüÇĞİÖŞÜ])" + re.escape(dd) + r"(?![\wçğıöşüÇĞİÖŞÜ])", body):
                found.append(d); body = body.replace(dd, "#")
        for (p, a), d in ALIAS.items():
            if p == prov and re.search(r"\b" + re.escape(a) + r"\b", body): found.append(d)
        out += [f"tr:{prov}/{d}" for d in found]
    return ";".join(dict.fromkeys(out))

def iso(d, kind):
    """'YYYY-MM-DD' | 'YYYY-MM' | 'YYYY' -> (date, precision); month-only and year-only dates go to the middle of the period"""
    if d is None: return None, None
    d = str(d)
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", d): return d, "day"
    if re.fullmatch(r"\d{4}-\d{2}", d): return d + "-15", "month"
    if re.fullmatch(r"\d{4}", d): return d + "-07-01", "year"
    m = re.match(r"(\d{4}-\d{2}-\d{2})", d)
    if m: return m.group(1), "day"
    raise ValueError(d)

def is_turkey(rec):
    """records of Asia Minor and Eastern Thrace, where the Turkish sources' wording is changed (names.TURKEY)"""
    return "tr:" in (rec.get("selector") or "") or (rec.get("batch") == "GB4a" and not any(k in rec["id"] for k in ("ukraine", "crimea")))

def textfix(rec):
    """house style for the research's text (names.py): the names of the time, in their Greek or English form; Constantinople,
    not Istanbul. Ids and selectors are left alone; in the sources only the fixed phrases are changed (titles are cited as they are)."""
    tk = is_turkey(rec)
    for k in list(rec):
        if k in ("id", "selector", "batch", "status", "status_research", "start", "end", "start_precision", "end_precision", "points", "joint", "geo"): continue
        if k == "sources":
            rec[k] = N.clean_sources(rec[k])
        else:
            rec[k] = N.clean_any(rec[k], tk)
    for k, v in M.OVERRIDE.get(rec["id"], {}).items(): rec[k] = [N.us_text(x) for x in v] if isinstance(v, list) else N.us_text(v)
    return rec

GEO = {"de_jure", "de_facto", "awarded", "occupied", "autonomous", "rising", "insurgent"}

def build():
    events, geoms, report = [], {}, []
    for f in FILES:
        for e in json.load(open(f"{R}/{f}.json")):
            i = e["id"]
            if i in M.DROP: report.append(f"DROP {i}: {M.DROP[i]}"); continue
            st = M.STATUS.get(i, e["status"])
            s0, e0 = M.DATES.get(i, (None, None))
            start, sp = iso(s0 or e["start"], "start")
            end, ep = iso(e0 or e["end"], "end") if (e0 or e["end"]) else (None, None)
            if end and start > end and sp == "month": start = start[:8] + "01"     # a month-only start in the month the event ended
            sel = M.SEL.get(i)
            if sel is None: sel = SEL_AUTO.get(i)
            if sel is None:
                sel = parse_tr(e["area"].get("units") or [])
                report.append(f"AUTO {i}: {sel}")
                if not sel: report.append(f"  !! no selector for {i} ({st})")
            rec = {"id": i, "batch": f, "status": st, "status_research": e["status"], "start": start, "start_precision": sp,
                   "end": end, "end_precision": ep, "name": e["area"].get("name"), "confidence": e["area"].get("confidence"),
                   "units": e["area"].get("units"), "line": e["area"].get("line"), "points": e["area"].get("points"),
                   "selector": sel, "joint": M.JOINT.get(i, e.get("joint", False)), "joint_with": e.get("joint_with", ""),
                   "occupier": e.get("occupier", ""), "by_whom": e.get("by_whom", ""), "battle": e.get("battle", ""),
                   "basis": e.get("basis", ""), "event": e.get("event", ""), "signed": e.get("signed"), "in_force": e.get("in_force"),
                   "handover": e.get("handover"), "date_note": e.get("date_note", ""), "sources": e.get("sources", ""),
                   "note": e.get("note", ""), "editorial": M.WHY.get(i, "")}
            textfix(rec)
            if st != e["status"]: rec["editorial"] = (rec["editorial"] + " " if rec["editorial"] else "") + f"Status changed from '{e['status']}' to '{st}'."
            if sel:
                try:
                    g = P.select(sel)
                    if g.is_empty: report.append(f"  !! empty geometry for {i}: {sel}")
                    geoms[i] = g
                except Exception as ex:
                    report.append(f"  !! {i}: {sel}: {ex!r}")
            events.append(rec)
    for x in getattr(M, "EXTRA", []):
        rec = dict(x); i = rec["id"]
        rec["start"], rec["start_precision"] = iso(rec["start"], "start")
        rec["end"], rec["end_precision"] = iso(rec["end"], "end") if rec.get("end") else (None, None)
        rec.setdefault("batch", "editorial")
        textfix(rec)
        geoms[i] = P.select(rec["selector"]); events.append(rec)
        report.append(f"EXTRA {i}: {rec['selector']}")
    return events, geoms, report

if __name__ == "__main__":
    ev, gm, rep = build()
    json.dump(ev, open("/home/claude/gb/data/events.json", "w"), ensure_ascii=False, indent=1)
    pickle.dump(gm, open("/home/claude/gb/data/geom.pkl", "wb"))
    from collections import Counter
    print(len(ev), "events;", Counter(e["status"] for e in ev))
    print("\n".join(r for r in rep if (len(sys.argv) > 1 or "!!" in r or r.startswith("DROP"))))
