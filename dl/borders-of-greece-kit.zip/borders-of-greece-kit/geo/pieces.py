"""The geometry registry for the Borders of Greece: present-day units (Greek municipalities with their regional units,
Albanian districts, Bulgarian obshtini, Turkish ilce with their provinces, Ukrainian raions) plus the splits that the
historical lines need (the 1832 line, the Arachthos, the Spercheios, the Achelous, the Struma, the Evros at Karaagac,
the Kalamas, Himare) and small custom shapes (circles, the Petrich strip). select(expr) returns a shapely geometry.

Selector syntax (terms separated by ';', a leading '-' subtracts):
  ru:Larissa        a Greek regional unit (short name)       m:Elassona     a Greek municipality (geoBoundaries name)
  ru:Arta@E / @W    east / west of the Arachthos              m:X@S1832 / @N1832   south / north of the 1832 line
  m:X@SSp / @NSp    south / north of the Spercheios           m:X@EAch / @WAch     east / west of the Achelous
  m:X@EStr / @WStr  east / west of the Struma                 m:X@NKal / @SKal     north / south of the Kalamas
  al:Sarandë        an Albanian district (al:Himarë = the Himarë coast, cut from Vlorë)
  bg:Petrich        a Bulgarian obshtina                      tr:Province/District  (tr:Province/* = the whole province)
  tr:Edirne/Edirne merkez@W   the Karaagac triangle west of the Evros
  ua:Name           a Ukrainian raion                         c:lat,lon,km   a circle
  poly:name         a custom polygon (POLYS)            box:x0,y0,x1,y1  a lon/lat box (use with '&' to clip)
  pt:lat,lon        a point marker (a 0.8 km circle)
Terms: 'a; b' union, '-b' subtract, '&b' intersect (applied left to right); [ ... ] groups a sub-expression; gr:* and al:* = all of Greece / Albania.
"""
import json, re, math, os, functools
from shapely.geometry import shape, Point, Polygon, LineString, box, mapping
from shapely.ops import unary_union, split, linemerge
G = "/home/claude/gb/geo"
O = "/home/claude/gb/osm"

def _load(f):
    return json.load(open(os.path.join(G, f)))["features"]

# ---------------------------------------------------------------- Greece
_ru = json.load(open(os.path.join(G, "gr_muni_ru.json")))
MUNI, MRU = {}, {}
for f in _load("GRC-ADM3.geojson"):
    sid, n = f["properties"]["shapeID"], f["properties"]["shapeName"]
    g = shape(f["geometry"]).buffer(0)
    MUNI[n] = unary_union([MUNI[n], g]) if n in MUNI else g
    MRU[n] = _ru[sid][1]
def _rushort(s):
    s = re.sub(r"\s*[Rr]egional [Uu]nit", "", s).strip()
    return {"Argolida": "Argolis", "Evritania": "Evrytania", "Kos": "Kos", "Karpathos-Kasos": "Karpathos"}.get(s, s)
RU = {}
for n, r in MRU.items():
    RU.setdefault(_rushort(r), []).append(n)

# ---------------------------------------------------------------- lines
RIV = json.load(open(os.path.join(O, "rivers_main.geojson")))
def _river(name):
    g = shape(RIV[name])
    if g.geom_type == "MultiLineString":
        m = linemerge(g)
        if m.geom_type == "MultiLineString":   # keep the longest chain
            m = max(m.geoms, key=lambda x: x.length)
        g = m
    return g
def _extend(line, d=0.3):
    c = list(line.coords)
    def ext(p, q):
        dx, dy = p[0] - q[0], p[1] - q[1]; L = math.hypot(dx, dy) or 1
        return (p[0] + dx / L * d, p[1] + dy / L * d)
    return LineString([ext(c[0], c[1])] + c + [ext(c[-1], c[-2])])

def _line_1832():
    """the land border of the 1832 kingdom (OpenHistoricalMap), from the Gulf of Arta to the Gulf of Volos"""
    oh = json.load(open(os.path.join(O, "ohm_greece_1832_1881.geojson")))["1832-05-07"]
    mp = shape(oh)
    main = max(mp.geoms, key=lambda p: p.area) if mp.geom_type == "MultiPolygon" else mp
    xy = list(main.exterior.coords)
    # the land border: points with lat > 38.85 between lon 20.8 and 23.1 that are inland (not on the coast)
    land = unary_union([MUNI[n] for n in MUNI])
    pts = [p for p in xy if 38.8 < p[1] < 39.35 and 20.7 < p[0] < 23.2]
    return main, pts
MAIN1832, _pts1832 = _line_1832()

def _sidepoly(line, side, far=4.0):
    """the half-plane on one side of a river: the river line, extended straight beyond its two ends (north/south for a
    river that runs N-S, east/west for one that runs E-W), closed far away on the requested side ('E','W','N','S')"""
    c = list(line.coords)
    if side in ("E", "W"):
        if c[0][1] < c[-1][1]: c = c[::-1]                     # first point = north end
        a, b = c[0], c[-1]; sx = far if side == "E" else -far
        ring = [(a[0], a[1] + far)] + c + [(b[0], b[1] - far), (b[0] + sx, b[1] - far), (a[0] + sx, a[1] + far)]
    else:
        if c[0][0] > c[-1][0]: c = c[::-1]                     # first point = west end
        a, b = c[0], c[-1]; sy = far if side == "N" else -far
        ring = [(a[0] - far, a[1])] + c + [(b[0] + far, b[1]), (b[0] + far, b[1] + sy), (a[0] - far, a[1] + sy)]
    from shapely.validation import make_valid
    p = make_valid(Polygon(ring))
    if p.geom_type == "GeometryCollection": p = unary_union([q for q in p.geoms if q.geom_type in ("Polygon", "MultiPolygon")])
    return p
def _halves(geom, line, side):
    sp = _sidepoly(line, side)
    return geom.intersection(sp), geom.difference(sp)

@functools.lru_cache(None)
def gr_split(kind, name, how):
    g = MUNI[name] if kind == "m" else unary_union([MUNI[m] for m in RU[name]])
    if how in ("S1832", "N1832"):
        s = g.intersection(MAIN1832.buffer(0.003)); n = g.difference(MAIN1832.buffer(0.003))
        # keep the coast: the OHM polygon's coast is coarse, so only the land border is used: parts north of lat 38.8
        n = unary_union([p for p in getattr(n, "geoms", [n]) if p.representative_point().y > 38.85 and p.area > 1e-5]) if not n.is_empty else n
        s = g.difference(n)
        return s if how == "S1832" else n
    lines = {"E": ("Arachthos", "E"), "W": ("Arachthos", "W"),
             "SSp": ("Spercheios", "S"), "NSp": ("Spercheios", "N"),
             "EAch": ("Acheloos", "E"), "WAch": ("Acheloos", "W"),
             "EStr": ("Struma", "E"), "WStr": ("Struma", "W"),
             "NKal": ("Kalamas", "N"), "SKal": ("Kalamas", "S")}
    rv, sd = lines[how]
    a, _ = _halves(g, _river(rv), sd)
    return a

# ---------------------------------------------------------------- neighbours
ALB = {}
for f in _load("ALB-ADM2.geojson"):
    n = f["properties"]["shapeName"]; g = shape(f["geometry"]).buffer(0)
    if n == "Kuçovë" and g.representative_point().x > 20.3: n = "Korçë"   # mislabelled in geoBoundaries
    ALB[n] = unary_union([ALB[n], g]) if n in ALB else g
HIMARE = Polygon([(19.52, 40.255), (19.62, 40.215), (19.66, 40.175), (19.78, 40.13), (19.86, 40.085), (19.94, 40.02),
                  (19.99, 39.985), (19.93, 39.96), (19.85, 40.02), (19.76, 40.07), (19.66, 40.11), (19.58, 40.15), (19.47, 40.2)])
ALB["Himarë"] = ALB["Vlorë"].intersection(HIMARE.buffer(0.01))
ALB["Vlorë-north"] = ALB["Vlorë"].difference(ALB["Himarë"])
BGR = {f["properties"]["shapeName"]: shape(f["geometry"]).buffer(0) for f in _load("BGR-ADM2.geojson")}
UKR = {}
for f in _load("UKR-ADM2.geojson"):
    UKR.setdefault(f["properties"]["shapeName"], []).append(shape(f["geometry"]).buffer(0))
_tprov = [(f["properties"]["shapeName"], shape(f["geometry"]).buffer(0)) for f in _load("TUR-ADM1.geojson")]
TUR = {}
for f in _load("TUR-ADM2.geojson"):
    g = shape(f["geometry"]).buffer(0); p = g.representative_point()
    prov = next((n for n, pg in _tprov if pg.contains(p)), "?")
    TUR[(prov, f["properties"]["shapeName"])] = g
# the names used in this atlas for two keys of the dataset: Tenedos (geoBoundaries 'Bozcaada') and Constantinople ('İstanbul')
TUR[("Çanakkale", "Tenedos")] = TUR.pop(("Çanakkale", "Bozcaada"))
for _k in [k for k in TUR if k[0] == "İstanbul"]: TUR[("Constantinople", _k[1])] = TUR.pop(_k)
def _karaagac():
    g = TUR[("Edirne", "Edirne merkez")]
    a, _ = _halves(g, _river("Evros"), "W")
    return a
POLYS = {}
def circle(lat, lon, km):
    return Point(lon, lat).buffer(km / (111.0 * math.cos(math.radians(lat))), 32).intersection(
        Point(lon, lat).buffer(km / 111.0 * 1.6, 32))   # an ellipse that is round on the ground

def _split(expr):
    """split on ';' outside [brackets]"""
    out, depth, cur = [], 0, ""
    for ch in expr:
        if ch == "[": depth += 1
        elif ch == "]": depth -= 1
        if ch == ";" and depth == 0: out.append(cur); cur = ""
        else: cur += ch
    out.append(cur)
    return [t.strip() for t in out if t.strip()]

@functools.lru_cache(None)
def _gr_all():
    return unary_union(list(MUNI.values()))
@functools.lru_cache(None)
def _al_all():
    return unary_union([g for n, g in ALB.items() if n not in ("Himarë", "Vlorë-north")])

def select(expr):
    out = Polygon()
    for term in _split(expr):
        op = term[0] if term[0] in "-&" else "+"; term = term.lstrip("-&").strip()
        if term.startswith("["):
            g = select(term[1:-1])
            out = out.difference(g) if op == "-" else out.intersection(g) if op == "&" else unary_union([out, g])
            continue
        kind, _, val = term.partition(":")
        val = val.strip(); g = None
        if kind in ("m", "ru"):
            name, _, how = val.partition("@")
            if how: g = gr_split(kind, name, how)
            elif kind == "m": g = MUNI[name]
            else: g = unary_union([MUNI[m] for m in RU[name]])
        elif kind == "gr":
            g = _gr_all()
        elif kind == "al":
            g = _al_all() if val == "*" else ALB[val]
        elif kind == "bg":
            g = BGR[val]
        elif kind == "ua":
            g = unary_union(UKR[val])
        elif kind == "tr":
            prov, _, dist = val.partition("/")
            if dist == "*": g = unary_union([v for (p, d), v in TUR.items() if p == prov])
            elif dist.endswith("@W"): g = _karaagac()
            else:
                keys = [k for k in TUR if k[0] == prov and k[1] == dist]
                if not keys: raise KeyError(val)
                g = unary_union([TUR[k] for k in keys])
        elif kind == "c":
            la, lo, km = map(float, val.split(",")); g = circle(la, lo, km)
        elif kind == "poly":
            g = POLYS[val]
        elif kind == "box":
            x0, y0, x1, y1 = map(float, val.split(",")); g = box(x0, y0, x1, y1)
        elif kind == "pt":
            la, lo = map(float, val.split(",")[:2]); g = circle(la, lo, 0.8)
        else:
            raise KeyError(term)
        out = out.difference(g) if op == "-" else out.intersection(g) if op == "&" else unary_union([out, g])
    return out

if __name__ == "__main__":
    print(len(MUNI), "municipalities in", len(RU), "regional units")
    print(sorted(RU))
    for e in ["ru:Arta@E", "ru:Arta@W", "m:Domokos@N1832", "m:Lamia@NSp", "ru:Serres@EStr", "tr:Edirne/Edirne merkez@W", "al:Himarë", "tr:İzmir/*"]:
        g = select(e); print(e, g.geom_type, round(g.area, 4), [round(v, 2) for v in g.bounds])
