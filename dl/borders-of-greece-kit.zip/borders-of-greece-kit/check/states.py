import sys; sys.path.insert(0, "/home/claude/gb/data")
import timeline as T, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, json
from shapely.geometry import shape
land = [shape(f["geometry"]) for f in json.load(open("/home/claude/gb/geo/ne_10m_admin_0_countries.geojson"))["features"]
        if f["properties"].get("ADM0_A3") in ("GRC","ALB","MKD","BGR","TUR","CYP","SRB","ROU","UKR","MDA","RUS","XKX","KOS","MNE","GEO","SYR","ITA")]
COL = dict(dj="#2f6db3", df="#7fb0e6", dfj="#b9a0e6", occ="#9a9a9a", aut="#bfe3c2", ris="#f0c080", ins="#d07070")
def draw(ax, g, **kw):
    for p in getattr(g, "geoms", [g]):
        if p.geom_type != "Polygon" or p.is_empty: continue
        x, y = p.exterior.xy; ax.fill(x, y, **kw)
dates = sys.argv[1].split(",")
bb = [float(v) for v in sys.argv[2].split(",")] if len(sys.argv) > 2 else [19, 34.5, 30.5, 42]
n = len(dates); cols = 4; rows = (n + cols - 1) // cols
fig, axs = plt.subplots(rows, cols, figsize=(cols * 5, rows * 4.2))
for ax, d in zip(axs.flat, dates):
    c, hold, ids = T.state(d)
    for g in land: draw(ax, g, color="#eeeae0", lw=0)
    for k in ["aut", "ris", "ins", "dj", "df", "dfj", "occ"]:
        draw(ax, c[k], color=COL[k], lw=0)
    a = c["awd"]
    for p in getattr(a, "geoms", [a]):
        if p.geom_type == "Polygon" and not p.is_empty:
            x, y = p.exterior.xy; ax.plot(x, y, color="#c03030", lw=0.8, ls="--")
    for n_, la, lo in hold: ax.plot(lo, la, "ko", ms=3)
    ax.set_xlim(bb[0], bb[2]); ax.set_ylim(bb[1], bb[3]); ax.set_title(d, fontsize=10); ax.set_aspect(1.3); ax.set_xticks([]); ax.set_yticks([])
for ax in list(axs.flat)[n:]: ax.axis("off")
plt.tight_layout(); plt.savefig(sys.argv[3] if len(sys.argv) > 3 else "/home/claude/gb/check/states.png", dpi=70)
