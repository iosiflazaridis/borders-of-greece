import sys; sys.path.insert(0, "/home/claude/gb/geo")
import pieces as P, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from shapely.geometry import box
def draw(ax, g, **kw):
    for p in getattr(g, "geoms", [g]):
        if p.geom_type != "Polygon" or p.is_empty: continue
        x, y = p.exterior.xy; ax.fill(x, y, **kw)
def outline(ax, bb):
    B = box(*bb)
    for n, g in P.MUNI.items():
        if g.intersects(B):
            for p in getattr(g, "geoms", [g]):
                x, y = p.exterior.xy; ax.plot(x, y, color="#555", lw=0.4)
            c = g.representative_point()
            if B.contains(c): ax.text(c.x, c.y, n, fontsize=5, ha="center")
panels = [("Arachthos: ru:Arta@E (red) / @W (blue)", ["ru:Arta@E", "ru:Arta@W"], (20.6, 38.9, 21.5, 39.7), "Arachthos"),
          ("Struma: ru:Serres@EStr / @WStr", ["ru:Serres@EStr", "ru:Serres@WStr"], (22.8, 40.6, 24.2, 41.5), "Struma"),
          ("1832: ru:Phthiotis@S1832 / @N1832", ["ru:Phthiotis@S1832", "ru:Phthiotis@N1832"], (21.6, 38.4, 23.3, 39.4), "Spercheios"),
          ("1832 west: ru:Aetolia-Acarnania@S1832 / ru:Evrytania@N1832", ["ru:Aetolia-Acarnania@S1832", "ru:Evrytania@N1832"], (20.6, 38.2, 22.0, 39.3), "Acheloos"),
          ("Kalamas: ru:Thesprotia@NKal / @SKal", ["ru:Thesprotia@NKal", "ru:Thesprotia@SKal"], (19.9, 39.2, 20.8, 39.9), "Kalamas"),
          ("Karaağaç + Himarë", ["tr:Edirne/Edirne merkez@W", "al:Himarë"], None, None)]
fig, axs = plt.subplots(2, 3, figsize=(18, 12))
for ax, (t, sels, bb, riv) in zip(axs.flat, panels):
    ax.set_title(t, fontsize=9)
    for s, col in zip(sels, ["#e05050", "#5070e0"]):
        try: draw(ax, P.select(s), color=col, alpha=0.45)
        except Exception as e: print(s, e)
    if bb:
        outline(ax, bb); ax.set_xlim(bb[0], bb[2]); ax.set_ylim(bb[1], bb[3])
        x, y = P._river(riv).xy; ax.plot(x, y, color="#0040ff", lw=1.2)
    if "1832" in t:
        x, y = P.MAIN1832.exterior.xy; ax.plot(x, y, color="k", lw=1, ls="--")
    ax.set_aspect(1.3)
plt.tight_layout(); plt.savefig("/home/claude/gb/check/splits.png", dpi=90)
