# Brief: the borders of the modern Greek state, 1821 to today (shared by all research batches)

We are building (1) a time-lapse film on a flat relief map of the territory of the modern Greek state from the first year of the
revolution (1821) to today, with the key battles that won or lost territory, and (2) a web atlas with a year slider. The film and the
atlas show not only the legal borders but every territory the Greek state or its armed forces CONTROLLED IN FACT, and every territory
GRANTED to Greece by a treaty or an award that was later superseded or never carried out, and every time Greece LOST CONTROL of its
own territory to a foreign occupier. Each batch covers one period and writes ONE JSON file: a list of "status events".

The geometry will be drawn later from these descriptions, so the most important thing is that every event says EXACTLY WHICH AREA
it covers, in terms that can be mapped (see "Area").

## The statuses (field `status`)

- `de_jure`: Greek sovereignty in force and recognised by the other party or by the Great Powers (a treaty in force, a protocol
  accepted by the parties, a formal transfer). Give the treaty and its dates.
- `de_facto`: controlled in fact by the Greek state or its armed forces, without recognised sovereignty: the areas held by the
  revolution and its provisional governments (1821–1832), military occupation in war, an administration granted by others (the
  Smyrna zone), territory taken and later handed back. Include joint Allied occupations in which Greek forces held a sector
  (`joint`: true, e.g. Kherson and Mykolaiv in 1919), and say who else was there.
- `awarded`: granted to Greece by a treaty, protocol, convention or Great-Power award that was never carried out or was superseded
  (the 1830 London Protocol line, the 1880 Berlin Conference line, Sèvres for Eastern Thrace, Imbros and Tenedos and the Smyrna zone,
  the Venizelos–Tittoni agreement for the Dodecanese). An area can be `awarded` and `de_facto` at the same time: give two events.
- `occupied`: territory under Greek sovereignty (or held de facto) taken over by a foreign power against the will of the Greek
  government: e.g. Piraeus 1854–57 (Britain and France), Thessaly 1897–98 (the Ottoman army), Eastern Macedonia 1916–18 (Bulgaria
  and Germany), Corfu 1923 (Italy), the Axis occupation 1941–44/45 (German, Italian and Bulgarian zones). Give the occupier. Allied
  forces on Greek soil with the government's consent are NOT `occupied` (note them in `note`).
- `autonomous`: Greek-populated entities outside the Greek state that matter for the story, so that the map can show them faintly:
  the Principality of Samos (1834–1912), the Cretan State (1898–1913), the Autonomous Republic of Northern Epirus (1914). Not
  Cyprus under Britain.

## What to record

Every change of status of any area, with START and END. Typical events: a town or island taken by the Greek army (de_facto from the
day it was entered), a treaty that makes it de_jure, the day the Greek army left an area it handed back, the start and end of a
foreign occupation, the date a treaty awarded an area and the date that award lapsed or was superseded.

- Dates: Gregorian (Greece used the Julian calendar until 16 February 1923 Julian = 1 March 1923 Gregorian: convert, and say
  "(Julian 26 October)" in `note` where the sources use Julian). Give `start` and `end` as "YYYY-MM-DD" (or "YYYY-MM" / "YYYY" if
  that is all that is known, and say so in `date_note`). Open-ended (still true today): `end` = null.
- For treaties give `signed`, `in_force` (ratification / entry into force) and `handover` (the day the territory actually changed
  hands) where known; set `start` to the handover if known, else the entry into force, and explain.
- Granularity: by town, island or district. For a war, record the advance and retreat at least town by town for the main towns,
  and give the FRONT LINE at key dates when the area is not a set of towns (e.g. Asia Minor in 1920 and 1921, Northern Epirus in
  1940–41, the Axis zones in 1941).

## Area (field `area`) – the most important field

Describe each area so that it can be drawn from present-day boundaries plus, where needed, a described line:
- `area.name`: a short name ("Thessaly (1881 line)", "Korytsa district", "Smyrna zone (Sèvres Art. 66)").
- `area.units`: the PRESENT-DAY administrative units that make it up, as precisely as possible: in Greece the regional units
  (e.g. "Larissa regional unit") and, where a line cuts a unit, the municipalities or municipal units on each side; in Albania,
  Bulgaria, North Macedonia, Turkey and Ukraine the present districts / municipalities (Turkish ilçe, Albanian bashki, Bulgarian
  obshtina, Ukrainian raion or hromada). Islands by name.
- `area.line`: where the boundary does NOT follow present units, describe its course as in the treaty or the standard histories
  (rivers, mountain crests, villages left on each side, the end points with coordinates if possible). Quote the treaty text where it
  defines the line. For a front line, list the places on it from end to end with coordinates.
- `area.points`: key places with lat/lon (decimal, 3 decimals) that the line passes through or the area contains.
- `area.confidence`: "exact" (a defined line, matches present units) | "good" | "approx" (a front line or vague extent).

## JSON object (one per status event)

```json
{
  "id": "1881-thessaly-arta",
  "status": "de_jure",
  "area": {"name": "Thessaly and Arta (1881 line)", "units": ["Larissa regional unit except Elassona and Tyrnavos?...", "..."],
           "line": "...", "points": [{"name": "Arta", "lat": 39.160, "lon": 20.985}], "confidence": "good"},
  "start": "1881-11-14", "end": null, "date_note": "",
  "signed": "1881-07-02", "in_force": "1881-07-02", "handover": "1881-09/11 (in stages: ...)",
  "basis": "Convention of Constantinople (2 July 1881) between Greece and the Ottoman Empire, after the Berlin Conference (1880)",
  "by_whom": "", "occupier": "", "joint": false, "joint_with": "",
  "battle": "", "event": "Ottoman troops handed over Larissa on ...; the last area handed over was ...",
  "sources": "en.wikipedia Convention of Constantinople (1881); el.wikipedia ...; Kaldis 1979 ...",
  "note": ""
}
```

- `battle`: if the change followed a battle, name it (e.g. "Sarantaporo", "Giannitsa", "Bizani", "Dumlupınar"), so that the film can
  link the key battles to the border changes.
- `sources`: say where each fact comes from (English and Greek Wikipedia, the treaty texts, standard works: Clogg, Koliopoulos &
  Veremis, Dakin, Hellenic Army General Staff histories, Llewellyn Smith's Ionian Vision, Kitromilides, Mazower's Inside Hitler's Greece,
  Mazower's Greece and the Inter-War Economic Crisis, the Treaty texts on Wikisource etc.). Never invent a date or a line; if unsure,
  say so in `note` and set `area.confidence` to "approx".

## Method

- WebFetch the URLs listed in your task first (English and Greek Wikipedia articles and treaty texts), then follow what they cite.
  You may use at most 10 WebSearch calls. Wikipedia pages not in your list can only be fetched if they appear in your search results.
- Write the file with the Write tool as valid JSON (an array of objects), early and then again as you add, and validate it with
  `python3 -c "import json,sys; d=json.load(open(sys.argv[1])); print(len(d))" FILE`.
- Final message (at most ten lines): the number of events by status, the areas whose extent or dates you could not pin down,
  and any place where the sources disagree. Do not paste the JSON back.
