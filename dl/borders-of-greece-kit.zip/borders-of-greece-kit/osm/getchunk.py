import json, base64, gzip, sys
def get(path):
    raw=json.load(open(path)); t=raw[0]['text'] if isinstance(raw,list) else raw
    s=t[t.index('CHUNKSTART|')+11:t.index('|CHUNKEND')]
    return s.strip('"')
if __name__=='__main__':
    b=get(sys.argv[1]); d=json.loads(gzip.decompress(base64.b64decode(b)))
    json.dump(d, open(sys.argv[2],'w'))
    print({k: len(v) for k,v in d.items()})
