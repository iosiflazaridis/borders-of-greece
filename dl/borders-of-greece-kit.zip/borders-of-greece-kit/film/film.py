"""The Borders of Greece, 1821 to today: the film.

Frame 1920x1080 at 30 fps: a 520 px panel on the left (title, date, legend with areas, caption, area chart) and a 1400x1080 map
on the right (flat relief in a Lambert conformal conic projection, with the status fills of data/timeline.py).
usage: python3 film.py info | still <date|t=seconds> [out.png] | render <k> <n>  (part k of n) | encode
"""
import sys, json, math, bisect, datetime as dt, functools, os, pickle, subprocess
import numpy as np, cairo, cv2
from pyproj import Transformer
import shapely
from shapely.geometry import Point, Polygon, MultiPolygon, LineString, box as sbox
from shapely.ops import unary_union
sys.path.insert(0, "/home/claude/gb/data"); sys.path.insert(0, "/home/claude/gb/geo")
import timeline as T

# events in the data (and on the site) but not in the film: southern Ukraine, 1919 (Iosif, 27 Oct: "I feel that episode does not
# belong to the video"; Greek troops served there under French command in an Allied intervention, with no Greek claim to the land).
# GB_ALL=1 (used by the site's prep_site.py) keeps them.
FILM_EXCLUDE = set() if os.environ.get("GB_ALL") else {"1919-ukraine-odessa", "1919-ukraine-odessa-front-berezovka-serbka",
                                                        "1919-ukraine-kherson", "1919-ukraine-nikolaev", "1919-crimea-sevastopol",
                                                        "1947-imia"}   # Imia: a point, marked on the site only
def f_active(d):
    return frozenset(T.active(d) - FILM_EXCLUDE)
def f_state(d):
    ids = f_active(d); c = T.classes(ids)
    greek = unary_union([c["dj"], c["df"]])
    hold = [(n, la, lo) for n, la, lo, s, e in __import__("mapping").HOLDOUTS if s <= d < e and greek.distance(Point(lo, la)) < 0.04]
    return c, hold, ids

FILM = "/home/claude/gb/film"
W, H, FPS = 1920, 1080, 30
PW = 520                          # panel width
MW, MH = W - PW, H                # map viewport
ASPECT = MW / MH

# ------------------------------------------------------------------ base raster and projection
BJ = json.load(open(f"{FILM}/base_0.5.json"))
_npz = np.load(f"{FILM}/base_0.5.npz")
BASE = _npz["rgb"]; LAND = _npz["land"]
FWD = Transformer.from_crs("EPSG:4326", BJ["proj"], always_xy=True)
KM = BJ["km"] * 1000.0
def proj(lon, lat):
    return FWD.transform(lon, lat)
def pgeom(g):
    return shapely.transform(g, lambda c: np.column_stack(FWD.transform(c[:, 0], c[:, 1])))

# ------------------------------------------------------------------ colours (dataviz reference ramps; validated for the legend)
def hexrgb(h): return tuple(int(h[i:i + 2], 16) / 255 for i in (1, 3, 5))
C = dict(dj=hexrgb("#256abf"), df=hexrgb("#6da7ec"), dfj=hexrgb("#e87ba4"), occ=hexrgb("#6b6b6b"), aut=hexrgb("#1baf7a"),
         ris=hexrgb("#eda100"), awd=hexrgb("#b97a00"), battle=hexrgb("#d03b3b"), ink=hexrgb("#1d1d1b"), ink2=hexrgb("#55534d"),
         muted=hexrgb("#8a877f"), paper=hexrgb("#f4f1ea"), hair=hexrgb("#dcd8cc"), hatch=hexrgb("#1c5cab"))
PAPER = (244, 241, 234)

# ------------------------------------------------------------------ dates
D0 = dt.date(1821, 3, 1).toordinal()
D1 = dt.date(2026, 10, 27).toordinal()
def ordn(s): return dt.date.fromisoformat(s).toordinal()
def iso(d): return dt.date.fromordinal(int(d)).isoformat()
MONTHS = "January February March April May June July August September October November December".split()

CAPS = json.load(open(f"{FILM}/captions.json"))
SET15 = {b["id"]: b for b in json.load(open("/home/claude/gb/battles/set15.json"))}
for c in CAPS:
    if c.get("set15"):
        b = SET15[c["set15"]]; c.setdefault("lat", b["lat"]); c.setdefault("lon", b["lon"]); c.setdefault("place", b["name"])
    c["day"] = ordn(c["date"])

# boundaries of the map states (any display event starting or ending), in days
DISP = [e for e in T.GEO if e["status"] in ("de_jure", "de_facto", "awarded", "occupied", "autonomous", "rising") and e["id"] not in FILM_EXCLUDE]
BOUND = sorted({d for e in DISP for d in (ordn(e["start"]), ordn(e["end"]) if e["end"] else None) if d and D0 <= d <= D1}
               | {ordn(s) for _, _, _, s, _ in __import__("mapping").HOLDOUTS} | {ordn(e) for _, _, _, _, e in __import__("mapping").HOLDOUTS})
BOUND = [b for b in BOUND if D0 <= b <= D1]
def state_index(day):
    return bisect.bisect_right(BOUND, day) - 1      # -1 = before the first boundary
STATE_DAYS = [D0] + BOUND                           # state k (k = index+1) starts at STATE_DAYS[k]

# ------------------------------------------------------------------ clock: film seconds per day
INTRO = 4.0            # title over the empty map before March 1821
OUTRO_HOLD = 6.5       # on today's map: the ghost of the lost lands, the strokes, then the cut to the card
CARD = 12.0            # the summary card
FLOW = 150.0           # seconds of flowing time, without the caption holds
EMPTY_RATE = 9.0 / (77 * 365.25)     # 1949-2026 in about nine seconds
MAXRATE = 0.55         # at most 0.55 s per day
FADE = 0.45            # crossfade between map states (s)

def words(c): return len((c["title"] + " " + c.get("win", "") + " " + c["text"]).split())
def read(c):
    """seconds on screen"""
    if c["kind"] == "end": return 6.0
    return 1.3 + words(c) / 4.2
def hold0(c):
    """seconds the clock stands still for it: the last part of the reading overlaps the clock moving again"""
    if c["kind"] == "end": return 0.0
    r = read(c); return r - min(2.5, 0.4 * r)

VIEWS = {"south": (23.75, 37.9, 900), "full": (24.6, 38.6, 1180), "asia": (26.0, 38.9, 1190), "ukraine": (30.95, 45.9, 470)}
# camera schedule: (from_day, to_day, view) - the camera moves over [from, to] to the view; the first entry is the opening view
CAM = [("1821-01-01", "1821-01-01", "south"), ("1912-08-01", "1912-10-12", "full"),
       ("1919-04-15", "1919-05-12", "asia"), ("1922-10-20", "1923-01-15", "full"), ("1955-01-01", "2012-01-01", "asia")]
MOVE_MIN = 3.2

def build_clock():
    n = D1 - D0 + 1
    imp = np.zeros(n)
    for b in BOUND: imp[b - D0] += 1
    for c in CAPS: imp[c["day"] - D0] += 1.5
    from scipy.ndimage import gaussian_filter1d
    dens = gaussian_filter1d(imp, 28)
    shape_ = np.sqrt(dens / dens.max())
    # solve for b in rate = EMPTY_RATE + b*shape, capped, so that the flow is FLOW seconds
    lo, hi = 0, 10
    for _ in range(60):
        b = (lo + hi) / 2
        r = np.minimum(EMPTY_RATE + b * shape_, MAXRATE)
        if r.sum() > FLOW: hi = b
        else: lo = b
    rate = np.minimum(EMPTY_RATE + b * shape_, MAXRATE)
    # camera moves take at least MOVE_MIN seconds
    for f, t, v in CAM[1:]:
        i0, i1 = ordn(f) - D0, ordn(t) - D0
        s = rate[i0:i1].sum()
        if s < MOVE_MIN: rate[i0:i1] *= MOVE_MIN / s
    sec = rate.copy()
    holds = np.zeros(n)
    for c in CAPS: c["hold"] = hold0(c)
    # a caption is not cut short by the next one: lengthen the hold of the earlier one where needed
    for _ in range(3):
        holds[:] = 0
        for c in CAPS: holds[c["day"] - D0] += c["hold"]
        T0 = np.concatenate([[0], np.cumsum(sec + holds)]) + INTRO
        ts = []
        for c in CAPS:
            i = c["day"] - D0; ts.append(T0[i] + sec[i] + sum(x["hold"] for x in CAPS if x["day"] == c["day"] and CAPS.index(x) < CAPS.index(c)))
        changed = False
        for j in range(len(CAPS) - 1):
            need = read(CAPS[j]) + 0.35 - (ts[j + 1] - ts[j])
            if need > 0.01: CAPS[j]["hold"] += need; changed = True; break
        if not changed: break
    else:
        pass
    # repeat until no conflicts remain
    while True:
        holds[:] = 0
        for c in CAPS: holds[c["day"] - D0] += c["hold"]
        T0 = np.concatenate([[0], np.cumsum(sec + holds)]) + INTRO
        ts = []
        seen = {}
        for c in CAPS:
            i = c["day"] - D0; off = seen.get(i, 0.0)
            ts.append(T0[i] + sec[i] + off); seen[i] = off + c["hold"]
        bad = [j for j in range(len(CAPS) - 1) if read(CAPS[j]) + 0.35 - (ts[j + 1] - ts[j]) > 0.01]
        if not bad: break
        j = bad[0]; CAPS[j]["hold"] += read(CAPS[j]) + 0.35 - (ts[j + 1] - ts[j])
    for c, t in zip(CAPS, ts): c["t0"] = t; c["t1"] = t + read(c)
    return sec, holds, T0
SEC, HOLDS, TDAY = build_clock()
T_END_MAP = TDAY[-1] + OUTRO_HOLD
T_GHOST0 = TDAY[-1] + 1.0          # the lost lands fade in
T_FLASH = TDAY[-1] + 4.4           # fully drawn, on the loudest strokes
T_CUT = T_END_MAP                  # the cut to the summary card
T_TOTAL = T_CUT + CARD

def day_at(t):
    """fractional day ordinal at film time t"""
    if t <= INTRO: return float(D0)
    i = int(np.searchsorted(TDAY, t, side="right") - 1)
    i = min(max(i, 0), len(SEC) - 1)
    dtd = t - TDAY[i]
    if dtd <= SEC[i]: return D0 + i + dtd / max(SEC[i], 1e-9)
    return D0 + i + 0.999                 # inside the day's hold
def t_at(day):
    i = int(day) - D0
    i = min(max(i, 0), len(SEC) - 1)
    return TDAY[i] + SEC[i] * (day - int(day))

# ------------------------------------------------------------------ camera
BX0, BX1, BY0, BY1 = BJ["x0"], BJ["x1"], BJ["y0"], BJ["y1"]
def view_rect(lon, lat, wkm):
    x, y = proj(lon, lat); w = wkm * 1000; h = w / ASPECT
    w = min(w, BX1 - BX0 - 2000); h = w / ASPECT
    x = min(max(x, BX0 + w / 2 + 1000), BX1 - w / 2 - 1000); y = min(max(y, BY0 + h / 2 + 1000), BY1 - h / 2 - 1000)
    return np.array([x, y, w])
VR = {k: view_rect(*v) for k, v in VIEWS.items()}
def smooth(u): return u * u * (3 - 2 * u)
def camera(t):
    """(cx, cy, width) in metres at film time t; moves interpolate the centre linearly and the width geometrically"""
    cur = VR[CAM[0][2]]
    for f, to, v in CAM[1:]:
        ta, tb = t_at(ordn(f)), t_at(ordn(to))
        if t <= ta: return cur
        nxt = VR[v]
        if t < tb:
            u = smooth((t - ta) / (tb - ta))
            c = cur[:2] * (1 - u) + nxt[:2] * u
            w = math.exp(math.log(cur[2]) * (1 - u) + math.log(nxt[2]) * u)
            return np.array([c[0], c[1], w])
        cur = nxt
    return cur
def is_static(t):
    for f, to, v in CAM[1:]:
        if t_at(ordn(f)) <= t <= t_at(ordn(to)): return False
    return True

# ------------------------------------------------------------------ geometry, projected and simplified
CACHE = f"{FILM}/states_cache.pkl"
_SC = pickle.load(open(CACHE, "rb")) if os.path.exists(CACHE) else {}
@functools.lru_cache(None)
def classes_proj(k):
    key = ("g", STATE_DAYS[k], f_active(iso(STATE_DAYS[k])))
    if key in _SC: return _SC[key]
    v = _classes_proj(k); _SC[key] = v; return v
def _classes_proj(k):
    """the display classes of state k (k=0: before the first boundary), projected to metres and simplified"""
    day = STATE_DAYS[k]
    c, hold_, ids = f_state(iso(day))
    out = {}
    for key, g in c.items():
        if key == "ins" or g.is_empty: continue
        out[key] = shapely.make_valid(pgeom(g).simplify(250))
    out["hold"] = [(n, *proj(lo, la)) for n, la, lo in hold_]
    # award lines: the land frontiers of the awarded area, plus its coasts where the coast is not already Greek-held
    if "awd" in out:
        held = unary_union([out[q].buffer(0) for q in ("dj", "df", "dfj", "occ") if q in out])
        L = out["awd"].boundary
        front = L.intersection(INLAND)
        coast = L.difference(INLAND)
        if not held.is_empty: coast = coast.difference(held.buffer(2500))
        out["awd_lines"] = unary_union([front, coast]).simplify(150)
    return out

AREA_TR = Transformer.from_crs("EPSG:4326", "+proj=laea +lat_0=39 +lon_0=24 +datum=WGS84", always_xy=True)
@functools.lru_cache(None)
def areas(k):
    key = ("a", STATE_DAYS[k], f_active(iso(STATE_DAYS[k])))
    if key in _SC: return _SC[key]
    v = _areas(k); _SC[key] = v; return v
def _areas(k):
    day = STATE_DAYS[k]
    c, _, _ = f_state(iso(day))
    def km2(g): return 0 if g.is_empty else shapely.transform(g, lambda a: np.column_stack(AREA_TR.transform(a[:, 0], a[:, 1]))).area / 1e6
    return dict(dj=km2(c["dj"]), df=km2(c["df"]) + km2(c["dfj"]), occ=km2(c["occ"]), aut=km2(c["aut"]))

# reference lines and labels
def _load(p): return json.load(open(p))
RIVERS = {k: pgeom(shapely.geometry.shape(v)).simplify(300) for k, v in _load("/home/claude/gb/osm/rivers_main.geojson").items()}
def _borders():
    from shapely.geometry import shape
    keep = {"GRC", "ALB", "MKD", "BGR", "TUR", "SRB", "ROU", "UKR", "MDA", "XKX", "KOS", "MNE", "BIH", "HRV", "GEO", "RUS", "HUN", "SYR"}
    cs = {}
    for f in _load("/home/claude/gb/geo/ne_10m_admin_0_countries.geojson")["features"]:
        a = f["properties"].get("ADM0_A3")
        if a in keep: cs[a] = shape(f["geometry"]).buffer(0)
    lines = []
    ks = sorted(cs)
    for i, a in enumerate(ks):
        for b in ks[i + 1:]:
            if not cs[a].intersects(cs[b]): continue
            l = cs[a].boundary.intersection(cs[b].buffer(0.002))
            if not l.is_empty: lines.append(l)
    return pgeom(unary_union(lines)).simplify(300)
BORDERS_CACHE = f"{FILM}/borders_proj.pkl"
if os.path.exists(BORDERS_CACHE): BORDERS = pickle.load(open(BORDERS_CACHE, "rb"))
else:
    BORDERS = _borders(); pickle.dump(BORDERS, open(BORDERS_CACHE, "wb"))
def _land_proj():
    from shapely.geometry import shape
    gs = []
    for fn in ("ne_10m_land", "ne_10m_minor_islands"):
        for f in _load(f"/home/claude/gb/geo/{fn}.geojson")["features"]:
            g = shape(f["geometry"])
            if g.intersects(sbox(16, 32.5, 36, 49)): gs.append(g.intersection(sbox(16, 32.5, 36, 49)).buffer(0))
    return pgeom(unary_union(gs)).simplify(200)
LAND_CACHE = f"{FILM}/land_proj.pkl"
if os.path.exists(LAND_CACHE): LANDP = pickle.load(open(LAND_CACHE, "rb"))
else:
    LANDP = _land_proj(); pickle.dump(LANDP, open(LAND_CACHE, "wb"))
INLAND = LANDP.buffer(-1500)

CITIES = [("Athens", 37.98, 23.73), ("Thessaloniki", 40.64, 22.94), ("Constantinople", 41.01, 28.98), ("Smyrna", 38.42, 27.14),
          ("Ioannina", 39.66, 20.85), ("Ankara", 39.93, 32.86), ("Odessa", 46.48, 30.72), ("Sofia", 42.70, 23.32), ("Tirana", 41.33, 19.82)]

# ------------------------------------------------------------------ drawing helpers
def to_px(cam):
    cx, cy, w = cam; s = MW / w
    x0 = cx - w / 2; y1 = cy + (w / ASPECT) / 2
    return (lambda X, Y: ((X - x0) * s, (y1 - Y) * s)), s

def path_geom(ctx, g, f):
    for p in getattr(g, "geoms", [g]):
        if p.geom_type == "Polygon":
            for ring in [p.exterior] + list(p.interiors):
                xy = np.asarray(ring.coords)
                if len(xy) < 3: continue
                px, py = f(xy[:, 0], xy[:, 1])
                ctx.move_to(px[0], py[0])
                for a, b in zip(px[1:], py[1:]): ctx.line_to(a, b)
                ctx.close_path()
        elif p.geom_type in ("MultiPolygon", "GeometryCollection"):
            path_geom(ctx, p, f)

def path_lines(ctx, g, f):
    for p in getattr(g, "geoms", [g]):
        if p.geom_type in ("LineString", "LinearRing"):
            xy = np.asarray(p.coords); px, py = f(xy[:, 0], xy[:, 1])
            ctx.move_to(px[0], py[0])
            for a, b in zip(px[1:], py[1:]): ctx.line_to(a, b)
        elif p.geom_type in ("MultiLineString", "GeometryCollection"):
            path_lines(ctx, p, f)
        elif p.geom_type == "Polygon":
            path_lines(ctx, p.exterior, f)
            for r in p.interiors: path_lines(ctx, r, f)

@functools.lru_cache(None)
def hatch(rgb, alpha, angle, gap=7.0, width=1.5):
    n = int(gap * 4)
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, n, n); c = cairo.Context(s)
    c.set_source_rgba(*rgb, alpha); c.set_line_width(width)
    for k in range(-8, 9):
        if angle == 45:
            c.move_to(k * gap - n, n); c.line_to(k * gap + n, -n)
        else:
            c.move_to(k * gap - n, -n); c.line_to(k * gap + n, n)
    c.stroke()
    p = cairo.SurfacePattern(s); p.set_extend(cairo.EXTEND_REPEAT)
    return p

def base_view(cam):
    """the relief and the land mask for a camera, resampled from the 0.5 km base"""
    cx, cy, w = cam; h = w / ASPECT
    px0 = (cx - w / 2 - BX0) / KM; py0 = (BY1 - (cy + h / 2)) / KM
    sc = (w / KM) / MW                        # base pixels per output pixel
    M = np.array([[sc, 0, px0], [0, sc, py0]], np.float32)
    src = BASE
    if sc > 1.25:                             # pre-blur when shrinking
        k = sc / 2.2
        src = cv2.GaussianBlur(BASE, (0, 0), k)
    rgb = cv2.warpAffine(src, M, (MW, MH), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_REPLICATE)
    land = cv2.warpAffine(LAND, M, (MW, MH), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_REPLICATE)
    return rgb, land.astype(np.float32) / 255.0

def overlay(k, cam):
    """RGBA float layers for state k: fills (to be masked by land) and lines (unmasked)"""
    G = classes_proj(k)
    f, s = to_px(cam)
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, MW, MH); ctx = cairo.Context(surf)
    ctx.set_fill_rule(cairo.FILL_RULE_WINDING)
    def fill(key, rgb, a, hat=None):
        g = G.get(key)
        if g is None or g.is_empty: return
        path_geom(ctx, g, f); ctx.set_source_rgba(*rgb, a); ctx.fill_preserve()
        if hat: ctx.set_source(hat); ctx.fill_preserve()
        ctx.new_path()
    fill("aut", C["aut"], 0.42)
    fill("dj", C["dj"], 0.60)
    fill("df", C["df"], 0.55, hatch(C["hatch"], 0.85, 45))
    fill("dfj", C["dfj"], 0.50, hatch((0.55, 0.15, 0.40), 0.85, 135))
    fill("occ", C["occ"], 0.50, hatch((0.18, 0.18, 0.18), 0.8, 135))
    g = G.get("ris")
    if g is not None and not g.is_empty:
        path_geom(ctx, g, f); ctx.set_source(hatch(C["ris"], 0.95, 45, 6.0, 1.6)); ctx.fill(); ctx.new_path()
    fills = surf
    surf2 = cairo.ImageSurface(cairo.FORMAT_ARGB32, MW, MH); c2 = cairo.Context(surf2)
    g = G.get("awd_lines")
    if g is not None and not g.is_empty:
        path_lines(c2, g, f)
        c2.set_line_join(cairo.LINE_JOIN_ROUND)
        c2.set_source_rgba(1, 1, 1, 0.55); c2.set_line_width(4.2); c2.stroke_preserve()
        c2.set_source_rgba(*C["awd"], 1); c2.set_line_width(2.0); c2.set_dash([7, 5]); c2.stroke(); c2.set_dash([])
    for n, X, Y in G["hold"]:
        x, y = f(X, Y)
        c2.new_path(); c2.arc(x, y, 5.0, 0, 2 * math.pi); c2.set_source_rgba(1, 1, 1, 0.95); c2.fill_preserve()
        c2.set_source_rgba(0.08, 0.08, 0.08, 1); c2.set_line_width(2.4); c2.stroke()
    return surf_to_np(fills), surf_to_np(surf2)

def surf_to_np(s):
    a = np.ndarray((s.get_height(), s.get_width(), 4), np.uint8, s.get_data()).astype(np.float32) / 255.0
    return a        # premultiplied BGRA

def composite(rgb, layer, mask=None):
    """rgb float 0..1 (RGB), layer premultiplied BGRA"""
    a = layer[..., 3:4]
    col = layer[..., [2, 1, 0]]
    if mask is not None:
        a = a * mask[..., None]; col = col * mask[..., None]
    return rgb * (1 - a) + col

@functools.lru_cache(maxsize=6)
def static_layers(k, camkey):
    cam = np.array(camkey)
    return overlay(k, cam)

@functools.lru_cache(maxsize=4)
def static_map(k, camkey):
    rgb, land, ref = static_base(camkey)
    fills, lines = static_layers(k, camkey)
    img = rgb.astype(np.float32) / 255.0
    img = composite(img, ref); img = composite(img, fills, land); img = composite(img, lines)
    return img

@functools.lru_cache(maxsize=2)
def static_base(camkey):
    cam = np.array(camkey)
    rgb, land = base_view(cam)
    ref = refs_layer(cam)
    return rgb, land, ref

def refs_layer(cam):
    """present-day borders, rivers and reference cities"""
    f, s = to_px(cam)
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, MW, MH); c = cairo.Context(surf)
    c.set_line_join(cairo.LINE_JOIN_ROUND); c.set_line_cap(cairo.LINE_CAP_ROUND)
    path_lines(c, RIVERS_ALL, f); c.set_source_rgba(0.36, 0.55, 0.70, 0.75); c.set_line_width(1.1); c.stroke()
    path_lines(c, BORDERS, f); c.set_source_rgba(0.25, 0.24, 0.22, 0.55); c.set_line_width(1.0); c.set_dash([3, 3]); c.stroke(); c.set_dash([])
    return surf_to_np(surf)
RIVERS_ALL = unary_union(list(RIVERS.values()))

# ------------------------------------------------------------------ text
FONT_SANS = "IBM Plex Sans Condensed"; FONT_SANS_M = "IBM Plex Sans Condensed Medium"; FONT_SANS_SB = "IBM Plex Sans Condensed SemiBold"
FONT_HEAD = "Marcellus"; FONT_SERIF = "Gentium Book Plus"
def font(ctx, fam, size, italic=False, bold=False):
    ctx.select_font_face(fam, cairo.FONT_SLANT_ITALIC if italic else cairo.FONT_SLANT_NORMAL,
                         cairo.FONT_WEIGHT_BOLD if bold else cairo.FONT_WEIGHT_NORMAL)
    ctx.set_font_size(size)
def text(ctx, s, x, y, rgb=C["ink"], a=1.0, align="left"):
    e = ctx.text_extents(s)
    if align == "right": x -= e.x_advance
    elif align == "center": x -= e.x_advance / 2
    ctx.move_to(x, y); ctx.set_source_rgba(*rgb, a); ctx.show_text(s)
    return e.x_advance
def wrap(ctx, s, width):
    out, line = [], ""
    for w_ in s.split():
        t = (line + " " + w_).strip()
        if ctx.text_extents(t).x_advance > width and line: out.append(line); line = w_
        else: line = t
    if line: out.append(line)
    return out
def halo_text(ctx, s, x, y, rgb, size, fam=FONT_SANS_M, a=1.0, align="left"):
    font(ctx, fam, size)
    e = ctx.text_extents(s)
    if align == "center": x -= e.x_advance / 2
    elif align == "right": x -= e.x_advance
    ctx.move_to(x, y); ctx.text_path(s)
    ctx.set_source_rgba(1, 1, 1, 0.80 * a); ctx.set_line_width(3.2); ctx.set_line_join(cairo.LINE_JOIN_ROUND); ctx.stroke()
    ctx.move_to(x, y); ctx.set_source_rgba(*rgb, a); ctx.show_text(s)

# ------------------------------------------------------------------ the area series for the chart
@functools.lru_cache(None)
def area_series():
    xs, ys = [D0], [areas(0)]
    for k, d in enumerate(BOUND, start=1):
        xs.append(d); ys.append(areas(k))
    return xs, ys

LEG = [("dj", "Greek state, recognized", None), ("df", "Held by Greece, not recognized", 45),
       ("dfj", "Joint Allied sector", 135), ("awd", "Awarded by treaty, not yet or never carried out", "dash"),
       ("occ", "Occupied by a foreign power", 135), ("aut", "Autonomous Greek state", None),
       ("ris", "Rising for union (irregulars)", 45), ("hold", "Ottoman-held fortress", "ring")]

def panel(ctx, t, day, k):
    ctx.set_source_rgb(*C["paper"]); ctx.rectangle(0, 0, PW, H); ctx.fill()
    ctx.set_source_rgb(*C["hair"]); ctx.rectangle(PW - 1, 0, 1, H); ctx.fill()
    L = 36
    font(ctx, FONT_HEAD, 40); text(ctx, "THE BORDERS OF GREECE", L, 66, C["ink"])
    font(ctx, FONT_SERIF, 22, italic=True); text(ctx, "Τὰ σύνορα τοῦ ἑλληνικοῦ κράτους, 1821 – σήμερα", L, 98, C["ink2"])
    # date
    d = dt.date.fromordinal(int(min(day, D1)))
    font(ctx, FONT_HEAD, 104); text(ctx, str(d.year), L - 4, 214, C["ink"])
    font(ctx, FONT_SANS_M, 28); text(ctx, MONTHS[d.month - 1], L + 2, 254, C["ink2"])
    # legend with areas
    a = areas(k)
    present = present_classes(k)
    y = 300
    for key, lab, sty in LEG:
        on = key in present
        al = 1.0 if on else 0.32
        sw_x, sw_y = L, y - 15
        if sty == "dash":
            ctx.set_source_rgba(1, 1, 1, 0.6 * al); ctx.set_line_width(4); ctx.move_to(sw_x, sw_y + 9); ctx.line_to(sw_x + 30, sw_y + 9); ctx.stroke()
            ctx.set_source_rgba(*C["awd"], al); ctx.set_line_width(2); ctx.set_dash([6, 4]); ctx.move_to(sw_x, sw_y + 9); ctx.line_to(sw_x + 30, sw_y + 9); ctx.stroke(); ctx.set_dash([])
        elif sty == "ring":
            ctx.new_path(); ctx.arc(sw_x + 15, sw_y + 9, 5, 0, 2 * math.pi); ctx.set_source_rgba(1, 1, 1, al); ctx.fill_preserve()
            ctx.set_source_rgba(0.08, 0.08, 0.08, al); ctx.set_line_width(2.4); ctx.stroke()
        else:
            ctx.rectangle(sw_x, sw_y, 30, 18)
            if key == "ris":
                ctx.set_source_rgba(1, 1, 1, al * 0.5); ctx.fill_preserve(); ctx.set_source(hatch(C["ris"], 0.95 * al, 45, 6.0, 1.6)); ctx.fill()
            else:
                fa = {"dj": 0.85, "df": 0.70, "dfj": 0.65, "occ": 0.60, "aut": 0.60}[key]
                ctx.set_source_rgba(*C[key], fa * al); ctx.fill_preserve()
                if sty: ctx.set_source(hatch({"df": C["hatch"], "dfj": (0.55, 0.15, 0.40), "occ": (0.18, 0.18, 0.18)}[key], 0.85 * al, sty)); ctx.fill()
                else: ctx.new_path()
        font(ctx, FONT_SANS, 20); text(ctx, lab, L + 44, y, C["ink"], al)
        v = {"dj": a["dj"], "df": a["df"] if key == "df" else None, "occ": a["occ"], "aut": a["aut"]}.get(key)
        if key == "dfj": v = None
        if v and v > 50:
            font(ctx, FONT_SANS_M, 20); text(ctx, f"{round(v, -2):,.0f} km²", PW - 30, y, C["ink"], al, align="right")
        y += 33
    # caption
    cap = current_caption(t)
    if cap:
        c, alpha = cap
        y = 590
        ctx.set_source_rgba(*C["hair"], alpha); ctx.rectangle(L, y - 30, PW - 2 * L, 1.5); ctx.fill()
        font(ctx, FONT_SANS_SB, 25)
        for ln in wrap(ctx, c["title"], PW - 2 * L):
            text(ctx, ln, L, y + 6, C["ink"], alpha); y += 31
        if c.get("win"):
            wc = C["dj"] if ("Greek" in c["win"] or "Government" in c["win"]) else C["ink2"] if c["win"] in ("indecisive", "draw") else C["battle"]
            font(ctx, FONT_SANS_M, 18); text(ctx, c["win"].upper(), L, y + 4, wc, alpha); y += 28
        font(ctx, FONT_SERIF, 22)
        y += 6
        for ln in wrap(ctx, c["text"], PW - 2 * L):
            text(ctx, ln, L, y + 6, C["ink"], alpha); y += 29
    chart(ctx, day)
    font(ctx, FONT_SANS, 13)
    text(ctx, "Areas computed from present-day boundaries (about ±1%).", L, H - 26, C["muted"])
    text(ctx, "Boundaries: geoBoundaries, Natural Earth. Relief: AWS Terrain Tiles.", L, H - 10, C["muted"])

def present_classes(k):
    G = classes_proj(k)
    s = {key for key in ("dj", "df", "dfj", "occ", "aut", "ris", "awd") if key in G and not G[key].is_empty}
    if G["hold"]: s.add("hold")
    return s

def chart(ctx, day):
    x0, x1, y0, y1 = 36, PW - 30, H - 62, H - 205
    vmax = 280000
    def X(d): return x0 + (d - D0) / (D1 - D0) * (x1 - x0)
    def Y(v): return y0 - v / vmax * (y0 - y1)
    xs, ys = area_series()
    # gridlines
    font(ctx, FONT_SANS, 13)
    for v in (100000, 200000):
        ctx.set_source_rgba(*C["hair"], 1); ctx.rectangle(x0, Y(v), x1 - x0, 1); ctx.fill()
        text(ctx, f"{v // 1000:,},000 km²", x0 + 4, Y(v) - 4, C["muted"])
    for yr in (1821, 1881, 1913, 1947, 2026):
        d = dt.date(yr, 1, 1).toordinal() if yr != 1821 else D0
        if yr == 2026: d = D1
        text(ctx, str(yr) if yr != 2026 else "today", X(d), y0 + 18, C["muted"], align="center" if yr not in (1821, 2026) else ("left" if yr == 1821 else "right"))
    ctx.set_source_rgba(*C["muted"], 1); ctx.rectangle(x0, y0, x1 - x0, 1); ctx.fill()
    # stacked steps up to today
    def band(lo_keys, key, rgb, a):
        pts_top, pts_bot = [], []
        for i in range(len(xs)):
            if xs[i] > day: break
            xa = X(xs[i]); xb = X(min(xs[i + 1] if i + 1 < len(xs) else D1, day))
            base_ = sum(ys[i][q] for q in lo_keys); top = base_ + ys[i][key]
            pts_top += [(xa, Y(top)), (xb, Y(top))]; pts_bot += [(xa, Y(base_)), (xb, Y(base_))]
        if not pts_top: return
        ctx.move_to(*pts_top[0])
        for p in pts_top[1:]: ctx.line_to(*p)
        for p in reversed(pts_bot): ctx.line_to(*p)
        ctx.close_path(); ctx.set_source_rgba(*rgb, a); ctx.fill()
    band([], "dj", C["dj"], 0.85)
    band(["dj"], "occ", C["occ"], 0.6)
    band(["dj", "occ"], "df", C["df"], 0.8)
    xc = X(min(day, D1))
    ctx.set_source_rgba(*C["ink"], 0.8); ctx.rectangle(xc - 0.75, y1 - 4, 1.5, y0 - y1 + 4); ctx.fill()

# ------------------------------------------------------------------ captions and battle marks
def current_caption(t):
    best = None
    for c in CAPS:
        if c["kind"] == "end":
            if t >= TDAY[-1] - 0.01: best = (c, min(1, (t - TDAY[-1] + 0.01) / 0.6))
            continue
        t0, t1 = c["t0"] - 0.25, c["t1"]
        if t0 <= t <= t1:
            a = min(1, (t - t0) / 0.35, (t1 - t) / 0.45)
            best = (c, max(0.0, a))
    return best

def marks(ctx, t, cam):
    f, s = to_px(cam)
    for c in CAPS:
        if "lat" not in c or c["kind"] == "end": continue
        t0 = c["t0"]; t1 = c["t1"] + 1.5
        if not (t0 - 0.1 <= t <= t1 + 0.6): continue
        x, y = f(*proj(c["lon"], c["lat"]))
        u = t - t0
        # expanding ring
        ctx.new_path()
        if 0 <= u < 1.4:
            r = 8 + 46 * (u / 1.4) ** 0.7; a = 1 - u / 1.4
            ctx.arc(x, y, r, 0, 2 * math.pi); ctx.set_source_rgba(*C["battle"], 0.85 * a); ctx.set_line_width(3); ctx.stroke()
        fade = min(1, max(0, (t1 + 0.6 - t) / 0.6), max(0, (t - t0 + 0.1) / 0.3))
        ctx.new_path(); ctx.arc(x, y, 6.5, 0, 2 * math.pi); ctx.set_source_rgba(1, 1, 1, 0.95 * fade); ctx.fill_preserve()
        ctx.set_source_rgba(*C["battle"], fade); ctx.set_line_width(3); ctx.stroke()
        ctx.new_path(); ctx.arc(x, y, 2.4, 0, 2 * math.pi); ctx.set_source_rgba(*C["battle"], fade); ctx.fill()
        name = c.get("label") or c["title"].split(",")[0]
        right = x < MW - 260
        halo_text(ctx, name, x + (14 if right else -14), y + 6, C["ink"], 21, a=fade, align="left" if right else "right")

def city_labels(ctx, cam, t):
    f, s = to_px(cam)
    for n, la, lo in CITIES:
        x, y = f(*proj(lo, la))
        if not (10 < x < MW - 10 and 10 < y < MH - 10): continue
        ctx.new_path(); ctx.arc(x, y, 2.6, 0, 2 * math.pi); ctx.set_source_rgba(0.12, 0.12, 0.12, 0.85); ctx.fill()
        halo_text(ctx, n, x + 6, y - 6, (0.18, 0.18, 0.16), 16, FONT_SANS, a=0.9)

# ------------------------------------------------------------------ the occupation zones of 1941-44 (lines and labels)
ZCACHE = f"{FILM}/zones_proj.pkl"
def _zones():
    import pieces as P
    ger = P.select("ru:Thessaloniki;ru:Chalkidiki;ru:Mount Athos;ru:Kilkis;ru:Pella;ru:Imathia;ru:Pieria;ru:Serres@WStr;m:Orestiadas;"
                   "m:Didymoteichou;m:Soufliou;[m:Alexandroupolis;&box:25.98,40.5,27,42]")
    bul = T.GM["1941-1944-bulgarian-zone"]
    gp = shapely.make_valid(pgeom(ger).simplify(300)); bp = shapely.make_valid(pgeom(bul).simplify(300))
    return unary_union([gp.boundary, bp.boundary]).intersection(INLAND.buffer(-1500)).simplify(200)
ZONES = pickle.load(open(ZCACHE, "rb")) if os.path.exists(ZCACHE) else None
def zones():
    global ZONES
    if ZONES is None:
        ZONES = _zones(); pickle.dump(ZONES, open(ZCACHE, "wb"))
    return ZONES
ZSPAN = (ordn("1941-06-01"), ordn("1944-09-20"))
ZLAB = [("GERMAN", 40.80, 22.62, "1941-06-01", "1944-09-20"), ("BULGARIAN", 41.22, 24.45, "1941-06-01", "1944-09-20"),
        ("ITALIAN", 39.55, 21.55, "1941-06-01", "1943-09-08"), ("GERMAN FROM SEPT. 1943", 39.55, 21.55, "1943-09-08", "1944-09-20")]
def zone_marks(ctx, day, cam):
    if not (ZSPAN[0] - 40 <= day <= ZSPAN[1] + 40): return
    a = min(1, (day - ZSPAN[0] + 40) / 40, (ZSPAN[1] + 40 - day) / 40)
    f, s = to_px(cam)
    ctx.new_path(); path_lines(ctx, zones(), f)
    ctx.set_source_rgba(1, 1, 1, 0.5 * a); ctx.set_line_width(3.4); ctx.stroke_preserve()
    ctx.set_source_rgba(0.12, 0.11, 0.10, 0.9 * a); ctx.set_line_width(1.5); ctx.stroke()
    for lab, la, lo, d0, d1 in ZLAB:
        if not (ordn(d0) - 30 <= day <= ordn(d1) + 30): continue
        b = a * min(1, max(0, (day - ordn(d0) + 30) / 30), max(0, (ordn(d1) + 30 - day) / 30))
        if ordn(d0) > ZSPAN[0] and day < ordn(d0): b = 0
        if ordn(d1) < ZSPAN[1] and day > ordn(d1): b = 0
        x, y = f(*proj(lo, la))
        halo_text(ctx, lab, x, y, (0.12, 0.11, 0.10), 17, FONT_SANS_SB, a=b, align="center")

# ------------------------------------------------------------------ the end: the lands once held or awarded
GCACHE = f"{FILM}/ghost_proj.pkl"
def _ghost():
    today = T.classes(T.active("2026-10-27"))["dj"]
    gs = [T.GM[e["id"]] for e in T.GEO if e["status"] in ("de_facto", "de_jure", "awarded") and e["id"] not in FILM_EXCLUDE]
    g = unary_union(gs).difference(today.buffer(0.01))
    return shapely.make_valid(pgeom(g).simplify(300))
GHOST = pickle.load(open(GCACHE, "rb")) if os.path.exists(GCACHE) else None
def ghost():
    global GHOST
    if GHOST is None:
        GHOST = _ghost(); pickle.dump(GHOST, open(GCACHE, "wb"))
    return GHOST
GLAB = [("Asia Minor, 1919–22", 39.35, 29.6, "center"), ("Eastern Thrace, 1920–22", 41.55, 27.15, "center"),
        ("Northern Epirus,", 40.62, 20.55, "center"), ("1912–16, 1940–41", 40.48, 20.55, "center"), ("Imbros and Tenedos,", 40.10, 25.55, "right"), ("1912–23", 39.96, 25.55, "right"),
        ("Southern Bulgaria, 1913", 41.95, 23.5, "center")]
@functools.lru_cache(maxsize=2)
def ghost_layer(camkey):
    cam = np.array(camkey); f, s = to_px(cam)
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, MW, MH); ctx = cairo.Context(surf)
    path_geom(ctx, ghost(), f); ctx.set_source_rgba(*C["df"], 0.30); ctx.fill_preserve()
    ctx.set_source(hatch(C["hatch"], 0.55, 45)); ctx.fill(); ctx.new_path()
    return surf_to_np(surf)
def ghost_labels(ctx, cam, a):
    f, s = to_px(cam)
    for lab, la, lo, al in GLAB:
        x, y = f(*proj(lo, la))
        halo_text(ctx, lab, x, y, (0.10, 0.22, 0.42), 19, FONT_SANS_SB, a=a, align=al)

# ------------------------------------------------------------------ the frame
def frame(t):
    if t >= T_CUT:
        img = card_image()
        if t > T_TOTAL - 1.0: img = (img.astype(np.float32) * max(0, (T_TOTAL - t)) + np.array(PAPER) * (1 - max(0, T_TOTAL - t))).astype(np.uint8)
        return img
    day = day_at(t)
    k = state_index(int(day)) + 1
    cam = camera(t)
    static = is_static(t)
    camkey = tuple(np.round(cam, 1))
    tk = t_at(STATE_DAYS[k]) if k > 0 else -1
    fading = k > 0 and 0 <= t - tk < FADE
    if static:
        img = static_map(k, camkey)
        if fading:
            u = (t - tk) / FADE
            img = static_map(k - 1, camkey) * (1 - u) + img * u
    else:
        rgb, land = base_view(cam); ref = refs_layer(cam)
        fills, lines = overlay(k, cam)
        if fading:
            u = (t - tk) / FADE
            pf, pl = overlay(k - 1, cam)
            fills = pf * (1 - u) + fills * u; lines = pl * (1 - u) + lines * u
        img = rgb.astype(np.float32) / 255.0
        img = composite(img, ref)
        img = composite(img, fills, land)
        img = composite(img, lines)
    ga = 0.0
    if t > T_GHOST0: ga = min(1.0, (t - T_GHOST0) / (T_FLASH - T_GHOST0)) ** 1.5
    if ga > 0:
        gl = ghost_layer(camkey) if static else ghost_layer(tuple(np.round(cam, 1)))
        img = composite(img, gl * ga, static_base(camkey)[1] if static else land)
    # marks and labels (cairo on top)
    out = np.zeros((H, W, 3), np.float32)
    out[:, PW:] = img
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); ctx = cairo.Context(surf)
    ctx.save(); ctx.translate(PW, 0); ctx.rectangle(0, 0, MW, MH); ctx.clip()
    city_labels(ctx, cam, t); zone_marks(ctx, day, cam); marks(ctx, t, cam)
    if ga > 0: ghost_labels(ctx, cam, ga)
    ctx.restore()
    panel(ctx, t, day, k)
    top = surf_to_np(surf)
    a = top[..., 3:4]
    out = out * (1 - a) + top[..., [2, 1, 0]]
    # intro title fade
    return (np.clip(out, 0, 1) * 255).astype(np.uint8)


# ------------------------------------------------------------------ the summary card
SITE = "iosiflazaridis.github.io/borders-of-greece"
@functools.lru_cache(None)
def card_image():
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); ctx = cairo.Context(surf)
    ctx.set_source_rgb(*C["paper"]); ctx.paint()
    L = 96
    font(ctx, FONT_HEAD, 64); text(ctx, "THE BORDERS OF GREECE", L, 118, C["ink"])
    font(ctx, FONT_SERIF, 30, italic=True); text(ctx, "Τὰ σύνορα τοῦ ἑλληνικοῦ κράτους, 1821 – σήμερα", L + 2, 166, C["ink2"])
    font(ctx, FONT_SANS, 26)
    text(ctx, "The land held by Greece and its armed forces, from the revolution of 1821 to today, in square kilometers", L + 2, 214, C["ink"])
    # chart
    x0, x1, y0, y1 = L + 70, W - L, 790, 300
    vmax = 280000
    def X(d): return x0 + (d - D0) / (D1 - D0) * (x1 - x0)
    def Y(v): return y0 - v / vmax * (y0 - y1)
    xs, ys = area_series()
    font(ctx, FONT_SANS, 18)
    for v in (50000, 100000, 150000, 200000, 250000):
        ctx.set_source_rgba(*C["hair"], 1); ctx.rectangle(x0, Y(v), x1 - x0, 1); ctx.fill()
        text(ctx, f"{v:,}", x0 - 12, Y(v) + 6, C["muted"], align="right")
    for yr in range(1830, 2030, 10):
        d = dt.date(yr, 1, 1).toordinal()
        ctx.set_source_rgba(*C["muted"], 1); ctx.rectangle(X(d), y0, 1, 7); ctx.fill()
        if yr % 20 == 0 or yr == 1830: text(ctx, str(yr), X(d), y0 + 30, C["muted"], align="center")
    def band(lo_keys, key, rgb, a, hat=None):
        top_, bot_ = [], []
        for i in range(len(xs)):
            xa = X(xs[i]); xb = X(xs[i + 1] if i + 1 < len(xs) else D1)
            b_ = sum(ys[i][q] for q in lo_keys); t_ = b_ + ys[i][key]
            top_ += [(xa, Y(t_)), (xb, Y(t_))]; bot_ += [(xa, Y(b_)), (xb, Y(b_))]
        ctx.move_to(*top_[0])
        for p in top_[1:]: ctx.line_to(*p)
        for p in reversed(bot_): ctx.line_to(*p)
        ctx.close_path(); ctx.set_source_rgba(*rgb, a); ctx.fill_preserve()
        if hat: ctx.set_source(hat); ctx.fill_preserve()
        ctx.new_path()
    band([], "dj", C["dj"], 0.85)
    band(["dj"], "occ", C["occ"], 0.55, hatch((0.18, 0.18, 0.18), 0.8, 135))
    band(["dj", "occ"], "df", C["df"], 0.75, hatch(C["hatch"], 0.85, 45))
    ctx.set_source_rgba(*C["ink2"], 1); ctx.rectangle(x0, y0, x1 - x0, 1.5); ctx.fill()
    # notes on the chart
    def at(datestr):
        k = state_index(ordn(datestr)) + 1; a = areas(k); return a
    best = max(range(len(ys)), key=lambda i: ys[i]["dj"] + ys[i]["df"])
    bd = dt.date.fromordinal(xs[best]); bv = ys[best]["dj"] + ys[best]["df"]
    notes = [("1833-06-01", "1832–33: the kingdom"), ("1864-07-01", "1864: the Ionian Islands"), ("1881-12-01", "1881: Thessaly, Arta"),
             ("1914-03-01", "1912–14: Macedonia, Epirus, Crete, the islands"), ("1947-10-01", "1947: the Dodecanese")]
    font(ctx, FONT_SANS_M, 19)
    for d_, lab in notes:
        a = at(d_); xx = X(ordn(d_)); v = a["dj"] + a["occ"]; yy = Y(v) - 14
        if lab.startswith("1864"):
            ctx.set_source_rgba(*C["ink2"], 1); ctx.rectangle(xx, yy - 56, 1.2, 66); ctx.fill()
            text(ctx, lab, xx - 4, yy - 64, C["ink"])
        elif lab.startswith("1912"): text(ctx, lab, xx - 10, yy, C["ink"], align="right")
        elif lab.startswith("1947"): text(ctx, lab, xx + 8, yy, C["ink"])
        else: text(ctx, lab, xx - 4, yy, C["ink"])
    text(ctx, f"{bd.strftime('%B %Y')}: {round(bv, -2):,.0f} km² held", X(xs[best]) + 14, Y(bv) + 8, C["ink"])
    text(ctx, "1941–44: occupied", X(ordn("1944-11-01")) + 10, Y(118000), (1, 1, 1))
    # legend
    ly = 880
    items = [("dj", "Greek state, recognized", None), ("df", "Held by Greece or its armed forces, not recognized (including the revolution, 1821–32)", 45),
             ("occ", "Greek territory under foreign occupation", 135)]
    lx = L
    font(ctx, FONT_SANS, 21)
    for key, lab, sty in items:
        ctx.rectangle(lx, ly - 16, 34, 20)
        fa = {"dj": 0.85, "df": 0.75, "occ": 0.55}[key]
        ctx.set_source_rgba(*C[key], fa); ctx.fill_preserve()
        if sty: ctx.set_source(hatch({"df": C["hatch"], "occ": (0.18, 0.18, 0.18)}[key], 0.85, sty)); ctx.fill()
        else: ctx.new_path()
        w_ = text(ctx, lab, lx + 46, ly, C["ink"]); lx += 46 + w_ + 40
    font(ctx, FONT_SANS, 18)
    text(ctx, "Areas computed from present-day boundaries (about ±1%); the official area of Greece today is 131,957 km². "
              "Not counted: the risings of 1854 and 1878, the autonomous Samos, Crete and Northern Epirus, and lands awarded but never held.", L, 936, C["ink2"])
    text(ctx, f"Data: {len(T.EV)} dated changes of control, compiled from the treaties, Greek, Turkish and English sources and standard histories, each with its sources, at {SITE}.", L, 966, C["ink2"])
    text(ctx, "Battles: the Modern Greek Battles set. Boundaries: geoBoundaries (CC BY 4.0), Natural Earth. Relief: AWS Terrain Tiles. Music: the phorminx, in the Dorian harmonia.", L, 996, C["ink2"])
    a = np.ndarray((H, W, 4), np.uint8, surf.get_data())[..., [2, 1, 0]].copy()
    return a

def total_frames():
    return int(math.ceil(T_TOTAL * FPS))

if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "info":
        print("states", len(STATE_DAYS), "map ends at", round(T_END_MAP, 1), "s;", total_frames(), "frames")
        print("flow", round(SEC.sum(), 1), "holds", round(HOLDS.sum(), 1))
        for c in CAPS: print(f"{c['t0']:7.1f}  {c['date']}  {c['title'][:60]}")
        for yr in (1822, 1830, 1850, 1881, 1897, 1912, 1913, 1920, 1922, 1923, 1940, 1945, 1950, 2000):
            print(yr, round(t_at(dt.date(yr, 1, 1).toordinal()), 1))
    elif cmd == "clock":
        per = [t_at(ordn(d)) for d in ("1821-03-29", "1832-08-30", "1912-10-18", "1919-05-15", "1923-07-24", "1940-10-28", "1949-08-30")]
        json.dump(dict(DUR=T_TOTAL, stops=[(c["t0"], read(c), c["title"]) for c in CAPS if c["kind"] != "end"], periods=[[p] for p in per],
                       T_TODAY=TDAY[-1], T_PULL0=TDAY[-1] - 3.0, T_GHOST0=T_GHOST0, T_FLASH=T_FLASH, T_CUT=T_CUT, FPS=FPS),
                  open(f"{FILM}/out_clock.json", "w"), indent=1)
        print("clock written", T_TOTAL)
    elif cmd == "cache":
        import time; t0 = time.time()
        for k in range(len(STATE_DAYS)):
            classes_proj(k); areas(k)
            if k % 50 == 0: print(k, round(time.time() - t0), flush=True)
        pickle.dump(_SC, open(CACHE, "wb")); print("cached", len(_SC))
    elif cmd == "still":
        arg = sys.argv[2]
        t = float(arg[2:]) if arg.startswith("t=") else t_at(ordn(arg) + 0.5)
        img = frame(t)
        out = sys.argv[3] if len(sys.argv) > 3 else f"{FILM}/still.png"
        cv2.imwrite(out, img[..., ::-1]); print(out, round(t, 2))
    elif cmd == "render":
        k, n = int(sys.argv[2]), int(sys.argv[3])
        N = total_frames(); a, b = N * k // n, N * (k + 1) // n
        os.makedirs(f"{FILM}/out", exist_ok=True)
        p = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS),
                              "-i", "-", "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", f"{FILM}/out/part{k}.mp4"],
                             stdin=subprocess.PIPE)
        import time; t0 = time.time()
        for i in range(a, b):
            p.stdin.write(frame(i / FPS).tobytes())
            if (i - a) % 300 == 0: print(k, i, round(time.time() - t0), flush=True)
        p.stdin.close(); p.wait(); print("done", k, a, b, round(time.time() - t0))
