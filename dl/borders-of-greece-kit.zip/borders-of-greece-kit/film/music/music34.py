"""Music for The Borders of Greece (set 34), adapted from the music of set 32 (same instrument, tuning and manner; Iosif on
set 32: "The music is not the showpiece, it's an accompaniment"; no sound effects; "a loud finish that cuts to the summary
slide/credits"; "a Dorian diatonic harmony"). The text below is the set 32 description, which still applies.

Music for Where the Greeks and Romans Fought: an accompaniment, not a showpiece (Iosif: "The music is not the
showpiece, it's an accompaniment"; no sound effects), with "a loud finish that cuts to the summary slide/credits",
in "a Dorian diatonic harmony" (Iosif, 23 Oct 2026).

The instrument: the I1 gut phorminx (gut_strings.py, the approved copy, md5 a29760fd...), eight strings tuned to the
Dorian octave of the Greater Perfect System, hypate meson to nete diezeugmenon, e to e', in the Pythagorean
(ditonic) diatonic: each tetrachord limma, tone, tone (256:243, 9:8, 9:8) upward, the two disjoined by a tone:
    E 165.00  F 173.83  G 195.56  A 220.00 (mese)  B 247.50  C 260.74  D 293.33  E' 330.00
and, for the last two strokes only, the deeper strings A 110 (proslambanomenos), B 123.75, E 82.5.
Harmony is by the consonances the Greeks recognised, fourth, fifth and octave: E-B, A-E', E-A, B-E'.

The body of the film: finger plucks (psallein), soft, about one every two seconds, in short phrases that come to
rest on a standing note (hypate E, mese A, paramese B, nete E'); each turning point is met by a soft fifth A-E' and
the plucking slows while its text is read; each new period by a soft fifth E-B.
The end: while the camera pulls back, a few low notes; then strokes of the plectrum on E-B-E', closer and louder,
up to the flash of all the battles, struck on A-E-A-E' (on mese); the last and loudest stroke, E-B-E-B-E' on hypate,
falls on the cut to the summary card and rings under it; three soft plucks close.
Reads ../out/film_clock.json; writes music32.wav (stereo, 44.1 kHz) and score32.json.
"""
import json, os, math
import numpy as np
import soundfile as sf
from scipy.signal import fftconvolve, sosfilt, butter
from scipy.ndimage import maximum_filter1d, minimum_filter1d, uniform_filter1d
import pyloudnorm as pyln
import gut_strings as gs

HERE = os.path.dirname(os.path.abspath(__file__))
FS = gs.FS
CLK = json.load(open(os.path.join(HERE, '..', 'out_clock.json')))
DUR = CLK['DUR']
A3 = 220.0
RAT = [3 / 4, 3 / 4 * 256 / 243, 3 / 4 * 256 / 243 * 9 / 8, 1.0, 9 / 8, 9 / 8 * 256 / 243, 9 / 8 * 256 / 243 * 9 / 8, 3 / 2]
NAMES = ['E', 'F', 'G', 'A', 'B', 'C', 'D', "E'"]
HZ = {n: A3 * r for n, r in zip(NAMES, RAT)}
HZ.update({'A,': 110.0, 'B,': 123.75, 'E,': 82.5})
STANDING = (0, 3, 4, 7)
def t60_of(f): return 3.6 - 1.25 * np.log2(f / 146.83)

EV = []
def pluck(t, s, vel, ring=3.4, finger=True, t60x=1.0, final=False, amp=1.0):
    EV.append(dict(t=round(float(t), 3), s=s, f=HZ[s], vel=float(vel), finger=finger, t60x=t60x, amp=amp,
                   ring_to=None if final else float(t) + 0.5 + ring))
def dyad(t, a, b, vel=0.40):
    pluck(t, a, vel); pluck(t + 0.035, b, vel * 0.88)
def strum(t, strings, vel, gap=0.022, t60x=1.0, final=False, ring=4.0, amp=1.0):
    for k, s in enumerate(strings):
        pluck(t + k * gap, s, vel * (1.0 - 0.04 * k), finger=False, t60x=t60x, final=final, ring=ring, amp=amp)

def next_string(rng, cur):
    cand = []
    for s in range(8):
        dd = abs(s - cur)
        if dd == 0: w = 0.25
        elif dd > 4: continue
        else: w = {1: 1.0, 2: 0.75, 3: 0.5, 4: 0.35}[dd]
        if s in STANDING: w *= 1.5
        if s == 3: w *= 1.3                                  # mese, the centre
        cand.append((s, w))
    ss, ww = zip(*cand); ww = np.array(ww) / sum(ww)
    return int(rng.choice(ss, p=ww))

# ---------------------------------------------------------------- the body
STOPS = [(a, L) for a, L, _ in CLK['stops']]
PER = [p[0] for p in CLK['periods'][1:]]
T_END_BODY = CLK['T_PULL0'] - 0.6
def reading(t):
    return any(a - 0.2 <= t < a + L for a, L in STOPS)
marks = sorted([(a, 'stop') for a, L in STOPS] + [(p, 'period') for p in PER])
rng = np.random.default_rng(34)
dyad(0.8, 'E', 'B', 0.36)
t = 3.0; cur = 3; phrase_left = int(rng.integers(4, 8)); mi = 0
while t < T_END_BODY:
    while mi < len(marks) and marks[mi][0] <= t + 0.05:         # a turning point or a new period: a soft fifth
        tm, kind = marks[mi]; mi += 1
        if kind == 'stop': dyad(tm, 'A', "E'", 0.42); t = max(t, tm + 2.6); cur = 3
        elif not any(abs(tm - a) < 1.0 for a, _ in STOPS): dyad(tm, 'E', 'B', 0.38); t = max(t, tm + 2.2); cur = 0
    if t >= T_END_BODY: break
    if mi < len(marks) and marks[mi][0] - t < 0.9:              # leave room before the mark
        t = marks[mi][0]; continue
    cur = next_string(rng, cur); phrase_left -= 1
    if phrase_left <= 0 and cur not in STANDING:
        cur = min(STANDING, key=lambda s: abs(s - cur))         # the phrase comes to rest on a standing note
    pluck(t, NAMES[cur], float(rng.uniform(0.38, 0.50)))
    if rng.random() < 0.10:                                     # now and then a fourth or fifth below
        low = {7: 4, 4: 0, 3: 0, 6: 3}.get(cur)
        if low is not None: pluck(t + 0.03, NAMES[low], 0.33)
    gap = 1.9 * (1.35 if reading(t) else 1.0)
    if phrase_left <= 0 and cur in STANDING:
        gap *= 1.5; phrase_left = int(rng.integers(4, 8))
    t += float(gap * rng.uniform(0.75, 1.15))

# ---------------------------------------------------------------- the end
P0, TF, TC = CLK['T_PULL0'], CLK['T_FLASH'], CLK['T_CUT']
pluck(P0 + 0.3, 'A', 0.40, ring=4.5); pluck(P0 + 2.3, 'E', 0.38, ring=4.0); pluck(P0 + 3.9, 'B', 0.36, ring=3.0)
build = [(-2.40, 0.34), (-1.62, 0.44), (-1.04, 0.54), (-0.60, 0.64), (-0.30, 0.74), (-0.12, 0.80)]
for dt, v in build: strum(TF + dt, ['E', 'B', "E'"], v, gap=0.018, ring=0.6, amp=0.30 + 0.45 * (v - 0.34) / 0.46)
strum(TF - 0.05, ['A,', 'E', 'A', "E'"], 0.98, gap=0.016, t60x=1.3, ring=2.2, amp=0.62)     # all the battles at once: on mese
strum(TC - 0.04, ['E,', 'B,', 'E', 'B', "E'"], 1.0, gap=0.014, t60x=1.7, final=True, amp=0.78)  # the cut: on hypate
for k, (dt, s) in enumerate(((5.2, 'B'), (7.2, 'A'), (9.2, 'E'))):
    pluck(TC + dt, s, 0.32 - 0.02 * k, ring=4.5 if k < 2 else 6.0, final=(k == 2))
EV.sort(key=lambda e: e['t'])

def render():
    n_total = int((DUR + 0.5) * FS)
    dry = np.zeros(n_total)
    by_s = {}
    for e in EV: by_s.setdefault(e['s'], []).append(e)
    seed = 32
    for s, evs in by_s.items():
        for k, ev in enumerate(evs):
            nxt = evs[k + 1]['t'] if k + 1 < len(evs) else None
            end = (ev['ring_to'] + 5 * 0.24) if ev['ring_to'] is not None else DUR + 0.5
            if nxt is not None: end = min(end, nxt + 0.014)
            n = int((end - ev['t']) * FS) + 1
            y = gs.gut_pluck(ev['f'], n, vel=ev['vel'], seed=seed, t60=t60_of(ev['f']) * ev['t60x'], finger=ev['finger'],
                             point=1 / 5.2 if ev['finger'] else 1 / 6.5)
            seed += 1
            tt = np.arange(n) / FS; env = np.ones(n)
            if ev['ring_to'] is not None:
                ds = ev['ring_to'] - ev['t']; m = tt > ds; env[m] = np.exp(-(tt[m] - ds) / 0.24)
            if nxt is not None:
                cut = int((nxt - ev['t']) * FS)
                if cut < n: env[cut:] *= np.linspace(1, 0, n - cut)
            i0 = int(round(ev['t'] * FS)); seg = (y * env * ev['amp'])[:n_total - i0]
            dry[i0:i0 + len(seg)] += seg
    dry = gs.add_sympathetic_strings(dry, [(HZ[s], t60_of(HZ[s]) * 1.1) for s in ('E', 'A', 'B', "E'")], amount=0.010)
    wet = gs.body_phorminx(dry) * 0.5
    rr = np.random.default_rng(3)
    def tail(seconds, lo, hi, gain):
        n = int(seconds * FS); tt = np.arange(n) / FS
        ir = rr.normal(0, 1, n) * np.exp(-6.9 * tt / seconds)
        ir = sosfilt(butter(2, [lo, hi], 'bandpass', fs=FS, output='sos'), ir); ir[:int(0.012 * FS)] = 0
        return ir / (np.abs(ir).max() + 1e-9) * gain
    irL = tail(2.4, 90, 6000, 0.07); irR = tail(2.45, 90, 5600, 0.07)
    for d_ms, g_ in ((11, 0.16), (23, 0.11), (37, 0.08)):
        dd = int(d_ms * FS / 1000); irL[dd] += g_; irR[dd + 3] += g_ * 0.9
    L = wet + fftconvolve(wet, irL)[:n_total]; R = wet + fftconvolve(wet, irR)[:n_total]
    st = np.stack([0.92 * L + 0.08 * R, 0.08 * L + 0.92 * R], axis=1)[:int(DUR * FS)]
    fade = np.ones(len(st)); nf = int(2.0 * FS); fade[-nf:] = np.linspace(1, 0, nf) ** 1.5
    st *= fade[:, None]
    meter = pyln.Meter(FS)
    body = st[:int((P0 - 1.0) * FS)]
    st = st * 10 ** ((-21.0 - meter.integrated_loudness(body)) / 20)      # the body at -21 LUFS, so that the end can be loud
    # a gentle limiter for the last strokes (peak 0.93): look-ahead gain, smoothed
    pk = maximum_filter1d(np.abs(st).max(axis=1), int(0.006 * FS))
    g = np.minimum(1.0, 0.93 / np.maximum(pk, 1e-9))
    w = int(0.008 * FS); g = uniform_filter1d(minimum_filter1d(g, 2 * w), w)
    st = st * g[:, None]
    lim = float(1.0 - g.min())
    return st, meter.integrated_loudness(body * 1.0), float(np.abs(st).max()), lim, meter

if __name__ == '__main__':
    st, lufs_body, pk, lim, meter = render()
    sf.write(os.path.join(HERE, 'music34.wav'), st.astype(np.float32), FS)
    json.dump([dict(t=e['t'], string=e['s'], hz=round(e['f'], 3), vel=round(e['vel'], 2), plectrum=not e['finger']) for e in EV],
              open(os.path.join(HERE, 'score34.json'), 'w'), indent=0)
    i0, i1 = int((TC - 0.2) * FS), int((TC + 3.0) * FS)
    print(f'plucks {len(EV)}; peak {pk:.3f}; limiter reduced by up to {lim * 100:.0f}%; whole film {meter.integrated_loudness(st):.1f} LUFS; '
          f'last stroke {meter.integrated_loudness(st[i0:i1]):.1f} LUFS (3 s)')
    print('Hz:', {k: round(v, 2) for k, v in HZ.items()})
