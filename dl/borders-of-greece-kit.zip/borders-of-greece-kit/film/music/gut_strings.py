"""The gut-string lyre model, copied from Gemini's AthenaHymn/Gemini/_build/gemini_instruments.py (the "I1" gut
phorminx Iosif chose on 13 October 2026: "I1 is awesome"; heard in full in Music/AthenaHymn/GutPhorminx_V1). Only
add_sympathetic_strings is changed: it takes the fixed strings of the lyre it is given, instead of the Athena hymn's.

  gut_pluck(f, n, vel, seed, t60, finger, point, ...)  one plucked gut string: a coherent geometric pluck + shaped
      release texture (no white-noise buzz), plectrum tick or finger-pad contact, two polarisations (+1.1 cents,
      longer decay), and a few cents of tension "bloom" in the first ~35 ms of a plectrum stroke;
  body_phorminx(x)   the hollowed-wood sound box (ten resonances 168 Hz - 5.8 kHz, short cavity reflections);
  add_sympathetic_strings(x, strings)   the open strings ringing in sympathy.
"""
import numpy as np
from scipy.signal import lfilter, sosfilt, butter

FS = 44100


def _allpass_delay(c, w):
    z = np.exp(-1j * w)
    H = (c + z) / (1 + c * z)
    return -np.angle(H) / w


def loop_params(f, brightness_a=0.17, t60=3.2):
    """Solve exact integer delay M and all-pass coefficient c so phase delay at f is FS/f."""
    D = FS / f
    w = 2 * np.pi * f / FS
    M = int(np.floor(D - 1 - 0.1))
    need = D - M - 1.0
    lo, hi = -0.999, 0.999
    for _ in range(80):
        mid = (lo + hi) / 2
        if _allpass_delay(mid, w) > need:
            lo = mid
        else:
            hi = mid
    c = (lo + hi) / 2
    a = brightness_a
    Lmag = (1 - 2 * a) + 2 * a * np.cos(w)
    g = 10 ** (-3 / (f * t60)) / Lmag
    return M, c, a, g


def _gut_excitation(P, vel, rng, finger=False, point=1.0 / 6.5):
    """Coherent physical gut-string excitation:
    Combines a sharp geometric pluck release wave (whose corner width is narrow for a horn
    plectrum and slightly wider for a fingertip) with shaped, comb-filtered gut release texture.
    """
    x_pos = np.linspace(0.0, 1.0, P, endpoint=False)
    p = float(np.clip(point, 0.10, 0.45))

    # 1. Geometric string slope wave (coherent harmonic phase = woody, non-buzzy core)
    slope = np.where(x_pos < p, 1.0 / p, -1.0 / (1.0 - p))
    slope -= slope.mean()
    # Narrow smoothing window so upper harmonics (1-5 kHz) are strong and articulate at attack
    c_width = (0.026 if finger else 0.011) * (1.15 - 0.25 * vel)
    win_len = max(1, int(round(P * c_width)))
    if win_len > 1:
        win = np.hanning(2 * win_len + 1)[1:-1]
        win /= win.sum()
        pad = np.concatenate([slope[-win_len:], slope, slope[:win_len]])
        geom = np.convolve(pad, win, mode='same')[win_len:win_len + P]
    else:
        geom = slope.copy()
    geom /= (np.sqrt(np.mean(geom ** 2)) + 1e-12)

    # 2. Comb-filtered organic pluck noise (the plectrum/finger release crispness)
    raw = rng.uniform(-1, 1, P) * (np.hanning(P) ** 0.35)
    alpha = (0.28 + 0.32 * vel) if finger else (0.42 + 0.42 * vel)
    tex = lfilter([alpha], [1, -(1 - alpha)], raw)
    k = max(1, int(round(P * p)))
    tex2 = tex.copy()
    tex2[k:] -= tex[:-k]
    # Add a second comb notch at p*0.5 for finite plectrum contact nuance
    k2 = max(1, int(round(P * (0.018 if not finger else 0.032))))
    if k2 < P:
        tex2[k2:] += 0.35 * tex[:-k2]
    tex2 /= (np.sqrt(np.mean(tex2 ** 2)) + 1e-12)

    # Blend coherent geometric wave + crisp release texture
    w_geom = 0.48 if finger else 0.38
    exc = w_geom * geom + (1.0 - w_geom) * tex2
    exc /= (np.abs(exc).max() + 1e-12)
    return exc * vel


def _run_waveguide(x, M, c, a, g):
    L = np.array([a, 1 - 2 * a, a])
    LA = np.convolve(L, [c, 1.0])
    den = np.zeros(M + 4)
    den[0] = 1.0
    den[1] += c
    den[M:M + 4] -= g * LA
    return lfilter([1.0, c], den, x)


def _apply_tension_bloom(y, cents_init=4.5, tau_s=0.032):
    """Real gut strings plucked hard with a plectrum start slightly sharp (+4-6 cents) due to
    initial displacement tension and settle exponentially to exact pitch within ~35 ms.
    Implemented by a tiny time-warping interpolation over the first 120 ms (zero pitch shift after).
    """
    if cents_init <= 0.1:
        return y
    n = len(y)
    n_warp = min(n, int(0.14 * FS))
    t = np.arange(n_warp) / FS
    # Instantaneous frequency ratio r(t) = 1 + dc * exp(-t/tau)
    dc = (2.0 ** (cents_init / 1200.0)) - 1.0
    # Phase integral of (r(t) - 1) in samples, vanishing at t >= n_warp
    shift_samples = dc * tau_s * FS * (1.0 - np.exp(-t / tau_s))
    # Smoothly taper the phase offset back to 0 between 50 ms and 130 ms so steady pitch is 100% untouched
    taper = np.clip((0.13 - t) / 0.08, 0.0, 1.0)
    shift_samples *= taper * taper * (3 - 2 * taper)
    idx = np.arange(n_warp, dtype=np.float64) + shift_samples
    idx = np.clip(idx, 0, n - 1)
    out = y.copy()
    out[:n_warp] = np.interp(idx, np.arange(n, dtype=np.float64), y)
    return out


def gut_pluck(f, n_samples, vel=0.8, seed=0, t60=3.2, finger=False, point=1.0 / 6.2,
              bright_plectrum=0.165, bright_finger=0.205, dual_pol=True, bloom_cents=4.2):
    """Render one plucked gut string with coherent geometric+texture excitation, tension bloom,
    and dual-polarization coupling."""
    rng = np.random.default_rng(seed)
    P = max(8, int(round(FS / f)))
    a1 = bright_finger if finger else bright_plectrum
    a1 = float(np.clip(a1 - 0.025 * (vel - 0.80), 0.13, 0.26))

    M1, c1, a1, g1 = loop_params(f, a1, t60)
    exc = _gut_excitation(P, vel, rng, finger=finger, point=point)

    x1 = np.zeros(n_samples)
    n_exc = min(P, n_samples)
    x1[:n_exc] = exc[:n_exc]

    # Crisp horn plectrum / fingernail transient (shaped around 800-4500 Hz, not raw white noise)
    if not finger:
        t_len = min(110, n_samples)
        tt = np.arange(t_len) / FS
        sos_t = butter(2, [700, 4800], 'bandpass', fs=FS, output='sos')
        tick = sosfilt(sos_t, rng.normal(0, 1, t_len)) * np.exp(-tt / 0.0011) * 0.075 * vel
        x1[:t_len] += tick
    else:
        t_len = min(120, n_samples)
        tt = np.arange(t_len) / FS
        sos_t = butter(2, [350, 2600], 'bandpass', fs=FS, output='sos')
        tick = sosfilt(sos_t, rng.normal(0, 1, t_len)) * np.exp(-tt / 0.0018) * 0.032 * vel
        x1[:t_len] += tick

    y1 = _run_waveguide(x1, M1, c1, a1, g1)

    if dual_pol:
        # Second polarization (parallel to soundboard): detuned +1.1 cents, slightly longer T60
        f2 = f * (2.0 ** (1.1 / 1200.0))
        M2, c2, a2, g2 = loop_params(f2, min(0.28, a1 + 0.035), t60 * 1.25)
        x2 = np.zeros(n_samples)
        x2[:n_exc] = exc[:n_exc] * 0.25
        y2 = _run_waveguide(x2, M2, c2, a2, g2)
        y = 0.85 * y1 + 0.22 * y2
    else:
        y = y1

    # Subtle nonlinear tension bloom on plectrum strokes
    if not finger and bloom_cents > 0:
        y = _apply_tension_bloom(y, cents_init=bloom_cents * (vel ** 1.2), tau_s=0.028)
    elif finger and bloom_cents > 0:
        y = _apply_tension_bloom(y, cents_init=0.45 * bloom_cents * (vel ** 1.2), tau_s=0.024)

    return y


def _peak(fc, gain_db, q):
    A = 10 ** (gain_db / 40.0)
    w0 = 2 * np.pi * fc / FS
    al = np.sin(w0) / (2 * q)
    b = np.array([1 + al * A, -2 * np.cos(w0), 1 - al * A])
    a = np.array([1 + al / A, -2 * np.cos(w0), 1 - al / A])
    return np.hstack([b / a[0], a / a[0]])


def body_phorminx(x):
    """Hollowed-wood cradle phorminx soundbox: fuller low-mid wood resonance (165-680 Hz) +
    articulate upper wood projection (1.1-3.2 kHz) + 3D short wood-cavity reflections."""
    modes = [
        _peak(168, 5.8, 1.5),    # main air cavity / sound-hole helmholtz resonance
        _peak(265, 4.2, 1.9),    # lower soundboard dipole
        _peak(395, 3.6, 2.0),    # cradle body wood mode
        _peak(580, 2.4, 2.2),    # yoke & arm coupling
        _peak(860, 2.2, 2.0),    # upper plate mode
        _peak(1420, 2.0, 1.8),   # clear pluck articulation
        _peak(2150, 1.4, 1.6),
        _peak(2850, -1.8, 1.8),  # gentle dip right at singer's formant peak (2.85 kHz)
        _peak(3900, 1.2, 1.6),   # plectrum air/definition
        _peak(5800, -4.5, 0.8),
    ]
    y = sosfilt(np.array(modes), x)
    n = len(y)
    body_ir = y.copy()
    for delay_ms, gain in ((0.48, 0.18), (1.15, -0.12), (2.30, 0.08)):
        d = int(round(delay_ms * 0.001 * FS))
        if d < n:
            body_ir[d:] += gain * y[:-d]
    hp = butter(2, 62, 'highpass', fs=FS, output='sos')
    return sosfilt(hp, body_ir)


def body_kithara(x):
    """Deep concert kithara chest (resonances down to 110 Hz, rich wood body + clear attack)."""
    modes = [
        _peak(114, 6.2, 1.4),    # deep kithara chest cavity
        _peak(185, 4.8, 1.7),    # lower plate mode
        _peak(290, 3.8, 1.9),
        _peak(440, 3.0, 2.0),
        _peak(680, 2.4, 2.0),
        _peak(1250, 2.0, 1.7),
        _peak(1950, 1.5, 1.6),
        _peak(2850, -2.0, 1.8),  # pocket for singer's formant
        _peak(3800, 1.0, 1.5),
        _peak(5400, -5.0, 0.8),
    ]
    y = sosfilt(np.array(modes), x)
    n = len(y)
    body_ir = y.copy()
    for delay_ms, gain in ((0.65, 0.20), (1.55, -0.13), (2.90, 0.09)):
        d = int(round(delay_ms * 0.001 * FS))
        if d < n:
            body_ir[d:] += gain * y[:-d]
    hp = butter(2, 42, 'highpass', fs=FS, output='sos')
    return sosfilt(hp, body_ir)


def body_chelys(x):
    """Tortoise-shell bowl lyre (chelys) with ox-hide belly (luminous, crisp, intimate)."""
    modes = [
        _peak(255, 4.5, 1.6),
        _peak(460, 3.8, 1.9),
        _peak(820, 2.8, 2.0),
        _peak(1550, 2.2, 1.8),
        _peak(2600, 1.5, 1.6),
        _peak(6000, -4.0, 0.8),
    ]
    y = sosfilt(np.array(modes), x)
    hp = butter(2, 110, 'highpass', fs=FS, output='sos')
    return sosfilt(hp, y)


def add_sympathetic_strings(dry_signal, strings, amount=0.012):
    """Couple bridge vibration into the fixed (open) strings: strings = [(Hz, T60 s), ...]"""
    out = np.zeros_like(dry_signal)
    lo = max(60.0, 0.85 * min(f for f, _ in strings))
    drive = sosfilt(butter(2, [lo, 1600], 'bandpass', fs=FS, output='sos'), dry_signal)
    for f, t60 in strings:
        M, c, a, g = loop_params(f, brightness_a=0.24, t60=t60)
        symp = _run_waveguide(drive * amount, M, c, a, g)
        out += symp
    return dry_signal + out


