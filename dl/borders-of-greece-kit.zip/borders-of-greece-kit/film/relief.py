"""Relief base for the Borders of Greece film: Lambert conformal conic, warm hypsometric tint, multi-directional
hillshade, slate-blue sea darker offshore with a pale coastal rim. Writes base_<res>.npz (rgb uint8 + land mask) and
the projection parameters. usage: python3 relief.py [km_per_px]"""
import json, sys, numpy as np
from pyproj import Transformer
from scipy.ndimage import map_coordinates, gaussian_filter, distance_transform_edt
from shapely.geometry import shape
from PIL import Image, ImageDraw

KM = float(sys.argv[1]) if len(sys.argv) > 1 else 0.5
PROJ = "+proj=lcc +lat_1=36 +lat_2=44 +lat_0=40 +lon_0=25 +datum=WGS84 +units=m +no_defs"
fwd = Transformer.from_crs("EPSG:4326", PROJ, always_xy=True)
inv = Transformer.from_crs(PROJ, "EPSG:4326", always_xy=True)
# projected extent: the largest rectangle inside the DEM (lon 18..34, lat 34..47.5), less a 3 km margin
la = np.linspace(34, 47.5, 200); lo = np.linspace(18, 34, 200)
xw, _ = fwd.transform(np.full(200, 18.0), la); xe, _ = fwd.transform(np.full(200, 34.0), la)
_, ys = fwd.transform(lo, np.full(200, 34.0)); _, yn = fwd.transform(lo, np.full(200, 47.5))
x0, x1, y0, y1 = xw.max() + 3000, xe.min() - 3000, ys.max() + 3000, yn.min() - 3000
W = int((x1 - x0) / (KM * 1000)); H = int((y1 - y0) / (KM * 1000))
print("base", W, H, "px at", KM, "km/px")

dem = np.load("/home/claude/gb/dem/dem_18_34_34_47.5_r96.npy").astype(np.float32)
RES, LON0, LAT1 = 96, 18.0, 47.5
# lon/lat of every pixel centre, row by row (memory: do it in bands)
rgb = np.zeros((H, W, 3), np.uint8)
elev = np.zeros((H, W), np.float32)
xs = x0 + (np.arange(W) + 0.5) * KM * 1000
for r0 in range(0, H, 256):
    r1 = min(H, r0 + 256)
    ys = y1 - (np.arange(r0, r1) + 0.5) * KM * 1000
    XX, YY = np.meshgrid(xs, ys)
    lo, la = inv.transform(XX, YY)
    ci = (lo - LON0) * RES - 0.5; ri = (LAT1 - la) * RES - 0.5
    elev[r0:r1] = map_coordinates(dem, [ri, ci], order=3, mode="nearest")

# land mask from Natural Earth 10m land + minor islands, rasterised in the projection (4x supersampled edges)
def raster_land():
    SS = 2
    im = Image.new("L", (W * SS, H * SS), 0); dr = ImageDraw.Draw(im)
    for fn in ("ne_10m_land", "ne_10m_minor_islands"):
        for f in json.load(open(f"/home/claude/gb/geo/{fn}.geojson"))["features"]:
            g = shape(f["geometry"])
            for p in (g.geoms if g.geom_type == "MultiPolygon" else [g]):
                b = p.bounds
                if b[2] < 17 or b[0] > 35 or b[3] < 33.5 or b[1] > 48: continue
                for ring_i, ring in enumerate([p.exterior] + list(p.interiors)):
                    xy = np.array(ring.coords)
                    px, py = fwd.transform(xy[:, 0], xy[:, 1])
                    pts = list(zip((px - x0) / (KM * 1000) * SS, (y1 - py) / (KM * 1000) * SS))
                    if len(pts) > 2: dr.polygon(pts, fill=255 if ring_i == 0 else 0)
    # lakes
    for f in json.load(open("/home/claude/gb/geo/ne_10m_lakes.geojson"))["features"]:
        g = shape(f["geometry"])
        if (f["properties"].get("scalerank") or 9) > 8: continue
        for p in (g.geoms if g.geom_type == "MultiPolygon" else [g]):
            b = p.bounds
            if b[2] < 17 or b[0] > 35 or b[3] < 33.5 or b[1] > 48: continue
            xy = np.array(p.exterior.coords); px, py = fwd.transform(xy[:, 0], xy[:, 1])
            dr.polygon(list(zip((px - x0) / (KM * 1000) * SS, (y1 - py) / (KM * 1000) * SS)), fill=0)
    return np.asarray(im.resize((W, H), Image.LANCZOS)).astype(np.float32) / 255
land = raster_land()

# hillshade: multi-directional, from the elevation in metres on a KM grid
z = np.where(land > 0.5, np.maximum(elev, 0), 0)
zs = gaussian_filter(z, 0.8)
dzdx = np.gradient(zs, axis=1) / (KM * 1000); dzdy = -np.gradient(zs, axis=0) / (KM * 1000)
exag = 2.2
shade = np.zeros_like(zs)
for az, alt, w in ((315, 42, 0.5), (270, 40, 0.2), (0, 45, 0.15), (225, 45, 0.15)):
    a = np.radians(az); h = np.radians(alt)
    lx, ly, lz = np.sin(a) * np.cos(h), np.cos(a) * np.cos(h), np.sin(h)
    nx, ny, nz = -dzdx * exag, -dzdy * exag, 1.0
    n = np.sqrt(nx ** 2 + ny ** 2 + nz ** 2)
    shade += w * np.clip((nx * lx + ny * ly + nz * lz) / n, 0, 1)
shade = shade / max(1e-6, np.percentile(shade[land > 0.5], 99.5))

# hypsometric tint (warm, muted)
stops = [(0, (214, 214, 192)), (150, (206, 206, 178)), (400, (201, 194, 162)), (800, (192, 178, 144)),
         (1300, (178, 160, 128)), (1900, (166, 150, 126)), (2600, (196, 190, 182)), (3200, (226, 224, 220))]
ev = np.array([s[0] for s in stops], np.float32); cv = np.array([s[1] for s in stops], np.float32)
tint = np.stack([np.interp(z, ev, cv[:, k]) for k in range(3)], -1)
lit = tint * (0.52 + 0.62 * shade[..., None])
# sea: slate blue, darker with depth, pale rim near the coast
depth = np.clip(-elev, 0, 4000)
dist = distance_transform_edt(land < 0.5) * KM
sea_c = np.array([176, 196, 204], np.float32); deep = np.array([140, 164, 178], np.float32)
t = np.clip(depth / 2500, 0, 1)[..., None] ** 0.6
sea = sea_c * (1 - t) + deep * t
rim = np.clip(1 - dist / 6, 0, 1)[..., None] * 0.35
sea = sea * (1 - rim) + np.array([206, 220, 222], np.float32) * rim
out = lit * land[..., None] + sea * (1 - land[..., None])
rng = np.random.default_rng(7)
out += rng.normal(0, 2.2, out.shape)
rgb = np.clip(out, 0, 255).astype(np.uint8)
np.savez_compressed(f"/home/claude/gb/film/base_{KM:g}.npz", rgb=rgb, land=(land * 255).astype(np.uint8))
json.dump({"proj": PROJ, "x0": x0, "x1": x1, "y0": y0, "y1": y1, "km": KM, "W": W, "H": H}, open(f"/home/claude/gb/film/base_{KM:g}.json", "w"))
Image.fromarray(rgb).resize((W // 3, H // 3), Image.LANCZOS).save(f"/home/claude/gb/film/base_{KM:g}_preview.jpg", quality=88)
print("ok")
