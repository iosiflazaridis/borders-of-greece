# The Borders of Greece, 1821 – today: the kit

The code and data behind the film and the web atlas (set 34, October 2026). Paths in the scripts are those of the build machine
(`/home/claude/gb/...`); change them to your own.

## The pipeline

1. **Research** (`research/`): `BRIEF.md` is the brief given to six research batches; `GB1.json` ... `GB5.json` are their status
   events (365): status (de_jure, de_facto, awarded, occupied, autonomous, note, insurgent), start and end (Gregorian), the area in
   present-day units, the line where it cuts them, the basis, the sources and the notes. Their text has been through `data/names.py`
   (see below); ids, dates, statuses and selectors are as built.
2. **Geometry** (`geo/pieces.py`): a selector language over present-day units: Greek municipalities and regional units, Albanian
   districts, Bulgarian obshtini, Turkish ilçe, Ukrainian raions (geoBoundaries), plus splits along rivers (OpenStreetMap main
   streams, `osm/rivers_main.geojson`) and the 1832 line (OpenHistoricalMap, `osm/ohm_greece_1832_1881.geojson`), circles, boxes and
   polygons. `geo/gr_muni_ru.json` maps each municipality to its regional unit (from Wikidata).
3. **Editorial calls** (`data/mapping.py`): the selector for every event, status changes (e.g. the Entente presence of 1915–17 as a
   note), date overrides with their reasons, dropped duplicates, the Ottoman-held fortresses of 1821–33, and the fill-ins.
   `data/build_events.py` writes `data/events.json` (372 records; the Imia record was added on 27 October 2026) and the geometry; `data/timeline.py`
   gives the map on any date. `data/sel_auto.py` holds the selectors once parsed from the research's Turkish district lists.
   Selectors use the keys of geoBoundaries' present-day units (e.g. `tr:<province>/<district>`, `al:<district>`); the atlas's text never
   does: the site and the downloads give the geometry itself.
3a. **Place names** (`data/names.py`, applied by `build_events.py` and, once, to the research files by `data/clean_research.py`): each
   place is named as it was called at the time, in its Greek or English form (Constantinople, Smyrna, Adrianople, Prusa, Nicomedia;
   Imbros, Tenedos, Imia; Argyrokastro, Korytsa; Turkish names in their modern spelling, e.g. Ankara); names given later are not used; rivers in or on the border of Greece
   have their Greek names (Evros, Strymon, Nestos, Aoos). Quotations and the titles of sources are left as they are. In the records of
   Asia Minor and Eastern Thrace the Turkish sources' 'liberated' is written 'retaken by the Turks'.
4. **Film** (`film/`): `relief.py` makes the flat relief (Lambert conformal conic, AWS Terrain Tiles at zoom 7); `film.py` renders the
   frames (`python3 film.py cache`, then `render k n` for part k of n; `clock` writes `out_clock.json` for the music); `captions.json`
   holds the captions; `music/music34.py` makes the music with the approved gut phorminx model (`gut_strings.py`).
5. **Web atlas** (`site/`): `prep_site.py` writes the relief, the land mask, the shapes in the relief's pixel frame and the downloads;
   `build_site.py` writes the GitHub Pages folder; `test_site.py` checks it in Chromium.

## Inputs not included (large)

- geoBoundaries (CC BY 4.0): GRC ADM2/ADM3, ALB ADM1/ADM2, BGR ADM2, MKD ADM1, TUR ADM1/ADM2, UKR ADM2 (github.com/wmgeolab/geoBoundaries).
- Natural Earth 10m: land, minor islands, lakes, admin-0 countries.
- AWS Terrain Tiles (Terrarium, zoom 7) for lon 18–34, lat 34–47.5, resampled to 1/96°.
