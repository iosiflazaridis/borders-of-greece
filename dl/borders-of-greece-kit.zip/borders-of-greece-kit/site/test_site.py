"""Test the Borders of Greece page in Chromium: errors, overflow, interactions; screenshots.
usage: python3 test_site.py <shots folder>   (with the page served at http://127.0.0.1:8765/site/)"""
import asyncio, os, sys
from playwright.async_api import async_playwright
URL = "http://127.0.0.1:8765/site/index.html"
SHOT = sys.argv[1]; os.makedirs(SHOT, exist_ok=True)
FONTS = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "test_fonts.css")).read()
async def run(pg, name, w, h, dark=False):
    errs = []
    pg.on("pageerror", lambda e: errs.append("pageerror: " + str(e)))
    pg.on("console", lambda m: errs.append("console: " + m.text) if m.type in ("error", "warning") else None)
    await pg.set_viewport_size({"width": w, "height": h})
    if dark: await pg.emulate_media(color_scheme="dark")
    await pg.route("**/fonts.googleapis.com/**", lambda r: r.fulfill(status=200, content_type="text/css", body=FONTS))
    await pg.goto(URL); await pg.wait_for_function("window.__ready === true", timeout=60000); await pg.wait_for_timeout(1500)
    over = await pg.evaluate("document.documentElement.scrollWidth - window.innerWidth")
    print(name, "horizontal overflow px:", over)
    await pg.screenshot(path=f"{SHOT}/{name}-top.png")
    for sec in ("atlas", "area", "moments", "changes", "film", "method", "calls", "downloads"):
        await pg.evaluate(f"document.getElementById('{sec}').scrollIntoView()"); await pg.wait_for_timeout(300)
        await pg.screenshot(path=f"{SHOT}/{name}-{sec}.png")
    if not dark:
        await pg.evaluate("document.getElementById('atlas').scrollIntoView()")
        for d in ("1821-10-06", "1921-09-06", "1942-06-01", "1919-03-08"):
            await pg.evaluate(f"(() => {{ const r = document.getElementById('day'); r.value = Math.round((Date.parse('{d}') - Date.parse('1821-03-01')) / 864e5); r.dispatchEvent(new Event('input')); }})()")
            await pg.wait_for_timeout(400)
            print(name, d, "|", " / ".join((await pg.inner_text("aside.side")).split("\n")[0:6]))
            await pg.screenshot(path=f"{SHOT}/{name}-d{d}.png")
        # views
        for i in range(5):
            await pg.click(f"#views button >> nth={i}"); await pg.wait_for_timeout(300)
            await pg.screenshot(path=f"{SHOT}/{name}-view{i}.png")
        await pg.click("#views button >> nth=0"); await pg.wait_for_timeout(200)
        # click on the map centre
        b = await pg.evaluate("(() => { const r = document.getElementById('map').getBoundingClientRect(); return [r.left + r.width * 0.42, r.top + r.height * 0.55]; })()")
        await pg.mouse.click(b[0], b[1]); await pg.wait_for_timeout(400)
        print(name, "place:", (await pg.inner_text("#place"))[:300].replace("\n", " | "))
        await pg.screenshot(path=f"{SHOT}/{name}-place.png")
        await pg.click("#play"); await pg.wait_for_timeout(2000); print(name, "playing:", await pg.inner_text("#bigdate")); await pg.click("#play")
        await pg.click("#next"); await pg.wait_for_timeout(200); print(name, "next:", await pg.inner_text("#bigdate"))
        # table
        await pg.evaluate("document.getElementById('changes').scrollIntoView()")
        await pg.fill("#q", "Smyrna"); await pg.wait_for_timeout(300); print(name, "search Smyrna:", await pg.inner_text("#count"))
        await pg.click("#tb tr.row >> nth=0"); await pg.wait_for_timeout(300)
        await pg.screenshot(path=f"{SHOT}/{name}-row.png")
        sh = await pg.query_selector("#tb [data-show]")
        if sh: await sh.click(); await pg.wait_for_timeout(1200); print(name, "after show:", " / ".join((await pg.inner_text("aside.side")).split("\n")[0:3])); await pg.screenshot(path=f"{SHOT}/{name}-shown.png")
        await pg.fill("#q", ""); await pg.select_option("#fs", "awarded"); await pg.wait_for_timeout(200); print(name, "awarded rows:", await pg.inner_text("#count"))
        await pg.click(".bitem >> nth=20"); await pg.wait_for_timeout(1200); print(name, "battle:", " / ".join((await pg.inner_text("aside.side")).split("\n")[0:3]))
        await pg.screenshot(path=f"{SHOT}/{name}-battle.png")
    print(name, "errors:", errs[:10])
async def main():
    async with async_playwright() as p:
        br = await p.chromium.launch()
        for name, w, h, dark in (("desk", 1400, 900, False), ("phone", 390, 844, False), ("dark", 1400, 900, True)):
            pg = await br.new_page(device_scale_factor=1); await run(pg, name, w, h, dark); await pg.close()
        await br.close()
asyncio.run(main())
