"""Build the Borders of Greece web atlas for GitHub Pages.
usage: python3 build_site.py   (after prep_site.py)
Output: /home/claude/gb/sites/borders-of-greece-site/ (index.html, relief.jpg, land.png, geo.json, img/, thumb/, dl/, README.md, .nojekyll)"""
import json, os, shutil, html as H
from pathlib import Path
from PIL import Image
HERE = Path(__file__).resolve().parent
B = HERE / "build"
SLUG = "borders-of-greece"; PFX = SLUG
BASE = f"https://iosiflazaridis.github.io/{SLUG}/"
S = Path(f"/home/claude/gb/sites/{SLUG}-site")
core = json.load(open(B / "core.json"))
EV = core["events"]
n_ev = len(EV); n_map = sum(1 for e in EV if e["geo"])
from collections import Counter
cnt = Counter(e["status"] for e in EV)
best = max(core["states"], key=lambda r: r[1] + r[2])
caps = [c for c in core["captions"] if c["kind"] != "end"]
nbat = sum(1 for c in caps if c["kind"] == "battle")

_dur = json.load(open("/home/claude/gb/film/out_clock.json"))["DUR"]
FILMLEN = f"{int(_dur // 60)} minutes {int(round(_dur % 60))} seconds"
MONTHS = "January February March April May June July August September October November December".split()
TX = dict(
    GK="Τὰ σύνορα τοῦ ἑλληνικοῦ κράτους",
    EYEBROW="An atlas of the Greek state, 1821 – today",
    H1="The Borders of Greece",
    LEDE=("Every change in the land held by Greece or its armed forces, from the first days of the revolution in 1821 to today: "
          "the borders recognised by treaty, the lands held without recognition, from the revolution's districts to Smyrna and Northern Epirus, "
          "the treaty awards that were never carried out, and the occupations of Greek territory."),
    ATLASINTRO=("Choose a date with the slider, or press Play. <b>Solid blue</b>: the recognised Greek state. <b>Hatched blue</b>: held by the "
                "Greek state, the revolution or the Greek armed forces without recognized sovereignty. <b>Pink</b>: Allied sectors held with Greek troops. "
                "<b>Dashed lines</b>: lands awarded by a treaty but not yet handed over, or never. <b>Gray</b>: Greek territory under foreign occupation. "
                "<b>Green</b>: autonomous Greek states. <b>Orange</b>: risings for union. <b>Red hatching</b>: held by insurgents (ELAS in Athens "
                "in 1944–45, the Democratic Army in 1947–49). "
                "<b>Rings</b>: Ottoman-held fortresses. The legend is also a switch: click a row to hide its layer. Thin dashed gray lines are today's borders."),
    AREAINTRO=(f"The area of the recognised Greek state, of the lands held beyond it, and of the Greek territory under occupation, computed from the "
               f"shapes drawn on the map. The most held at once: <b>{round(best[1] + best[2], -2):,.0f} km²</b>, in {MONTHS[int(best[0][5:7]) - 1]} {best[0][:4]} "
               f"(the advance to the Sakarya). Click the chart to move the atlas to that date."),
    MOMINTRO=(f"The {nbat} battles and {len(caps) - nbat} treaties and other turning points captioned in the film. Click one to see the map on that date."),
    CHINTRO=(f"All {n_ev} records in the data: {cnt['de_jure']} recognised borders, {cnt['de_facto']} lands held, {cnt['awarded']} awards, "
             f"{cnt['occupied']} occupations, {cnt['autonomous']} autonomous states, {cnt['rising']} risings, {cnt['insurgent']} insurgent-held areas "
             f"and {cnt['note']} notes (events that do not change the map). Click a row for the treaty, the sources "
             f"and the notes; 'Show on the map' sets the atlas to its date."),
    FILMINTRO=(f"A film of the same data, {FILMLEN}, 1920 × 1080: the map month by month, with captions for the key battles and treaties, "
               "on a flat relief. Stills from it:"),
    CALLSINTRO=("The research reported its doubts, and some choices had to be made in drawing it. They are listed here, with the event they concern, "
                "so that each can be checked or changed."),
)
METHOD = [
    ("What is drawn",
     "Each change of control is a dated record: which area, from when to when, under what status, on what basis, and from which sources. "
     "The statuses: <b>recognised</b> (a treaty or protocol in force, or a decision of the Great Powers); <b>held</b> (the revolution's areas in "
     "1821–32, the advances and occupations of the Greek armed forces, the Smyrna zone, territory taken and later handed back); <b>joint</b> (Allied sectors "
     "with Greek troops: the Thracian railway in 1919–20, the Straits zone); <b>awarded</b> (a treaty or award not yet "
     "carried out, as in Attica, Euboea and Lamia in 1832–33, or never carried out: the 1830 line, Berlin 1880, Sèvres, the Venizelos–Tittoni agreement); <b>occupied</b> (Greek territory taken "
     "over by a foreign power against the government's will); <b>autonomous</b> (Samos 1834–1913, the Cretan State 1898–1908 and self-governing Crete 1908–12, "
     "the Free State of Icaria 1912, Northern Epirus 1914); and, for the site only, risings for union and areas held by insurgents."),
    ("Where the lines come from",
     "Every area is drawn from present-day units: Greek municipalities and regional units, Albanian districts, Bulgarian municipalities and Turkish "
     "districts (ilçe) (geoBoundaries). Where a historical line cuts a unit it is split along a river (the Arachthos of 1881, "
     "the Strymon of 1916–18 and 1941–44, the Spercheios, the Achelous, the Kalamas, the Evros at Karaağaç), along the 1832 line of "
     "OpenHistoricalMap (for Domokos), or by a box. Towns and forts held alone are circles. Fronts that followed no unit (the Albanian front of "
     "1941, the Sakarya salient) are drawn from the places named in the sources and are approximate."),
    ("Place names",
     "Places are named as they were called at the time, in their Greek or English form: Constantinople, Smyrna, Adrianople, Prusa, "
     "Nicaea, Nicomedia, Magnesia, Philadelphia, Kydonies, Raidestos, Saranta Ekklisies, Gallipoli; Imbros, Tenedos and Imia, which are Greek "
     "names; the towns of Northern Epirus in their Greek forms (Argyrokastro, Korytsa, Agioi Saranta, Delvino, Premeti, Chimarra). "
     "Names given later are not used, and rivers in or on the border of Greece have their Greek names (Evros, "
     "Strymon, Nestos, Aoos). Towns without a Greek or English name keep their local name of the time (Uşak, Eskişehir). Quotations and "
     "the titles of sources are given as they are."),
    ("Dates",
     "All dates are Gregorian. Greece used the Julian calendar until February 1923; the research converted Julian dates (13 days in the 20th "
     "century, 12 in the 19th) and says so in each record. A date known only to the month is placed in the middle of the month, one known only "
     "to the year in the middle of the year, unless a better date follows from the order of events (listed in the editorial calls)."),
    ("Areas",
     "The areas are computed from the drawn shapes in an equal-area projection. They are within about 1% of the official figures (the Greek state "
     "is 47,800 km² after 1833, 64,300 after 1881, 120,200 in 1914 and 131,500 today, against the official 131,957 km²)."),
    ("The research",
     "Six research batches compiled the records from the treaty texts, the English, Greek and Turkish Wikipedias, the Turkish General Staff's "
     "war history, the Hellenic Army General Staff and the standard histories (Dakin, Clogg, Koliopoulos and Veremis, Llewellyn Smith, Mazower), "
     "citing their sources record by record. For the town-by-town dates in Asia Minor it relied mainly on Turkish sources (the Ministry of "
     "Culture's chronology, the studies of Metin and Güçlü, newspaper lists of 1922), with English Wikipedia and FRUS where they give a date. "
     "The geometry was then fitted by hand to each record's description."),
    ("The film and this page",
     "The film and the atlas are drawn from the same records, on a relief in a Lambert conformal conic projection centred on the Aegean. "
     "Battles come from the Modern Greek Battles set. Everything can be downloaded below, including the code that turns the records into maps."),
]
CALLS = [
    ("The 1897 border strips", "1897-frontier-rectification-strips",
     "After the war of 1897 Greece ceded 'strategic points' along the Thessalian frontier, about 394 km². No source found locates them, so they "
     "are not drawn: the 1881 line is shown until 1912."),
    ("Thessaly and Arta, 1881", "1881-thessaly-arta",
     "Drawn as Greek from the convention (2 and 6 July 1881); the Ottoman troops left in stages between September and November, and the "
     "handover dates by district were not found."),
    ("The Arachthos and Georgios Karaiskakis", "1881-thessaly-arta",
     "The research put the Georgios Karaiskakis municipality on the right (Ottoman) bank of the Arachthos; the municipality lies east of the "
     "river, so it is drawn as Greek from 1881, with Arta town, Nikolaos Skoufas and Central Tzoumerka."),
    ("The 1832 line", "1832-kingdom-de-jure",
     "Drawn on the present boundaries of Aetolia-Acarnania, Evrytania and Phthiotis with Arta, Karditsa, Larissa and Magnesia, which follow it, "
     "except Domokos, cut along OpenHistoricalMap's line on the Othrys. The Ottoman fort of Punta (Aktio) stayed Ottoman until 1881 and is a ring."),
    ("The revolution's land, 1821–28", "1821-crete",
     "The areas held by the revolution are drawn by whole units, with the Ottoman-held fortresses as rings; the countryside was contested, "
     "and its extent is approximate (Crete in 1821–24 is drawn as its three western regional units; Kolokotronis' bands in 1825–27 are not drawn)."),
    ("Evrytania, 1829–32, and the Dodecanese islands of 1821", "1829-evrytania",
     "The research marked both as unverified: whether Greek authority reached Karpenisi and the Agrafa before 1832, and which Dodecanese "
     "islands were in the revolutionary state. Both are drawn, as approximate."),
    ("Risings are not held land", "1854-epirus-arta-peta",
     "The risings of 1854 and 1878 were led by Greek officers who had resigned their commissions; the state did not hold the land, so they are "
     "drawn as risings (orange), not as Greek-held."),
    ("The Entente in Greece, 1915–17", "1915-thessaloniki-entente",
     "The Allied presence at Thessaloniki, Corfu, Milos, Lesbos and in Thessaly in 1917 is kept as a note, not as an occupation: the Greek "
     "administration continued. The National Defence government of 1916–17 is also a note: a rival Greek government, not a change of border."),
    ("Northern Epirus in 1916", "1916-italy-northern-epirus",
     "Italy, Bulgaria and France took over the Greek-held districts of Northern Epirus in 1916. Greek sovereignty there had not been recognized "
     "(the Powers had assigned it to Albania in 1913), so the map shows the end of Greek control there, not an occupation of Greek territory."),
    ("Imbros and Tenedos, 1912–23", "1912-tenedos",
     "Both stayed under Greek administration from 1912 until the handover under the Lausanne settlement in September 1923; the 1914 award of "
     "the Powers was not carried out for them."),
    ("Imia (Limnia)", "1947-imia",
     "Imia is Greek territory: two uninhabited islets east of Kalymnos, part of the Dodecanese. Turkey renounced the Dodecanese and the islets "
     "dependent on them in favour of Italy at Lausanne (1923, Art. 15); the Italian–Turkish convention of 4 January 1932 and its protocol of "
     "28 December 1932 placed Imia on the Italian side; Italy ceded the Dodecanese 'as well as the adjacent islets' to Greece by the Treaty "
     "of Paris (1947, Art. 14). Turkey did not contest this until the crisis of 1995–96 and has disputed it since; Greek sovereignty did not "
     "change. The islets are too small to see at this scale, so they are marked with a point from 1947."),
    ("Southern Ukraine, 1919", "1919-ukraine-odessa",
     "Two Greek divisions served under French command in the Allied intervention against the Bolsheviks (Odessa, Kherson, Nikolaev, "
     "Sevastopol, January–April 1919). Greece held no land of its own there, so the five records are kept as notes, with the forces and "
     "dates, and are not drawn on the map or in the film."),
    ("Mount Athos", "1924-mount-athos",
     "Held from November 1912 (hatched). Greek sovereignty, with the monastic autonomy, was recognised at Lausanne, so Athos is drawn as part "
     "of the recognized state from 6 August 1924."),
    ("Asia Minor, district by district", "fill-1921-sakarya-east",
     "The Greek-held zone is drawn by present-day districts from the date each was taken to the date it was lost. Some districts appear only in "
     "the research's snapshots of the front; they are drawn as fill-ins with inferred dates (marked 'editorial'). The Sakarya salient east of the "
     "river is the least certain area of all."),
    ("Sandıklı", "1921-08-sandikli",
     "The Turkish Ministry of Culture's chronology dates its recapture to 12 September 1922, which is doubtful; it is drawn until the withdrawal after the Sakarya "
     "(24 September 1921)."),
    ("Western Thrace, 1920", "1920-komotini",
     "The Greek sources give 14–16 May 1920; read as Old Style, that is 27–29 May (Gregorian)."),
    ("Eastern Thrace, October 1922", "1922-eastern-thrace-evacuation",
     "Drawn as held until 31 October 1922, when the Greek Army stood on the Evros after Mudanya; the Allied missions then handed the land to Turkey."),
    ("The Albanian front, 1940–41", "1941-greek-held-southern-albania-front-line",
     "No source gives the whole front line; it is drawn through the positions named (the Kuç saddle, Trebeshina, Hill 731, the south of Tomoros, "
     "the Kamia massif) on the pre-2015 Albanian districts, and is approximate."),
    ("The occupation of 1941", "1941-1944-ionian-islands",
     "Some occupations are dated only to the month; those of April 1941 are drawn from 30 April, after the fall of Athens, and the occupation of "
     "western Crete from the fall of Chania (27 May), not from the first landings."),
    ("The Civil War", "1947-1949-dse-vitsi",
     "Athens and Piraeus held by ELAS in the Dekemvriana (December 1944 – January 1945) and the Democratic Army's bases at Grammos and Vitsi "
     "(1947–49) are drawn, faintly and approximately, as held by insurgents; the Democratic Army's other mountain zones are not drawn. The film "
     "leaves all of them out."),
    ("Thessaloniki, 1912–13", "1912-thessaloniki",
     "A Bulgarian division was in the city with the Greek garrison until June 1913; the city is drawn as Greek-held, not as a joint sector."),
]
import sys as _sys; _sys.path.insert(0, "/home/claude/gb/data"); import names as _N
TX = {k: _N.us_text(v) for k, v in TX.items()}
METHOD = [(_N.us_text(t), _N.us_text(x)) for t, x in METHOD]
CALLS = [(_N.us_text(t), i, _N.us_text(x)) for t, i, x in CALLS]
def ev_link(i): return f' <button type="button" class="linkbtn" data-ev="{i}">Show</button>' if i in {e["id"] for e in EV if e["geo"]} else ""
calls_html = "".join(f'<div class="q"><h3>{H.escape(t)}</h3><p>{x}{ev_link(i)}</p></div>' for t, i, x in CALLS)
method_html = "".join(f"<div><h3>{t}</h3><p>{x}</p></div>" for t, x in METHOD)
facts = [(f"{n_ev - cnt['note']}", f"dated changes of control, and {cnt['note']} notes, each with its sources"), (f"{round(best[1] + best[2], -2):,.0f} km²", "the most held at once, in 1921"),
         ("131,957 km²", "the Greek state today, unchanged since 1947"), (f"{nbat}", "battles captioned in the film, with the treaties")]
facts_html = "".join(f'<div class="fact"><b>{a}</b><span>{b}</span></div>' for a, b in facts)
STILLS = [("1821-10-06", "October 1821: the revolution, with the Ottoman-held fortresses"), ("1830-03-01", "1830: the London Protocol's line (dashed)"),
          ("1854-06-01", "1854: the risings, and the Ionian Islands still British"), ("1897-06-01", "1897: Thessaly under Ottoman occupation"),
          ("1913-08-01", "August 1913: Macedonia, Epirus and Western Thrace"),
          ("1920-09-01", "1920: Sèvres, the Smyrna zone and Eastern Thrace"), ("1921-09-06", "September 1921: the Sakarya"), ("1940-12-25", "December 1940: a quarter of Albania held"),
          ("1942-06-01", "1942: the triple occupation"), ("end", "Today, with the lands once held or awarded"), ("card", "The summary card")]
gallery = "".join(f'<button type="button" class="thumb" data-full="img/{PFX}-{k}.png" data-cap="{H.escape(c)}"><img src="thumb/{PFX}-{k}.jpg" alt="{H.escape(c)}" loading="lazy"><span>{H.escape(c)}</span></button>' for k, c in STILLS)
DLS = [(f"{PFX}-events.geojson", "every record with its geometry (WGS 84, simplified to about 200 m)"), (f"{PFX}-events.csv", "the records as a table"),
       (f"{PFX}-events.xlsx", "the records and the areas, as a spreadsheet"), (f"{PFX}-events.json", "the records as JSON"),
       (f"{PFX}-areas.csv", "the area held on every date where it changes"), (f"{PFX}-film-captions.json", "the film's captions"),
       (f"{PFX}-kit.zip", "the code and data that build the maps, the film and this page")]
dl_html = "".join(f'<div><a href="dl/{f}" download>{f}</a> <span>— {d}</span></div>' for f, d in DLS)
FOOT = (f"Boundaries: geoBoundaries (CC BY 4.0), Natural Earth; the 1832 line from OpenHistoricalMap; rivers from OpenStreetMap (ODbL). "
        f"Relief: AWS Terrain Tiles (SRTM and others). Battles: the Modern Greek Battles set. Data compiled October 2026; corrections welcome. "
        f"<a href=\"{BASE}\">{BASE}</a>")

page = open(HERE / "page.html").read()
rep = dict(GK=TX["GK"], EYEBROW=TX["EYEBROW"], H1=TX["H1"], LEDE=TX["LEDE"], FACTS=facts_html, ATLASINTRO=TX["ATLASINTRO"], AREAINTRO=TX["AREAINTRO"],
           MOMINTRO=TX["MOMINTRO"], CHINTRO=TX["CHINTRO"], FILMINTRO=TX["FILMINTRO"], GALLERY=gallery, METHOD=method_html, CALLSINTRO=TX["CALLSINTRO"],
           CALLS=calls_html, DOWNLOADS=dl_html, FOOTER=FOOT, CORE=json.dumps(core, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/"))
for k, v in rep.items(): page = page.replace(f"%%{k}%%", v)
assert "%%" not in page, page[page.index("%%") - 40: page.index("%%") + 40]
css = "<style>\n" + open("/home/claude/pr/sitekit/base.css").read() + "\n" + open(HERE / "borders.css").read() + "\n</style>"
desc = "An atlas of the Greek state, day by day, from 1821 to today: recognized borders, lands held, treaty awards and occupations, with sources."
head = f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>The Borders of Greece, 1821 – today</title>
<meta name="description" content="{desc}">
<meta property="og:title" content="The Borders of Greece, 1821 – today">
<meta property="og:description" content="{desc}">
<meta property="og:type" content="website">
<meta property="og:url" content="{BASE}">
<meta property="og:image" content="{BASE}thumb/{PFX}-card.jpg">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:image" content="{BASE}thumb/{PFX}-card.jpg">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Marcellus&family=Gentium+Book+Plus:ital,wght@0,400;0,700;1,400&family=IBM+Plex+Sans+Condensed:ital,wght@0,400;0,500;0,600;1,400&display=swap">
'''
html = head + css + "\n</head>\n<body>\n" + page + "\n</body>\n</html>\n"

shutil.rmtree(S, ignore_errors=True)
for d in ("img", "thumb", "dl"): (S / d).mkdir(parents=True)
for f in ("relief.jpg", "land.png", "geo.json"): shutil.copy(B / f, S / f)
for f in os.listdir(B / "dl"): shutil.copy(B / "dl" / f, S / "dl" / f)
STILLDIR = Path("/home/claude/gb/stills")
for k, c in STILLS:
    src = STILLDIR / f"{k}.png"
    if not src.exists(): print("missing still", src); continue
    shutil.copy(src, S / "img" / f"{PFX}-{k}.png")
    Image.open(src).convert("RGB").resize((1200, 675), Image.LANCZOS).save(S / "thumb" / f"{PFX}-{k}.jpg", quality=86, optimize=True, progressive=True)
(S / "index.html").write_text(html, encoding="utf8"); (S / ".nojekyll").write_text("")
readme = f'''# The Borders of Greece, 1821 – today

An atlas of the land held by the Greek state and its army, day by day, from the revolution of 1821 to today: the borders recognised by
treaty, the lands held without recognition (the revolution's districts, Smyrna and Asia Minor, Eastern Thrace, Northern Epirus), the treaty awards that were never carried out (the 1830 line, Berlin 1880, Sèvres) and the occupations of Greek territory.
{n_ev} records ({n_ev - cnt['note']} dated changes of control and {cnt['note']} notes), each with its basis, its sources and its doubts.

**Open the page:** {BASE}

Files: `index.html` (the page, with the records), `geo.json` (the shapes), `relief.jpg` and `land.png` (the map), `img/` and `thumb/` (stills
of the film), `dl/` (downloads: GeoJSON, CSV, xlsx, JSON, the kit).
'''
(S / "README.md").write_text(_N.us_text(readme).replace("the Greek state and its army", "Greece or its armed forces"))
print("site", S, sum(f.stat().st_size for f in S.rglob("*") if f.is_file()) // 1024, "KB;", "index.html", (S / "index.html").stat().st_size // 1024, "KB")
