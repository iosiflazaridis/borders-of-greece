"""Prepare the data of the Borders of Greece web atlas.

Writes into /home/claude/gb/site/build/:
  relief.jpg, land.png        the flat relief (1 km/px, the film's projection) and its land mask
  geo.json                    the events' geometry as SVG path strings in the relief's pixel frame; award lines; zone lines
  core.json                   events (without geometry), areas per state, holdouts, battles and captions, views
  dl/*                        downloads (GeoJSON in lon/lat, CSV, JSON, xlsx)
"""
import sys, json, os, math, pickle, csv, datetime as dt
os.environ["GB_ALL"] = "1"     # the site keeps the events the film leaves out (Imia, a point too small for the film)
import numpy as np
from PIL import Image
sys.path.insert(0, "/home/claude/gb/film"); sys.path.insert(0, "/home/claude/gb/data"); sys.path.insert(0, "/home/claude/gb/geo")
import film as F, timeline as T, mapping as M
import shapely
from shapely.ops import unary_union

OUT = "/home/claude/gb/site/build"; os.makedirs(OUT + "/dl", exist_ok=True)
KM = 1000.0   # metres per site pixel
X0, Y1 = F.BX0, F.BY1
WPX, HPX = int((F.BX1 - F.BX0) / KM), int((F.BY1 - F.BY0) / KM)

# ---------------------------------------------------------------- the relief and the land mask at 1 km/px
rgb = Image.fromarray(F.BASE).resize((WPX, HPX), Image.LANCZOS)
rgb.save(f"{OUT}/relief.jpg", quality=84, optimize=True, progressive=True)
land = Image.fromarray(F.LAND).resize((WPX, HPX), Image.LANCZOS)
la = np.asarray(land)
mask = np.zeros((HPX, WPX, 4), np.uint8); mask[..., 3] = la
Image.fromarray(mask, "RGBA").save(f"{OUT}/land.png", optimize=True)
print("relief", WPX, HPX, os.path.getsize(f"{OUT}/relief.jpg") // 1024, "KB; land", os.path.getsize(f"{OUT}/land.png") // 1024, "KB")

# ---------------------------------------------------------------- paths
def topx(g):
    return shapely.transform(g, lambda c: np.column_stack(((c[:, 0] - X0) / KM, (Y1 - c[:, 1]) / KM)))
def path_d(g, closed=True):
    """SVG path with relative moves, one decimal"""
    out = []
    def ring(coords):
        xy = np.round(np.asarray(coords) * 10).astype(np.int64)
        if len(xy) < 2: return
        s = [f"M{xy[0,0]/10:g} {xy[0,1]/10:g}"]
        d = np.diff(xy, axis=0)
        d = d[(d != 0).any(axis=1)]
        if len(d): s.append("l" + " ".join(f"{a/10:g} {b/10:g}" for a, b in d))
        if closed: s.append("z")
        out.append("".join(s))
    def walk(p):
        t = p.geom_type
        if t == "Polygon":
            ring(p.exterior.coords)
            for r in p.interiors: ring(r.coords)
        elif t in ("LineString", "LinearRing"): ring(p.coords)
        elif hasattr(p, "geoms"):
            for q in p.geoms: walk(q)
    walk(g)
    return "".join(out)

GEO_ST = ("de_jure", "de_facto", "awarded", "occupied", "autonomous", "rising", "insurgent")
geo = {"W": WPX, "H": HPX, "ev": {}, "awl": {}, "zones": None}
for e in T.EV:
    i = e["id"]
    if i not in T.GM or e["status"] not in GEO_ST: continue
    g = T.GM[i]
    if g.is_empty: continue
    gp = shapely.make_valid(topx(F.pgeom(g)).simplify(0.45))
    if gp.area < 0.05 and e["status"] != "awarded":     # a point-sized place (a fort, an islet): kept as a dot
        c = F.pgeom(g).centroid; geo["ev"][i] = {"pt": [round((c.x - X0) / KM, 1), round((Y1 - c.y) / KM, 1)]}
        continue
    b = gp.bounds
    geo["ev"][i] = {"d": path_d(gp), "bb": [round(b[0]), round(b[1]), round(b[2]), round(b[3])]}
    if e["status"] == "awarded":
        # the land frontiers of the award, plus its coasts where Greece did not hold the coast at any time during the award
        a0, a1 = e["start"], e["end"] or "2100-01-01"
        held = unary_union([T.GM[x["id"]] for x in T.GEO if x["status"] in ("de_jure", "de_facto", "occupied") and x["start"] < a1 and (x["end"] or "2100") > a0])
        P = F.pgeom(g); L = P.boundary
        front = L.intersection(F.INLAND)
        coast = L.difference(F.INLAND)
        if not held.is_empty: coast = coast.difference(F.pgeom(held).buffer(2500))
        lines = topx(unary_union([front, coast])).simplify(0.4)
        geo["awl"][i] = path_d(lines, closed=False)
geo["zones"] = path_d(topx(F.zones()), closed=False)
geo["borders"] = path_d(topx(F.BORDERS).simplify(0.4), closed=False)
geo["rivers"] = path_d(topx(F.RIVERS_ALL).simplify(0.4), closed=False)
json.dump(geo, open(f"{OUT}/geo.json", "w"), separators=(",", ":"))
print("geo.json", os.path.getsize(f"{OUT}/geo.json") // 1024, "KB;", len(geo["ev"]), "events with geometry")

# ---------------------------------------------------------------- core data
def px(lon, lat):
    X, Y = F.proj(lon, lat); return [round((X - X0) / KM, 1), round((Y1 - Y) / KM, 1)]
ST = []
for k, d in enumerate(F.STATE_DAYS):
    a = F.areas(k)
    ST.append([F.iso(d), round(a["dj"]), round(a["df"]), round(a["occ"]), round(a["aut"])])
# the holdout rings, shown while inside or next to Greek-held land (as in the film)
spans = {}
for k, d in enumerate(F.STATE_DAYS):
    names = {(n, round(X), round(Y)) for n, X, Y in F.classes_proj(k)["hold"]}
    end = F.iso(F.STATE_DAYS[k + 1]) if k + 1 < len(F.STATE_DAYS) else F.iso(F.D1)
    for key in names:
        sp = spans.setdefault(key, [])
        if sp and sp[-1][1] == F.iso(d): sp[-1][1] = end
        else: sp.append([F.iso(d), end])
HOLD = [dict(name=n, xy=[round((X - X0) / KM, 1), round((Y1 - Y) / KM, 1)], start=sp[0][0], end=sp[-1][1], spans=sp) for (n, X, Y), sp in spans.items()]
# the research's lists of present-day units and the drawing selectors (keys of geoBoundaries' present-day units) stay in the kit's code;
# the site and the downloads give the geometry itself
KEEP = ["id", "batch", "status", "status_research", "start", "start_precision", "end", "end_precision", "name", "confidence", "line",
        "joint", "joint_with", "occupier", "by_whom", "battle", "basis", "event", "signed", "in_force", "handover", "date_note",
        "sources", "note", "editorial"]
EV = []
for e in T.EV:
    r = {k: e.get(k) for k in KEEP}
    r["geo"] = e["id"] in geo["ev"]
    EV.append(r)
caps = []
for c in F.CAPS:
    caps.append(dict(date=c["date"], kind=c["kind"], title=c["title"], text=c["text"], win=c.get("win", ""),
                     xy=px(c["lon"], c["lat"]) if "lat" in c else None, set15=c.get("set15")))
def view(name):
    cx, cy, w = F.VR[name]; h = w / F.ASPECT
    return [round((cx - w / 2 - X0) / KM), round((Y1 - (cy + h / 2)) / KM), round(w / KM), round(h / KM)]
# each view of a period also moves the atlas to a date in that period (the dates of the stills)
VIEWS = [("greece", "Greece", view("full"), None), ("south", "The revolution", view("south"), "1821-10-06"),
         ("asia", "Asia Minor and Thrace", view("asia"), "1921-09-06"),
         ("all", "The whole map", [0, 0, WPX, HPX], None)]
core = dict(W=WPX, H=HPX, D0=F.iso(F.D0), D1=F.iso(F.D1), events=EV, states=ST,
            holdouts=HOLD,
            captions=caps, views=VIEWS,
            cities=[dict(name=n, xy=px(lo, la)) for n, la, lo in F.CITIES],
            zlabels=[dict(name=n, xy=px(lo, la), start=a, end=b) for n, la, lo, a, b in F.ZLAB],
            bounds=[F.iso(b) for b in F.BOUND],
            minor=[dict(name="Imia", xy=px(27.150, 37.050), start="1947-09-15")])     # labels shown when zoomed in
json.dump(core, open(f"{OUT}/core.json", "w"), ensure_ascii=False, separators=(",", ":"))
print("core.json", os.path.getsize(f"{OUT}/core.json") // 1024, "KB")

# ---------------------------------------------------------------- downloads
PFX = "borders-of-greece"
feats = []
for e in T.EV:
    i = e["id"]
    props = {k: e.get(k) for k in KEEP}
    g = T.GM.get(i)
    geom = None
    if g is not None and not g.is_empty and e["status"] in GEO_ST:
        geom = shapely.geometry.mapping(shapely.make_valid(g.simplify(0.002)))
    feats.append({"type": "Feature", "properties": props, "geometry": geom})
json.dump({"type": "FeatureCollection", "name": PFX, "features": feats}, open(f"{OUT}/dl/{PFX}-events.geojson", "w"), ensure_ascii=False)
json.dump([{k: v for k, v in r.items() if k != "geo"} for r in EV], open(f"{OUT}/dl/{PFX}-events.json", "w"), ensure_ascii=False, indent=1)
cols = [k for k in KEEP]
with open(f"{OUT}/dl/{PFX}-events.csv", "w", newline="", encoding="utf8") as fh:
    w = csv.writer(fh); w.writerow(cols)
    for e in T.EV:
        w.writerow([e.get(k) for k in cols])
with open(f"{OUT}/dl/{PFX}-areas.csv", "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["from_date", "greek_state_km2", "held_not_recognised_km2", "occupied_km2", "autonomous_km2"])
    for r in ST: w.writerow(r)
json.dump(caps, open(f"{OUT}/dl/{PFX}-film-captions.json", "w"), ensure_ascii=False, indent=1)
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment
wb = Workbook(); ws = wb.active; ws.title = "events"
ws.append(cols)
for e in T.EV: ws.append([str(e.get(k)) if isinstance(e.get(k), (list, dict)) else e.get(k) for k in cols])
for c in ws[1]: c.font = Font(bold=True)
ws.freeze_panes = "A2"
for col, wdt in zip("ABCDEFGHIJ", (34, 7, 11, 11, 11, 8, 11, 8, 40, 9)): ws.column_dimensions[col].width = wdt
ws2 = wb.create_sheet("areas"); ws2.append(["from_date", "greek_state_km2", "held_not_recognised_km2", "occupied_km2", "autonomous_km2"])
for r in ST: ws2.append(r)
for c in ws2[1]: c.font = Font(bold=True)
wb.save(f"{OUT}/dl/{PFX}-events.xlsx")
for f in sorted(os.listdir(f"{OUT}/dl")): print(" ", f, os.path.getsize(f"{OUT}/dl/{f}") // 1024, "KB")
